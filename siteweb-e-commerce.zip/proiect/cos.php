<?php 
session_start();
require_once 'db.php';


$customerId=$_SESSION['customer_id']?? null;
$guestId=$_SESSION['guest_id']?? null;
$cartId=$_SESSION['cart_id']?? null;



if($_SERVER["REQUEST_METHOD"]==="POST" &&isset($_POST['action'])){
    $cart_item_id = intval($_POST['cart_item_id']);
    $action       = $_POST['action'];
    $stmt=$conn->prepare("SELECT quantity FROM cart_items WHERE cart_item_id=? AND cart_id=?");
    $stmt->bind_param("ii", $cart_item_id,$cartId);
    $stmt->execute();
    $res=$stmt->get_result();
if ($row = $res->fetch_assoc()) {
        $quantity = $row['quantity'];

        if ($action === "plus") {
            $quantity++;
            $update = $conn->prepare("UPDATE cart_items SET quantity=? WHERE cart_item_id=?");
            $update->bind_param("ii", $quantity, $cart_item_id);
            $update->execute();
        } elseif ($action === "minus") {
            if ($quantity > 1) {
                $quantity--;
                $update = $conn->prepare("UPDATE cart_items SET quantity=? WHERE cart_item_id=?");
                $update->bind_param("ii", $quantity, $cart_item_id);
                $update->execute();
            } else {
                $del = $conn->prepare("DELETE FROM cart_items WHERE cart_item_id=?");
                $del->bind_param("i", $cart_item_id);
                $del->execute();
            }
        } elseif ($action === "delete") {
            $del = $conn->prepare("DELETE FROM cart_items WHERE cart_item_id=?");
            $del->bind_param("i", $cart_item_id);
            $del->execute();
        }
    }
     header("Location: cos.php");
    exit;
}

$stmt=$conn->prepare("SELECT ci.cart_item_id, ci.product_id, ci.quantity, p.name, p.price,p.discount FROM cart_items ci INNER JOIN products p ON ci.product_id=p.product_id WHERE ci.cart_id=?");
$stmt->bind_param("i", $cartId);
$stmt->execute();
$res=$stmt->get_result();

$total=0;
?>



   <?php include 'header.php'; ?>

<div class="container mt-5">
  <h2 class="mb-4">Coșul meu</h2>


<?php if ($res->num_rows===0){?>
  <div class="alert alert-warning text-center">
    <h5>Cosul tau este gol</h5>
    <p>Nu ai adaugat niciun produs</p>
    <a href="index.php" class="btn btn-primary mt-3">Inapoi la pagina principala</a>

  </div>
  <?php  }else{?>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Nume</th>
        <th>Preț</th>
        <th>Discount</th>
        <th>Cantitate</th>
        <th>Subtotal</th>
        <th>Acțiuni</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = $res->fetch_assoc()){
        $reducedPrice = $row['price'] - ($row['price'] * $row['discount'] / 100);
        $subtotal = $reducedPrice * $row['quantity'];
        $total += $subtotal;
      ?>
      <tr>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo number_format($row['price'],2); ?> lei</td>
        <td><?php echo $row['discount']; ?>%</td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <form method="POST"  class="d-inline">
              <input type="hidden" name="cart_item_id" value="<?php echo $row['cart_item_id']; ?>">
              <input type="hidden" name="action" value="minus">
              <button type="submit" class="btn btn-sm btn-outline-secondary">-</button>
            </form>
            <span><?php echo $row['quantity']; ?></span>
            <form method="POST"  class="d-inline">
              <input type="hidden" name="cart_item_id" value="<?php echo $row['cart_item_id']; ?>">
              <input type="hidden" name="action" value="plus">
              <button type="submit" class="btn btn-sm btn-outline-secondary">+</button>
            </form>
          </div>
        </td>
        <td><?php echo number_format($subtotal,2); ?> lei</td>
        <td>
          <form method="POST">
            <input type="hidden" name="cart_item_id" value="<?php echo $row['cart_item_id']; ?>">
            <input type="hidden" name="action" value="delete">
            <button type="submit" class="btn btn-sm btn-danger">Șterge</button>
          </form>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>

  <h4 class="text-end">Total: <?php echo number_format($total,2); ?> lei</h4>

  <div class="d-flex justify-content-end mt-3">
    <a href="index.php" class="btn btn-secondary me-2">Continuă cumpărăturile</a>
    <a href="checkout.php" class="btn btn-success">Finalizare comandă</a>
  </div>
  <?php }?>
</div>
  <br><br><br>
 <?php 
      include 'footer.php';
      ?>
