<?php 
   session_start();
   require_once 'db.php';
   
   
   $customer = null;
   $addresses = [];
   
   if (isset($_SESSION['customer_id'])) {
       $stmt = $conn->prepare("SELECT first_name, last_name, email FROM customers WHERE customer_id=?");
       $stmt->bind_param("i", $_SESSION['customer_id']);
       $stmt->execute();
       $res = $stmt->get_result();
       $customer = $res->fetch_assoc();
   
       $addrstmt = $conn->prepare("SELECT * FROM addresses WHERE customer_id=?");
       $addrstmt->bind_param("i", $_SESSION['customer_id']);
       $addrstmt->execute();
       $addresses = $addrstmt->get_result()->fetch_all(MYSQLI_ASSOC);
   }
   
   
   $payments = $conn->query("SELECT * FROM payments")->fetch_all(MYSQLI_ASSOC);
   $shippings = $conn->query("SELECT * FROM shippings")->fetch_all(MYSQLI_ASSOC);
   
   
   $cartID = $_SESSION['cart_id'] ?? null;
   $judete = $conn->query("SELECT DISTINCT judet FROM ps_rc_fancourier_cities ORDER BY judet ASC");
   $localitati = $conn->query("SELECT judet, localitate FROM ps_rc_fancourier_cities ORDER BY judet, localitate ASC");
   
   
   $localitatiData = [];
   while ($row = $localitati->fetch_assoc()) {
       $localitatiData[$row['judet']][] = $row['localitate'];
   }
   
   $selectedCounty = $addresses[0]['county'] ?? '';
   $selectedCity   = $addresses[0]['city'] ?? '';
   
   $cartItems = [];
   $totalProducts = 0;
   $totalPayment = 0;
   
   if ($cartID) {
       $cartQuery = $conn->prepare("
           SELECT ci.quantity, p.product_id, p.name, p.price,IFNULL(p.discount, 0) AS discount,
        ROUND(p.price * (100 - IFNULL(p.discount,0)) / 100, 2) AS price_final
           FROM cart_items ci
           JOIN products p ON ci.product_id = p.product_id
           WHERE ci.cart_id = ?
       ");
       $cartQuery->bind_param("i", $cartID);
       $cartQuery->execute();
       $res=$cartQuery->get_result();
       $cartItems = $res->fetch_all(MYSQLI_ASSOC);
   
       foreach ($cartItems as $item) {
           $subtotal = $item['price_final'] * $item['quantity'];
           $totalProducts += $item['quantity'];
           $totalPayment += $subtotal;
       }
   }
   
   
   if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalizeaza'])) {
       $firstName   = $_POST['first_name'];
       $lastName    = $_POST['last_name'];
       $email       = $_POST['email'];
       $address     = $_POST['address'];
       $city        = $_POST['city'];
       $county      = $_POST['county'];
       $country     = $_POST['country'] ?? 'Romania'; 
       $postalCode  = $_POST['postal_code'];
       $payment     = $_POST['payment'];
       $shipping    = $_POST['shipping'];
       $company_name=$_POST['company_name'] ?? null;
       $tax_id=$_POST['tax_id']?? null;
   
   
        $shippingCost = 0.0;
       $shipStmt = $conn->prepare("SELECT cost FROM shippings WHERE shipping_id = ?");
       $shipStmt->bind_param("i", $shipping);
       $shipStmt->execute();
       $shipRes = $shipStmt->get_result()->fetch_assoc();
       if ($shipRes) {
           $shippingCost = (float)$shipRes['cost'];
       }
   
       // 2) Total FINAL (produse + livrare)
       $totalPaymentWithShipping = $totalPayment + $shippingCost;
   
   
       if ($totalProducts > 0) {
           $conn->begin_transaction();
           try {
               $customerID = $_SESSION['customer_id'] ?? null;
               $guestID=$_SESSION['guest_id']?? null;
   
               if (!$customerID && $guestID) {
    
                   $stmtGuest = $conn->prepare("
                   UPDATE guest 
                   SET first_name = ?, last_name = ?, email = ? 
                   WHERE guest_id = ?
                   ");
                   $stmtGuest->bind_param("sssi", $firstName, $lastName, $email, $guestID);
                   $stmtGuest->execute();
               }
            
            $company_name = trim((string)($company_name ?? ''));
            $tax_id       = trim((string)($tax_id ?? ''));

            $streetNorm   = trim($address);
            $cityNorm     = trim($city);
            $countyNorm   = trim($county);
            $postalNorm   = trim($postalCode);
            $countryNorm  = trim($country);

            $customerIdForMatch = $customerID ?? 0;

            $findAddr = $conn->prepare("
    SELECT address_id
    FROM addresses
    WHERE IFNULL(customer_id, 0) = IFNULL(?, 0)
      AND LOWER(TRIM(street_address)) = LOWER(TRIM(?))
      AND LOWER(TRIM(city))           = LOWER(TRIM(?))
      AND LOWER(TRIM(county))         = LOWER(TRIM(?))
      AND TRIM(postal_code)           = TRIM(?)
      AND LOWER(TRIM(country))        = LOWER(TRIM(?))
      AND COALESCE(tax_id,'')         = COALESCE(?, '')
      AND COALESCE(company_name,'')   = COALESCE(?, '')
    LIMIT 1
            ");
            $findAddr->bind_param(
            "isssssss",
            $customerIdForMatch,
            $streetNorm, $cityNorm, $countyNorm, $postalNorm, $countryNorm,
            $tax_id, $company_name
            );
            $findAddr->execute();
            $existing = $findAddr->get_result()->fetch_assoc();

        if ($existing) {
            $addressId = (int)$existing['address_id'];
        } else {
            $insAddr = $conn->prepare("
        INSERT INTO addresses
          (customer_id, street_address, city, county, postal_code, country, tax_id, company_name)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $customerIdForInsert = $customerID ?? null;
            $taxIdParam = ($tax_id === '' ? null : $tax_id);
            $companyNameParam = ($company_name === '' ? null : $company_name);
            $insAddr->bind_param(
            "isssssss",
            $customerIdForInsert, $streetNorm, $cityNorm, $countyNorm, $postalNorm, $countryNorm,
            $taxIdParam,
            $companyNameParam
        );
        $insAddr->execute();
        $addressId = $insAddr->insert_id;
    }
   
   
               if ($customerID) {
                   $stmt = $conn->prepare("
                   INSERT INTO orders (order_reference, customer_id, guest_id, cart_id, address_id, payment_id, shipping_id, total_products, total_payment,current_state)
                   VALUES (1, ?, NULL, ?, ?, ?, ?, ?, ?,1)
                   ");
                   $stmt->bind_param("iiiiiid", $customerID, $cartID, $addressId, $payment, $shipping, $totalProducts, $totalPaymentWithShipping);
               } else {
                   $stmt = $conn->prepare("
                   INSERT INTO orders (order_reference, customer_id, guest_id, cart_id, address_id, payment_id, shipping_id, total_products, total_payment,current_state)
                   VALUES (1, NULL, ?, ?, ?, ?, ?, ?, ?,1)
                   ");
                   $stmt->bind_param("iiiiiid", $guestID, $cartID, $addressId, $payment, $shipping, $totalProducts, $totalPaymentWithShipping);
               }
   
               $stmt->execute();
               $orderId = $stmt->insert_id;
   
               $ref = "ORD-" . $orderId;
               $updateRef = $conn->prepare("UPDATE orders SET order_reference=? WHERE order_id=?");
               $updateRef->bind_param("si", $ref, $orderId);
               $updateRef->execute();
   
              
               foreach ($cartItems as $item) {
                   $stmtItem = $conn->prepare("
                       INSERT INTO order_items (order_id, product_id, product_name, quantity, price_final, price_original, discount, reference)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                   ");
                   $productId = (int)$item['product_id'];
                   $productName = (string)$item['name'];
                   $quantity = (int)$item['quantity'];
                   $priceFinal = (float)$item['price_final'];
                   $priceOriginal = (float)$item['price'];
                   $discount = (float)$item['discount'];
                   $stmtItem->bind_param("iisiddds", $orderId, $productId, $productName, $quantity, $priceFinal, $priceOriginal, $discount, $ref);
                   $stmtItem->execute();

                   $updateStock=$conn->prepare("
                   UPDATE products
                   SET stock_quantity=GREATEST(stock_quantity-?,0)
                   WHERE product_id=?");
                   $updateStock->bind_param("ii",$quantity,$productId);
                   $updateStock->execute();
               }
   
               $conn->commit();

               // Email de confirmare comanda (non-blocant)
               try {
                   require_once __DIR__ . '/phpmailer/PHPMailer.php';
                   require_once __DIR__ . '/phpmailer/SMTP.php';
                   require_once __DIR__ . '/phpmailer/Exception.php';

                   $mailer = new \PHPMailer\PHPMailer\PHPMailer(true);
                   // Pentru SMTP, decomenteaza si configureaza:
                    $mailer->isSMTP();
                    $mailer->Host = 'sandbox.smtp.mailtrap.io';
                    $mailer->SMTPAuth = true;
                    $mailer->Username = '48c1beb3fab6c6';
                    $mailer->Password = '46b28686d24d29';
                    $mailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mailer->Port = 2525;

                   $mailer->setFrom('andreeanicola2003@gmail.com', 'Mailer');
                   $mailer->addAddress($email, trim($firstName . ' ' . $lastName));
                   $mailer->isHTML(true);
                   $mailer->Subject = 'Confirmare comanda ' . $ref;

                   $rowsHtml = '';
                   foreach ($cartItems as $ci) {
                       $lineTotal = number_format($ci['price_final'] * $ci['quantity'], 2, ',', '.');
                       $priceEach = number_format($ci['price_final'], 2, ',', '.');
                       $rowsHtml .= '<tr>'
                           . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($ci['name']) . '</td>'
                           . '<td style="padding:8px;border:1px solid #ddd; text-align:center;">' . (int)$ci['quantity'] . '</td>'
                           . '<td style="padding:8px;border:1px solid #ddd; text-align:right;">' . $priceEach . ' lei</td>'
                           . '<td style="padding:8px;border:1px solid #ddd; text-align:right;">' . $lineTotal . ' lei</td>'
                           . '</tr>';
                   }

                   $shippingCostFmt = number_format($shippingCost, 2, ',', '.');
                   $totalProductsFmt = number_format($totalPayment, 2, ',', '.');
                   $grandTotalFmt = number_format($totalPaymentWithShipping, 2, ',', '.');
                   $addressHtml = nl2br(htmlspecialchars($streetNorm . "\n" . $cityNorm . ", " . $countyNorm . " " . $postalNorm . "\n" . $countryNorm));

                   $body = '<div style="font-family:Arial,Helvetica,sans-serif; font-size:14px; color:#222;">'
                     . '<h2 style="margin:0 0 10px;">Multumim pentru comanda ta!</h2>'
                     . '<p>Buna, ' . htmlspecialchars($firstName) . ' ' . htmlspecialchars($lastName) . '.</p>'
                     . '<p>Comanda ta a fost inregistrata cu referinta <strong>' . htmlspecialchars($ref) . '</strong>.</p>'
                     . '<h3 style="margin:18px 0 8px;">Sumar comanda</h3>'
                     . '<table style="border-collapse:collapse; width:100%; max-width:640px;">'
                     . '<thead>'
                     . '<tr>'
                     . '<th style="padding:8px;border:1px solid #ddd; text-align:left;">Produs</th>'
                     . '<th style="padding:8px;border:1px solid #ddd; text-align:center;">Cantitate</th>'
                     . '<th style="padding:8px;border:1px solid #ddd; text-align:right;">Pret</th>'
                     . '<th style="padding:8px;border:1px solid #ddd; text-align:right;">Subtotal</th>'
                     . '</tr>'
                     . '</thead>'
                     . '<tbody>' . $rowsHtml . '</tbody>'
                     . '<tfoot>'
                     . '<tr>'
                     . '<td colspan="3" style="padding:8px;border:1px solid #ddd; text-align:right;"><strong>Total produse</strong></td>'
                     . '<td style="padding:8px;border:1px solid #ddd; text-align:right;"><strong>' . $totalProductsFmt . ' lei</strong></td>'
                     . '</tr>'
                     . '<tr>'
                     . '<td colspan="3" style="padding:8px;border:1px solid #ddd; text-align:right;">Livrare</td>'
                     . '<td style="padding:8px;border:1px solid #ddd; text-align:right;">' . $shippingCostFmt . ' lei</td>'
                     . '</tr>'
                     . '<tr>'
                     . '<td colspan="3" style="padding:8px;border:1px solid #ddd; text-align:right;"><strong>Total de plata</strong></td>'
                     . '<td style="padding:8px;border:1px solid #ddd; text-align:right;"><strong>' . $grandTotalFmt . ' lei</strong></td>'
                     . '</tr>'
                     . '</tfoot>'
                     . '</table>'
                     . '<h3 style="margin:18px 0 8px;">Adresa de livrare</h3>'
                     . '<p style="white-space:pre-line;">' . $addressHtml . '</p>'
                     . '<p style="margin-top:18px;">Poti urmari detaliile comenzii aici: '
                     . '<a href="' . htmlspecialchars('confirmare-comanda.php?order_id=' . $orderId) . '">confirmare-comanda</a></p>'
                     . '<p>Daca ai intrebari, raspunde la acest email.</p>'
                     . '</div>';

                   $mailer->Body = $body;
                   $mailer->AltBody = 'Comanda ' . $ref . " total: " . $grandTotalFmt . ' lei';
                   $mailer->send();
               } catch (\Throwable $mailErr) {
                   // optional: log
               }

               unset($_SESSION['cart_id']);

               $response = [
                       'status' => 'success',
                       'redirect' => 'confirmare-comanda.php?order_id=' . $orderId
               ];
               die(json_encode($response));
                
   
           } catch (Exception $e) {
               $conn->rollback();
               $response = ['status' => 'error', 'message' => 'Nu am putut efectua comanda: ' . $e->getMessage()];
               die(json_encode($response));
           }
       } else {
           $response = ['status' => 'empty', 'message' => 'Coșul tău este gol!'];
           die(json_encode($response));
       }
   }
   
   
   
   ?>
<?php 
   include 'header.php';
   ?>
<div class="container my-5">
   <h2 class="mb-4 text-center fw-bold">Finalizează Comanda</h2>
   <div class="row">
      <div class="col-lg-8">
         <?php if (!$customer): ?>
         <div class="alert alert-info">
            Ai deja cont? <a href="autentificare.php?finalizare=checkout.php" class="alert-link">Conectează-te aici</a>
         </div>
         <?php endif; ?>
         <form method="POST" id="checkout-form">
            <div class="checkout-step bg-white p-4 shadow-sm rounded mb-3">
               <h4>1. Date de Livrare</h4>
               <div class="row g-3">
                  <div class="col-md-6">
                     <label class="form-label">CUI</label>
                     <input type="text" name="tax_id" id="cui" class="form-control"
                        value="<?= $addresses[0]['tax_id'] ?? '' ?>">
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Nume Companie</label>
                     <input type="text" id="company_name" name="company_name" class="form-control" readonly>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Nr. Inregistrare</label>
                     <input type="text" id="reg_com" name="reg_com" class="form-control" readonly>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Prenume</label>
                     <input type="text" name="first_name" class="form-control"
                        value="<?= $customer['first_name'] ?? '' ?>" required>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Nume</label>
                     <input type="text" name="last_name" class="form-control"
                        value="<?= $customer['last_name'] ?? '' ?>" required>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Email</label>
                     <input type="email" name="email" class="form-control"
                        value="<?= $customer['email'] ?? '' ?>" required>
                  </div>
                  <div class="col-md-12">
                     <label class="form-label">Adresă</label>
                     <input type="text" id="street_address" name="address" class="form-control"
                        value="<?= $addresses[0]['street_address'] ?? '' ?>" required>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Localitate</label>
                     <select name="city" id="city" class="form-select" required>
                        <option value="<?= $selectedCity ?>"><?= $selectedCity ?: 'Selectează oraș' ?></option>
                     </select>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Județ</label>
                     <select name="county" id="county" class="form-select" required>
                        <option value="">Selectează județ</option>
                        <?php foreach ($judete as $row) { ?>
                        <option value="<?= $row['judet'] ?>" 
                           <?= ($row['judet'] == $selectedCounty) ? 'selected' : '' ?>>
                           <?= $row['judet'] ?>
                        </option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="col-md-6">
                     <label class="form-label">Cod Poștal</label>
                     <input type="text" id="postal_code" name="postal_code" class="form-control"
                        value="<?= $addresses[0]['postal_code'] ?? '' ?>">
                  </div>
               </div>
            </div>
            <div class="checkout-step bg-white p-4 shadow-sm rounded mb-3">
               <h4>2. Metoda de Livrare</h4>
               <?php foreach ($shippings as $shipping){ ?>
               <div class="form-check">
                  <input class="form-check-input" type="radio" name="shipping" value="<?= $shipping['shipping_id'] ?>" data-cost="<?=number_format($shipping['cost'],2,'.','')?>" required>
                  <label class="form-check-label">
                  <?= $shipping['name'] ?> - <?= number_format($shipping['cost'],2,',','.') ?> lei
                  </label>
               </div>
               <?php } ?>
            </div>
            <div class="checkout-step bg-white p-4 shadow-sm rounded mb-3">
               <h4>3. Metoda de Plată</h4>
               <?php foreach ($payments as $payment){ ?>
               <div class="form-check">
                  <input class="form-check-input" type="radio" name="payment" value="<?= $payment['payment_id'] ?>" required>
                  <label class="form-check-label">
                  <?= $payment['name'] ?> (<?= $payment['description'] ?>)
                  </label>
               </div>
               <?php }?>
            </div>
            <button type="submit" name="finalizeaza" class="btn btn-success w-100 ">Plasează Comanda</button>
         </form>
      </div>
      <div class="col-lg-4">
         <div class="bg-light p-4 rounded shadow-sm">
            <h5>Sumar Comandă</h5>
            <ul class="list-group mb-3">
               <?php foreach ($cartItems as $item){ ?>
               <li class="list-group-item d-flex justify-content-between">
                  <?= $item['name'] ?> x<?= $item['quantity'] ?>
                  <span><?= number_format($item['price_final'] * $item['quantity'],2) ?> lei</span>
               </li>
               <?php } ?>
               <li class="list-group-item d-flex justify-content-between">
                  <span><strong>Total Produse</strong></span>
                  <strong id="totalProducts" data-value="<?= number_format($totalPayment,2,'.','')?>">
                  <?=number_format($totalPayment,2,',','.')?> lei
                  </strong>
               </li>
               <li class="list-group-item d-flex justify-content-between">
                  <span><strong>Livrare</strong></span>
                  <strong id="shippingCost" data-value="0">0,00 lei</strong>
               </li>
               <li class="list-group-item d-flex justify-content-between">
                  <span><strong>Total</strong></span>
                  <strong class="text-danger" id="grandTotal">
                  <?= number_format($totalPayment, 2, ',', '.') ?> lei
                  </strong>
               </li>
            </ul>
            <input type="hidden" name="shipping_price" id="shipping_price" value="0">
            <input type="hidden" name="grand_total" id="grand_total" value="<?= number_format($totalPayment, 2, '.', '') ?>">
         </div>
      </div>
   </div>
</div>
<?php 
   include 'footer.php';
   ?>
<script>
   $(document).ready(function() {
       $("#checkout-form").on("submit", function(e){
           e.preventDefault();
           $.ajax({
               type: "POST",
               dataType: "json",
               data: $(this).serialize() + "&finalizeaza=1",
               success: function(result) {
                   if (result.status === "success") {
                       //$.growl.notice({ title: "Succes", message: result.message });
                       window.location.href = result.redirect;
                   } else if (result.status === "empty") {
                       $.growl.warning({ title: "", message: result.message });
                   } else {
                       $.growl.error({ title: "Eroare", message: result.message });
                   }
               },
               error: function(xhr) {
                   $.growl.error({ title: "Eroare", message: xhr.responseText });
               }
           });
       });
   
       var localitati = <?php echo json_encode($localitatiData); ?>;
   
       
       var selectedCountry = "<?= $addresses[0]['country'] ?? 'Romania' ?>";
       var selectedCounty  = "<?= $addresses[0]['county'] ?? '' ?>";
       var selectedCity    = "<?= $addresses[0]['city'] ?? '' ?>";
   
       $('#country').val(selectedCountry).trigger('change');
   
       
       if(selectedCountry === 'Romania'){
           $('#county').prop('disabled', false);
   
           
           $('#county').val(selectedCounty).trigger('change');
       }
   
       
       $('#county').change(function(){
           var judet = $(this).val();
           if(judet && localitati[judet]){
               var opt = '<option value="">Selectează oraș</option>';
               $.each(localitati[judet], function(i, oras){
                   var sel = (oras === selectedCity) ? 'selected' : '';
                   opt += '<option value="'+oras+'" '+sel+'>'+oras+'</option>';
               });
               $('#city').html(opt).prop('disabled', false);
           } else {
               $('#city').prop('disabled', true).html('<option value="">Selectează oraș</option>');
           }
       });
   
       
       $('#county').trigger('change');
   
   
    function removeDiacritics(str) {
       return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
   }
   
   function capitalizeWords(str) {
       return str.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
   }
   
   
       $("#cui").on("focusout",function(){
           const cui=$(this).val().trim();
           if(cui.length>0){
               $.ajax({
                   url:'anaf.php',
                   type:"POST",
                   data:{cui:cui},
                   dataType:"json",
                   success:function(response){
                       console.log("Răspuns ANAF:", response);
                       if(response.success){
                           $("#company_name").val(response.data.denumire);
                           $("#reg_com").val(response.data.nrRegCom);
                           $("#street_address").val(response.data.sdenumire_Strada);
                           $('#postal_code').val(response.data.scod_Postal);
   
                           console.log("Setez judet:", response.data.sdenumire_Judet);
                           console.log("Setez oras:", response.data.sdenumire_Localitate);
                           let rawJudet = response.data.sdenumire_Judet.trim();
                           let judetFaraDiacritice = removeDiacritics(rawJudet.toUpperCase());
                           let judetFinal = "";
   
                           if (judetFaraDiacritice === "MUNICIPIUL BUCURESTI") {
                               judetFinal = "Bucuresti";
                           } else if (judetFaraDiacritice === "BISTRITA-NASAUD" || judetFaraDiacritice === "BISTRITA NASAUD") {
                               judetFinal = "Bistrita-Nasaud";
                           } else if (judetFaraDiacritice === "CARAS-SEVERIN" || judetFaraDiacritice === "CARAS SEVERIN") {
                               judetFinal = "Caras-Severin";
                           } else {
                               judetFinal = capitalizeWords(removeDiacritics(rawJudet.toLowerCase()));
                           }       
   
                       $("#county").val(judetFinal).trigger('change');
                       console.log("Setez judet:", judetFinal);
   
                       
                       let rawOras = response.data.sdenumire_Localitate.trim();
                       let parts = rawOras.split('.');
                       let orasFinal = parts[parts.length - 1].trim();
                       orasFinal = capitalizeWords(removeDiacritics(orasFinal.toLowerCase()));
   
                       setTimeout(function () {
                           $("#city").val(orasFinal);
                           console.log("Setez oras:", orasFinal);
                       }, 300);
                       }else{
                           alert("CUI invalid sau comapnia nu a fost gasita");
                       }
                   },
                   error:function(){
                       alert("eroare la conectarea cu ANAF");
                   }
               });
           }
       });
   

     function roMoney(n){
  
       return Number(n).toLocaleString('ro-RO', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' lei';
     }
   
     function updateTotals(){
       var base = parseFloat($('#totalProducts').data('value') || '0');
       var ship = 0;
   
       var $checked = $('input[name="shipping"]:checked');
       if($checked.length){
         ship = parseFloat($checked.data('cost') || '0');
       }
   
       $('#shippingCost').data('value', ship.toFixed(2))
                         .text(roMoney(ship));
   
       var total = base + ship;
       $('#grandTotal').text(roMoney(total));
   
      
       $('#shipping_price').val(ship.toFixed(2));
       $('#grand_total').val(total.toFixed(2));
     }
   
    
     updateTotals();
     $(document).on('change', 'input[name="shipping"]', updateTotals);
   
   });
</script>