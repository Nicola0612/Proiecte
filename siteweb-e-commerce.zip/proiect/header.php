<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$menuCats = $conn->query("
    SELECT category_id, name
    FROM categories
    ORDER BY name ASC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link href="/proiect/jquery.growl/stylesheets/jquery.growl.css" rel="stylesheet" />
    <link rel="stylesheet" href="stil.css">

    <title>Magazin</title>
</head>
<body>
<header class="p-3 text-bg-dark">
         <div class="container">
            <img src="img/logo.png" alt="mdo" width="100" height="100" class="rounded-circle me-6"> 
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
               <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                  <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap">
                     <use xlink:href="#bootstrap"></use>
                  </svg>
               </a>
               <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                  <li>
                     <a href="index.php" class="nav-link px-2 text-secondary ms-4">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle text-white" href="#" id="produseDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                     Produse
                     </a>
                     <!-- <ul class="dropdown-menu dropdown-menu-dark p-3 shadow" aria-labelledby="produseDropdown" style="width: 300px;">
                        <li><a class="dropdown-item" href="#">Telefoane</a></li>
                        <li><a class="dropdown-item" href="#">Tablete</a></li>
                        <li><a class="dropdown-item" href="#">Gaming</a></li>
                        <li><a class="dropdown-item" href="#">Racire,purificareaer, incalzire</a></li>
                        <li><a class="dropdown-item" href="#">Electrocasnice mari</a></li>
                        <li><a class="dropdown-item" href="#">Electrocasnice mici, Vesela</a></li>
                        <li><a class="dropdown-item" href="#">Piscine</a></li>
                        <li><a class="dropdown-item" href="#">Jucarii</a></li>
                        <li><a class="dropdown-item" href="#">Bauturi</a></li>
                        <li><a class="dropdown-item" href="#">Mobilier</a></li>
                     </ul> -->
                     <ul class="dropdown-menu dropdown-menu-dark p-3 shadow" aria-labelledby="produseDropdown" style="width:300px;max-height:60vh;overflow:auto">
                        <?php foreach($menuCats as $c):?>
                           <li>
                              <a href="/proiect/categorie.php?id=<?= (int)$c['category_id']?>" class="dropdown-item">
                                 <?=htmlspecialchars($c['name'])?>
                              </a>
                           </li>
                        <?php endforeach; ?>
                     </ul>
                  </li>
                  <li><a href="#" class="nav-link px-2 text-white">Promotii</a>
                  </li>
                  <li>
                     <a href="#" class="nav-link px-2 text-white">Resigilate</a>
                  </li>
                  <!--<li>
                     <a href="#" class="nav-link px-2 text-white">Finantare</a>
                     </li>-->
                  <li class="nav-item dropdown text-white">
                     <a class="nav-link dropdown-toggle text-white" href="#" data-bs-toggle="dropdown" aria-expanded="false">Finantare</a> 
                     <ul class="dropdown-menu">
                        <li>
                           <a class="dropdown-item" href="#">Rate online Credex</a>
                        </li>
                        <li>
                           <a class="dropdown-item" href="#">Credit in magazin</a>
                        </li>
                        <li>
                           <a class="dropdown-item" href="#">Carduri de credit</a>
                        </li>
                        <li>
                           <a class="dropdown-item" href="#">Credit de nevoi personale</a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="#" class="nav-link px-2 text-white">Suport Clienti</a>
                  </li>
                  <li>
                     <a href="#" class="nav-link px-2 text-white">Magazine</a>
                  </li>
                  <li>
                     <a href="#" class="nav-link px-2 text-white">Vanzari telefonice</a>
                  </li>
               </ul>
               <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search"> 
                  <input type="search" class="form-control form-control-dark text-white" placeholder="Search..." aria-label="Search"> 
               </form>
               <div class="d-flex align-items-center gap-4">
                  <div class="dropdown">
                     <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                     <i class="bi bi-cart3 fs-4 me-2"></i>
                     <span>Coșul meu</span>
                     </a>
                     <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="cos.php">Vezi coșul</a></li>
                        <!--<li><a class="dropdown-item" href="checkout.php">Finalizare comandă</a></li>-->
                     </ul>
                  </div>
                  <div class="dropdown">
                     <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                     <i class="bi bi-person-circle fs-4 me-2"></i>
                     <span>Cont</span>
                     </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                        <?php if (isset($_SESSION['customer_id'])){ ?>
                        <li><a class="dropdown-item" href="contul_meu.php">Contul meu</a></li>
                     <li><a class="dropdown-item" href="logout_client.php">Logout</a></li>
                     <?php }else{ ?>
                           <li><a class="dropdown-item" href="autentificare.php">Autentificare</a></li>
                           <li><a class="dropdown-item" href="inregistrare.php">Înregistrare</a></li>
                     <?php } ?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>