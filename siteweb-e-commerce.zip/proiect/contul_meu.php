<?php
session_start();
require_once 'db.php';



$customerId=$_SESSION['customer_id'];
$success=$error="";

if($_SERVER['REQUEST_METHOD']==='POST'){
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $new_password=$_POST['new_password'];


    $stmt=$conn->prepare("SELECT password FROM customers WHERE customer_id=?");
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    $result=$stmt->get_result();
    $user=$result->fetch_assoc();

    if(!$user || !password_verify($password,$user['password'])){
        $error="parola incorecta";
    }else{
        if(!empty($new_password)){
            $hash=password_hash($new_password,PASSWORD_DEFAULT);
        }else{
            $hash=$user['password'];
        }

        $update=$conn->prepare("UPDATE customers SET first_name=?, last_name=?,email=?, password=? WHERE customer_id=?");
        $update->bind_param("ssssi", $first_name, $last_name, $email, $hash, $customerId);

        if($update->execute()){
    header("Location: contul_meu.php?success=info#informatii");
} else {
    header("Location: contul_meu.php?error=info#informatii");
}
exit;

    }
}
if (isset($_POST['add_address'])) {
    $stmt = $conn->prepare("
        INSERT INTO addresses (customer_id, street_address, city, county, country, postal_code, company_name, tax_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "isssssss",
        $_SESSION['customer_id'],
        $_POST['street_address'],
        $_POST['city'],
        $_POST['county'],
        $_POST['country'],
        $_POST['postal_code'],
        $_POST['company_name'],
        $_POST['tax_id']
    );
   if($stmt->execute()){
       header("Location: contul_meu.php?success=add#adrese");

    } else {
         header("Location: contul_meu.php?error=add#adrese");
    }
    exit;
}


if (isset($_POST['edit_address'])) {

    $stmt = $conn->prepare("UPDATE addresses SET street_address=?, city=?, county=?, country=?, postal_code=?, company_name=?, tax_id=?  WHERE address_id=? AND customer_id=?");

    $stmt->bind_param(
        "sssssssii",   
        $_POST['street_address'],
        $_POST['city'],
        $_POST['county'],
        $_POST['country'],
        $_POST['postal_code'],
        $_POST['company_name'],
        $_POST['tax_id'],
        $_POST['address_id'],
        $_SESSION['customer_id']
    );

   if($stmt->execute()){
       header("Location: contul_meu.php?success=edit#adrese");

    } else {
        header("Location: contul_meu.php?error=edit#adrese");

    }
    exit;
}


$judete = $conn->query("SELECT DISTINCT judet FROM ps_rc_fancourier_cities ORDER BY judet ASC");
$localitati = $conn->query("SELECT judet, localitate FROM ps_rc_fancourier_cities ORDER BY judet, localitate ASC");

$localitatiData = [];
while($row = $localitati->fetch_assoc()){
    $localitatiData[$row['judet']][] = $row['localitate'];
}


$stmt=$conn->prepare("SELECT first_name, last_name, email FROM customers WHERE customer_id=?");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$result=$stmt->get_result();
$user=$result->fetch_assoc();

$addresses = $conn->query("SELECT * FROM addresses WHERE customer_id=$customerId");

$orderQuery=$conn->prepare("
SELECT o.order_id, o.order_reference, o.created_at, o.total_products,o.total_payment,p.name as payment_name, s.name as shipping_name
FROM orders o
LEFT JOIN payments p ON o.payment_id=p.payment_id
LEFT JOIN shippings s ON o.shipping_id=s.shipping_id
WHERE o.customer_id=?
ORDER BY o.created_at DESC");
$orderQuery->bind_param("i", $customerId);
$orderQuery->execute();
$orders=$orderQuery->get_result();


?>




   <?php 
      include 'header.php';
      ?>
<div class="container mt-5">
  <div class="row">
    
    <div class="col-md-3">
      <div class="list-group" id="list-tab" role="tablist">
        <a class="list-group-item list-group-item-action active" id="list-informatii-list"
           data-bs-toggle="list" href="#informatii" role="tab">Informații cont</a>
        <a class="list-group-item list-group-item-action" id="list-comenzi-list"
           data-bs-toggle="list" href="#comenzi" role="tab">Comenzile mele</a>
        <a class="list-group-item list-group-item-action" id="list-adrese-list"
           data-bs-toggle="list" href="#adrese" role="tab">Adrese</a>
        <a class="list-group-item list-group-item-action text-danger" href="logout_client.php">Deconectare</a>
      </div>
    </div>

    
    <div class="col-md-9">
      <div class="tab-content p-4 border rounded bg-white shadow-sm" id="nav-tabContent">

       
        <div class="tab-pane fade show active" id="informatii" role="tabpanel">
          <h3>Informații Personale</h3>
          <form  method="POST" >
                    <div class="mb-3">
                        <label>Prenume</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo $user['first_name']?>">
                    </div>
                    <div class="mb-3">
                        <label>Nume de familie</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo $user['last_name']?>">
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo $user['email']?>">
                    </div>
                    <div class="mb-3">
                        <label>Parola</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Parola noua</label>
                        <input type="password" name="new_password" class="form-control" >
                    </div>
                    <button type="submit" class="btn btn-success">Salveaza</button>

                </form>

        </div>

        
        <div class="tab-pane fade" id="comenzi" role="tabpanel">
          <h3>Comenzile Mele</h3>
          <?php if($orders->num_rows >0){?>
            <div class="list-group">
              <?php while($ord=$orders->fetch_assoc()){?>
                <div class="list-group-item mb-3 shadow-sm">
                  <div class="d-flex justify-content-between">
                    <div>
                      <strong>Comanda #<?=$ord['order_reference'] ?></strong><br>
                      Data:<?=date("d.m.Y H:i", strtotime($ord['created_at'])) ?><br>
                      Produse: <?= $ord['total_products']?><br>
                      Livrare: <?= $ord['shipping_name'] ?>  Plata: <?= $ord['payment_name'] ?>

                    </div>
                    <div class="text-end">
                      <span class="badge bg-success fs-6"><?= $ord['total_payment']?> lei</span>
                     <a href="detalii.php?order_id=<?= $ord['order_id'] ?>" class="btn btn-sm btn-primary mt-2">Vezi Detalii</a>
                    </div>
                    
                  </div>
                </div>
              <?php }?>

            </div>
            <?php }else{?>
              <div class="alert alert-info">Nu ai plasat nici o comanda.</div>
              <?php }?>

           

        </div>

        
        <div class="tab-pane fade" id="adrese" role="tabpanel">
  <h3>Adrese</h3>
  <?php if($addresses->num_rows > 0){ ?>
    <?php while($adr = $addresses->fetch_assoc()){ ?>
      <div class="card mb-3">
        <div class="card-body">
          <p><strong><?= $adr['street_address'] ?></strong>, 
          <?= $adr['city'] ?>, 
          <?=$adr['county'] ?>, 
          <?= $adr['country'] ?></p>
          <p>Cod poștal: <?= $adr['postal_code'] ?></p>
          <?php if($adr['company_name']): ?>
            <p>Companie: <?= $adr['company_name'] ?> | CUI: <?=$adr['tax_id'] ?></p>
          <?php endif; ?>

         
          <button
            type="button"
            class="btn btn-sm btn-primary btn-edit"
            data-bs-toggle="modal"
            data-bs-target="#editAddressModal"
            data-id="<?= $adr['address_id']?>"
            data-street="<?= $adr['street_address']?>"
            data-country="<?= $adr['country']?>"
            data-county="<?= $adr['county']?>"
            data-city="<?= $adr['city']?>"
            data-postal="<?= $adr['postal_code']?>"
            data-company="<?= $adr['company_name']?>"
            data-cui="<?= $adr['tax_id']?>"
          >
            Editează
          </button>
        </div>
      </div>
    <?php } ?>
  <?php } else { ?>
    <p>Nu ai adrese adăugate.</p>
  <?php }?>
  <button
    type="button"
    class="btn btn-sm btn-success"
    data-bs-toggle="modal"
    data-bs-target="#addAddressModal">
    Adaugă Adresă Nouă
</button>



        

      </div>
    </div>
  </div>
</div>


<?php if(isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php if($_GET['success'] == 'edit'): ?>
            Adresa a fost actualizată cu succes!
        <?php elseif($_GET['success'] == 'add'): ?>
            Adresa a fost adăugată cu succes!
        <?php elseif($_GET['success'] == 'info'): ?>
            Datele contului au fost actualizate cu succes!
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Închide"></button>
    </div>
<?php elseif(isset($_GET['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php if($_GET['error'] == 'edit'): ?>
            Eroare la actualizarea adresei!
        <?php elseif($_GET['error'] == 'add'): ?>
            Eroare la adăugarea adresei!
        <?php elseif($_GET['error'] == 'info'): ?>
            Eroare la actualizarea datelor contului!
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Închide"></button>
    </div>
<?php endif; ?>


<div class="modal fade" id="editAddressModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Editează Adresa</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Închide"></button>
      </div>
      <div class="modal-body">
        <form method="POST" class="row g-3">
          <input type="hidden" name="edit_address" value="1">
          <input type="hidden" name="address_id" id="edit-address-id">

          <div class="col-md-6">
            <label class="form-label">Stradă și număr</label>
            <input type="text" name="street_address" id="edit-street" class="form-control" required>
          </div>

          <div class="col-md-4">
            <label class="form-label">Țara</label>
            <select name="country" id="edit-country" class="form-select" required>
              <option value="">Alege țara</option>
              <option value="Romania">România</option>
              <option value="Altele">Altele</option>
            </select>
          </div>

          <div class="col-md-4">
            <label class="form-label">Județ</label>
            <select name="county" id="edit-county" class="form-select" required>
              <option value="">Selectează județ</option>
              <?php foreach($judete as $row){ ?>
                <option value="<?= $row['judet'] ?>"><?= $row['judet'] ?></option>
              <?php } ?>
            </select>

          </div>

          <div class="col-md-4">
            <label class="form-label">Localitate</label>
            <select name="city" id="edit-city" class="form-select" required>
              <option value="">Selectează oraș</option>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label">Cod Poștal</label>
            <input type="text" name="postal_code" id="edit-postal" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Companie</label>
            <input type="text" name="company_name" id="edit-company" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">CUI</label>
            <input type="text" name="tax_id" id="edit-cui" class="form-control">
          </div>

          <div class="col-12">
            <button type="submit" class="btn btn-success">Salvează</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="addAddressModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="addModalLabel">Adaugă Adresă Nouă</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Închide"></button>
      </div>
      <div class="modal-body">
        <form method="POST" class="row g-3">
          <input type="hidden" name="add_address" value="1">

          <div class="col-md-6">
            <label class="form-label">Stradă și număr</label>
            <input type="text" name="street_address" class="form-control" required>
          </div>

          <div class="col-md-4">
            <label class="form-label">Țara</label>
            <select name="country" id="add-country" class="form-select" required>
              <option value="">Alege țara</option>
              <option value="Romania">România</option>
              <option value="Altele">Altele</option>
            </select>
          </div>

          <div class="col-md-4">
            <label class="form-label">Județ</label>
            <select name="county" id="add-county" class="form-select" required disabled>
              <option value="">Selectează județ</option>
              <?php foreach($judete as $row){ ?>
                <option value="<?php echo $row['judet']; ?>">
             <?php echo $row['judet']; ?>
              </option>
              <?php } ?>
            </select>
          </div>

          <div class="col-md-4">
            <label class="form-label">Localitate</label>
            <select name="city" id="add-city" class="form-select" required disabled>
              <option value="">Selectează oraș</option>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label">Cod Poștal</label>
            <input type="text" name="postal_code" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Companie</label>
            <input type="text" name="company_name" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">CUI</label>
            <input type="text" name="tax_id" class="form-control">
          </div>

          <div class="col-12">
            <button type="submit" class="btn btn-success">Adaugă</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
 <?php 
      include 'footer.php';
      ?>



<script>
$(document).ready(function(){
    var localitati = <?php echo json_encode($localitatiData); ?>;

   
    $('#edit-country').change(function(){
        if($(this).val() === 'Romania'){
            $('#edit-county').prop('disabled', false);
        } else {
            $('#edit-county').prop('disabled', true).html('<option value="">Selectează județ</option>');
            $('#edit-city').prop('disabled', true).html('<option value="">Selectează oraș</option>');
        }
    });

    
    $('#edit-county').change(function(){
        var judet = $(this).val();
        if(judet && localitati[judet]){
            var opt = '<option value="">Selectează oraș</option>';
            $.each(localitati[judet], function(i, oras){
                opt += '<option value="'+oras+'">'+oras+'</option>';
            });
            $('#edit-city').html(opt).prop('disabled', false);
        } else {
            $('#edit-city').prop('disabled', true).html('<option value="">Selectează oraș</option>');
        }
    });


    $('.btn-edit').on('click', function() {
        $('#edit-address-id').val($(this).data('id'));
        $('#edit-street').val($(this).data('street'));
        $('#edit-country').val($(this).data('country')).trigger('change');

        var county = $(this).data('county');
        var city = $(this).data('city');

       
        $('#edit-county').val(county).trigger('change');

      
        setTimeout(function(){
            $('#edit-city').val(city);
        }, 300);

        $('#edit-postal').val($(this).data('postal'));
        $('#edit-company').val($(this).data('company'));
        $('#edit-cui').val($(this).data('cui'));
    });
});


$(document).ready(function(){
    var localitati = <?php echo json_encode($localitatiData); ?>;

    $('#add-country').change(function(){
        if($(this).val() === 'Romania'){
            $('#add-county').prop('disabled', false);
        }
    });

    $('#add-county').change(function(){
        var judet = $(this).val();
        if(judet && localitati[judet]){
            var opt = '<option value="">Selectează oraș</option>';
            $.each(localitati[judet], function(i, oras){
                opt += '<option value="'+oras+'">'+oras+'</option>';
            });
            $('#add-city').html(opt).prop('disabled', false);
        } else {
            $('#add-city').prop('disabled', true).html('<option value="">Selectează oraș</option>');
        }
    });
});

$(document).ready(function() {
    const hash = window.location.hash;
    if (hash) {
        $('a[href="' + hash + '"]').tab('show');
    }
});

</script>


