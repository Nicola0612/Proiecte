<?php require_once 'db.php';
 if(isset($_GET['id'])){
    $product_id=intval($_GET['id']);

    $stmt=$conn->prepare("SELECT * FROM products WHERE product_id= ? ");
    $stmt->bind_param("i",$product_id);
    $stmt->execute();
    $res=$stmt->get_result();
    $product=$res->fetch_assoc();

    if(!$product){
        echo "produsul nu a fost gasit";
        exit;
    }

 }else{
    echo "invalid";
    exit;
 }
?>


       <?php 
      include 'header.php';
      ?>
    <main>
<div class="container mt-5">
  <div class="row">
    
    <div class="col-md-5">
      <img src="img/<?php echo $product['image_url']; ?>" class="img-fluid rounded" alt="Combina Gorenje">
    </div>

  
    <div class="col-md-7">
      <h1 class="h4 fw-bold"><?php echo $product['name']; ?></h1>
      <p><?php echo $product['description']; ?></p>
      <p><strong>Brand:</strong><?php echo $product['brand']; ?></p>

<!--       
      <div class="d-flex align-items-center mb-2">
        <div class="text-warning me-2">
          <i class="bi bi-star-fill"></i>
          <i class="bi bi-star-fill"></i>
          <i class="bi bi-star-fill"></i>
          <i class="bi bi-star-half"></i>
          <i class="bi bi-star"></i>
        </div>
        <small class="text-muted">3.4 din 5 (5 recenzii)</small>
      </div> -->
      <?php 
        $pret_initial=$product['price'];
        $discount=$product['discount'];
        $pret_final=$pret_initial;
        


        if($discount>0){
            $pret_final=$pret_initial-($pret_initial*$discount/100);
            echo "<p class='text-muted text-decoration-line-through'>". number_format($pret_initial,2) . "lei</p>";
            echo "<p class='text-danger fw-bold fs-4'>". number_format($pret_final,2) ." lei (-{$discount}%)</p>";
         } else {
            echo "<p class='text-black fw-bold fs-4'>{$pret_initial} lei</p>";
        }
        $garantie = [
         '1_an' => round($pret_final * 0.07, 2),
         '2_ani' => round($pret_final * 0.11, 2),
         '3_ani' => round($pret_final * 0.15, 2)
         ];
      ?>
      <div class="d-grid gap-2 col-md-6 col-8">
        <button class="btn btn-danger btn-lg"><i class="bi bi-cart-plus me-2"></i>Adaugă în coș</button>
      </div>
    </div>
  </div>
</div>


<div class="container my-5">
  <div class="row row-cols-1 row-cols-md-3 g-3">
    
    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body text-center">
          <i class="bi bi-truck display-6 text-success mb-2"></i>
          <h6 class="card-title fw-semibold">Livrare gratuită</h6>
          <p class="card-text small text-secondary">Rapid în 24-48h.</p>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body text-center">
          <i class="bi bi-arrow-counterclockwise display-6 text-primary mb-2"></i>
          <h6 class="card-title fw-semibold">Retur în 14 zile</h6>
          <p class="card-text small text-secondary">Fără griji, fără costuri suplimentare.</p>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body text-center">
          <i class="bi bi-shield-check display-6 text-warning mb-2"></i>
          <h6 class="card-title fw-semibold">Garanție 24 luni</h6>
          <p class="card-text small text-secondary">Acoperire completă pentru orice defect.</p>
        </div>
      </div>
    </div>

  </div>
</div>


<div class="container my-5">
  <h4 class="mb-4">Adaugă servicii opționale</h4>
  <div class="row g-4">
    <div class="col-md-6">
      <div class="border rounded p-4 bg-light">
        <h6 class="fw-bold mb-3"><i class="bi bi-shield-check text-primary me-2"></i>Garanție extinsă</h6>

        <div class="form-check mb-2">
          <input class="form-check-input" type="radio" name="garantie" id="gar1" value="1">
          <label class="form-check-label" for="gar1">
            1 an (+<?= $garantie['1_an'] ?> lei)
          </label>
        </div>
        <div class="form-check mb-2">
          <input class="form-check-input" type="radio" name="garantie" id="gar2" value="2">
          <label class="form-check-label" for="gar2">
            2 ani (+<?= $garantie['2_ani'] ?> lei)
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="garantie" id="gar3" value="3">
          <label class="form-check-label" for="gar3">
            3 ani (+<?= $garantie['3_ani'] ?> lei)
          </label>
        </div>
      </div>
    </div>

  </div>
</div>


    </main>

    <?php 
      include 'footer.php';
      ?>
