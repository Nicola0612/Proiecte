<?php
session_start();
require_once 'db.php';
if(!isset($_GET['order_id'])){
    die("Comanda nu a fost specificata");
}
$orderID=intval($_GET['order_id']);
$customerID=$_SESSION['customer_id'];

$stmt=$conn->prepare("SELECT o.order_reference,o.created_at,o.total_products,o.total_payment,p.name as payment_name, s.name as shipping_name,a.street_address, a.city, a.county,a.country,a.postal_code
FROM orders o
LEFT JOIN payments p ON o.payment_id=p.payment_id
LEFT JOIN shippings s ON o.shipping_id=s.shipping_id
LEFT JOIN addresses a ON o.address_id=a.address_id
WHERE o.order_id=? AND o.customer_id=?");

$stmt->bind_param("ii",$orderID,$customerID);
$stmt->execute();
$order=$stmt->get_result()->fetch_assoc();

$itemstmt=$conn->prepare("SELECT product_name,quantity,price_final
FROM order_items
WHERE order_id=?");

$itemstmt->bind_param("i", $orderID);
$itemstmt->execute();
$items=$itemstmt->get_result();

?>

<?php include 'header.php';?>

<div class="container mt-5">
    <h2>Detalii Comanda #<?= $order['order_reference']?></h2>
    <p><strong>Data:</strong><?= date("d.m.Y H:i", strtotime($order['created_at'])) ?></p>
    <p><strong>Produse:</strong> <?= $order['total_products']?></p>
    <p><strong>Plata:</strong><?= $order['payment_name']?></p>
    <p><strong>Livrare:</strong><?= $order['shipping_name']?></p>
    <p><strong>Adresa de livrare</strong>
        <?= $order['street_address'], $order['city'], $order['county'],$order['country']?>, Cod POstal: <?= $order['postal_code']?></p>
    <h4 class="mt-4">Produse comandate</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Produs</th>
                <th>Cantitate</th>
                <th>Pret Final</th>
            </tr>
        </thead>
        <tbody>
            <?php while($item=$items->fetch_assoc()){?>
                <tr>
                    <td><?= $item['product_name']?></td>
                    <td><?=$item['quantity']?></td>
                    <td><?= number_format($item['price_final'],2)?></td>
                </tr>
            <?php }?>    
        </tbody>
    </table>
    <h4 class="text-end">Total: <?= number_format($order['total_payment'],2)?> lei</h4>
    <a href="contul_meu.php#comenzi" class="btn btn-secondary mt-3 mb-3">Inapoi la comenzi</a>    
</div>


<?php include 'footer.php'; ?>
