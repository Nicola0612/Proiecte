<?php 
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['cui'])){
    $cui=(int)$_POST['cui'];
    $date=date('Y-m-d');

    $p=json_encode([
        ['cui'=> $cui, 'data'=> $date]
    ]);

    $ch=curl_init('https://webservicesp.anaf.ro/api/PlatitorTvaRest/v9/tva');
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POST,true);
    curl_setopt($ch,CURLOPT_HTTPHEADER,['Content-Type: application/json']);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$p);

    $response=curl_exec($ch);
    curl_close($ch);
    $result=json_decode($response,true);
    if(isset($result['found'][0]['date_generale'])){
        $data=$result['found'][0]['date_generale'];
        $data2=$result['found'][0]['adresa_sediu_social'];
        echo json_encode([
            'success'=>true,
            'data'=>[
                'denumire'=>$data['denumire'],
                'nrRegCom'=>$data['nrRegCom'],
                'sdenumire_Strada'=>$data2['sdenumire_Strada'] . ' ' . $data2['snumar_Strada'],
                'sdenumire_Localitate'=>$data2['sdenumire_Localitate'],
                'sdenumire_Judet'=>$data2['sdenumire_Judet'],
                'stara'=>$data2['stara'],
                'scod_Postal'=>$data2['scod_Postal']
            ]
            ]);
    }else{
        echo json_encode(['success'=>false,'error'=>'Compania nu a fost gasita']);
    }


}


?>