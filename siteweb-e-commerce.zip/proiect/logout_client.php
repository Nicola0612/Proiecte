<?php
   session_start();

   // if(session_destroy()) {
   //    header("Location: index.php");
   // }
   unset($_SESSION['customer_id']);
unset($_SESSION['cart_id']);

header("Location: index.php");
exit;
?>