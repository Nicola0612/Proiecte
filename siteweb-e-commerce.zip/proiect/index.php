<?php 
   session_start();
   include 'db.php';
   
   
   if (isset($_SESSION['customer_id'])) {
     
   } else {
     
      if (!isset($_SESSION['guest_id'])) {
          $stmt = $conn->prepare("INSERT INTO guest (created_at) VALUES (NOW())");
          $stmt->execute();
          $_SESSION['guest_id'] = $stmt->insert_id;
      }
   }
   
   
   if (isset($_POST['action']) && $_POST['action'] == 'addToCart') {
     $producId=intval($_POST['idProduct']);
     $customerId=isset($_SESSION['customer_id'])? $_SESSION['customer_id']: null;
      $guestId = isset($_SESSION['guest_id']) ? $_SESSION['guest_id'] : null;
     if(!isset($_SESSION['cart_id'])){
        if($customerId){
           $stmt=$conn->prepare("INSERT INTO shopping_cart(customer_id) VALUES (?)");
           $stmt->bind_param("i",$customerId);
        }else{
           $stmt = $conn->prepare("INSERT INTO shopping_cart (customer_id, guest_id, created_at, updated_at) VALUES (NULL, ?, NOW(), NOW())");
              $stmt->bind_param("i", $guestId);
        }
   
        $stmt->execute();
        $_SESSION['cart_id']=$stmt->insert_id;
     }
     $cartId=$_SESSION['cart_id'];
   
     $check=$conn->prepare("SELECT quantity FROM cart_items WHERE cart_id=? AND product_id=?");
     $check->bind_param("ii",$cartId,$producId);
     $check->execute();
     $res=$check->get_result();
   
     if($res->num_rows>0){
        $row=$res->fetch_assoc();
        $new=$row['quantity']+1;
        $update=$conn->prepare("UPDATE cart_items SET quantity=? WHERE cart_id=? AND product_id=?");
        $update->bind_param("iii",$new,$cartId,$producId);
        $update->execute();
     }else{
        $cant=1;
        $insert=$conn->prepare("INSERT INTO cart_items(cart_id, product_id,quantity) VALUES (?,?,?)");
        $insert->bind_param("iii", $cartId,$producId, $cant);
        if (!$insert->execute()) {
             
              $del = $conn->prepare("DELETE FROM shopping_cart WHERE cart_id=?");
              $del->bind_param("i", $cartId);
              $del->execute();
              unset($_SESSION['cart_id']);
              
              $response = ['isError' => true, 'message' => 'Nu am putut adăuga produsul în coș!'];
              die(json_encode($response));
          }
     }
   
   
   
     $response = [
        'isError' => false,
        'message' => 'Produsul a fost adaugat in cos'
     ];
   
     die(json_encode($response));
     exit;
   
   }
   $guestId = $_SESSION['guest_id'] ?? null;
   $customerId = $_SESSION['customer_id'] ?? null;
   $cartId = $_SESSION['cart_id'] ?? null;
   ?>
<?php 
   include 'header.php';
   ?>
<!-- <div class="container my-4">
   <div style="position:absolute; top:200px;left:20px;width:220px;z-index:1000;">
      <div class="card shadow-sm">
         <div class="card-header bg-dark text-white p-2" style="font-size: 14px;">
            Informatii Utilizator & Cos
         </div>
         <div class="card-body p-2" style="font-size: 14px;">
            <p><strong>ID Guest:</strong> 
               <?= $guestId ? $guestId : '<span class="text-muted">null</span>'; ?>
            </p>
            <p><strong>ID Customer:</strong> 
               <?= $customerId ? $customerId : '<span class="text-muted">null</span>'; ?>
            </p>
            <p><strong>ID Cos:</strong> 
               <?= $cartId ? $cartId : '<span class="text-muted">null</span>'; ?>
            </p>
         </div>
      </div>
   </div>
</div> -->
<div class="container">
   <h4 class="mb-3"> Cauta produse</h4>
   <form class="row g-4 allig-items-end">
      <div class="col-md-3">
         <label for="categorie" class="form-label">Categorie</label>
         <select class="form-select" aria-label="Default select example">
            <option selected>Categorie</option>
            <option value="1">Telefon</option>
            <option value="2">Laptop</option>
            <option value="3">Gaming</option>
            <option value="4">Tableta</option>
            <option value="5">Aspirator</option>
         </select>
      </div>
      <div class="col-md-2">
         <label for="pretMin" class="form-label">Preț minim</label>
         <input type="number" class="form-control" id="pretMin" placeholder="0">
      </div>
      <div class="col-md-2">
         <label for="pretMin" class="form-label">Preț maxim</label>
         <input type="number" class="form-control" id="pretMin" placeholder="999999">
      </div>
      <div class="col-md-3">
         <label for="brand" class="form-label">Brand</label>
         <select class="form-select" aria-label="Default select example">
            <option value="1">Apple</option>
            <option value="2">Samsung</option>
            <option value="3">Asus</option>
            <option value="4">Acer</option>
            <option value="5">Dyson</option>
         </select>
      </div>
      <div class="col-md-2  align-self-end">
         <button type="submit" class="btn btn-primary mb-3">Cauta</button>
      </div>
   </form>
</div>
<div class="container">
   <div class="row text-center py-4">
      <div class="col-12 col-sm-6 col-lg-4 mb-4">
         <div class="box_cms p-3 h-100">
            <div class="img-wrapper mt-4 mb-3">
               <img src="img/300x300.svg" data-src="img/Garantie premium.png" alt="Garanție Premium" class="img-fluid lazy" style="max-height: 80px;">
            </div>
            <div class="txt_cms">
               <h2>Garanție Premium</h2>
               <p>Transport gratuit tur-retur prin curier pentru efectuarea service-ului</p>
            </div>
         </div>
      </div>
      <div class="col-12 col-sm-6 col-lg-4 mb-4">
         <div class="box_cms p-3 h-100">
            <div class="img-wrapper mt-4 mb-3">
               <i class="fa-solid fa-car fa-3x"></i>
            </div>
            <div class="txt_cms">
               <h2>Transport Gratuit</h2>
               <p>Transport gratuit pentru comenzile mai mari de 250 Lei și livrare în 1-2 zile lucrătoare</p>
            </div>
         </div>
      </div>
      <div class="col-12 col-sm-6 col-lg-4 mb-4">
         <div class="box_cms p-3 h-100">
            <div class="img-wrapper mt-4 mb-3">
               <img src="img/300x300.svg" data-src="img/Clienti multumiti.png" alt="Clienți mulțumiți" class="img-fluid lazy" style="max-height: 80px;">
            </div>
            <div class="txt_cms">
               <h2>Peste 300.000 de Clienți Mulțumiți</h2>
               <p>Orice produs poate fi returnat în termen de 15 zile</p>
            </div>
         </div>
      </div>
   </div>
</div>
<div id="carouselExampleIndicators" class="carousel slide">
   <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
   </div>
   <div class="carousel-inner">
      <div class="carousel-item active">
         <img src="img/300x300.svg" data-src="img/imagine1.png" class="d-block w-100 lazy" alt="ceva">
      </div>
      <div class="carousel-item">
         <img src="img/300x300.svg" data-src="img/imagine2.png" class="d-block w-100 lazy" alt="ceva2">
      </div>
      <div class="carousel-item">
         <img src="img/300x300.svg" data-src="img/imagine3.png" class="d-block w-100 lazy" alt="ceva3">
      </div>
   </div>
   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="visually-hidden">Previous</span>
   </button>
   <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="visually-hidden">Next</span>
   </button>
</div>
<div class="container mb-5">
   <h2 class="mb-3">Caută rapid</h2>
   <div class="row text-center">
      <div class="col">
         <i class="bi bi-phone h1"></i>
         <p>Telefoane</p>
      </div>
      <div class="col">
         <i class="bi bi-laptop h1"></i>
         <p>Laptopuri</p>
      </div>
      <div class="col">
         <i class="bi bi-tv h1"></i>
         <p>TV</p>
      </div>
      <div class="col">
         <i class="bi bi-cart h1"></i>
         <p>Electrocasnice</p>
      </div>
   </div>
</div>
</div>
<div class="container mb-5">
   <h2 class="mb-4 fw-bold"> Top Oferte</h2>
   <div class="row row-cols-2 row-cols-md-4 g-4 mobile-grid">
      <?php 
         $products1 = Product::getDiscountProducts();
            if ($products1) {
                foreach ($products1 as $product) { 
                  if($product['active']==1){
               ?>
      <div class="col">
         <div class="card h-100 d-flex flex-column">
            <span class="position-absolute top-0 end-0 bg-warning text-dark px-2 py-1 small fw-bold rounded-start">
            -<?php echo $product['discount']; ?>%
            </span>
            <img src="img/300x300.svg" data-src="img/Garantie premium.png" class="card-img-top lazy" alt="tableta">
            <div class="card-body text-start d-flex flex-column">
               <a href="produs.php?id=<?php echo $product['product_id']; ?>">
               <?php echo $product['name']; ?>
               </a>
               <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
               <p class="text-secondary text-decoration-line-through mb-0"><?php echo $product['price']; ?> lei</p>
               <p class="text-danger fw-bold fs-5"><?php echo $reduced=$product['price']-($product['price']*$product['discount']/100) ?> lei</p>
               <div class="mt-auto">
                  <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
               </div>
            </div>
         </div>
      </div>
      <?php   
         } }}
         
         
         ?>
   </div>
</div>
<div class="container my-5">
   <ul class="nav nav-tabs" id="tabProduse" role="tablist">
      <li class="nav-item" role="presentation">
         <button class="nav-link active" id="piscine-tab" data-bs-toggle="tab" data-bs-target="#piscine" type="button" role="tab">Piscine</button>
      </li>
      <li class="nav-item" role="presentation">
         <button class="nav-link" id="jucarii-tab" data-bs-toggle="tab" data-bs-target="#jucarii" type="button" role="tab">Jucării pentru plajă</button>
      </li>
      <li class="nav-item" role="presentation">
         <button class="nav-link" id="bauturi-tab" data-bs-toggle="tab" data-bs-target="#bauturi" type="button" role="tab">Băuturi răcoritoare</button>
      </li>
   </ul>
   <div class="tab-content pt-3">
      <div class="tab-pane fade show active" id="piscine" role="tabpanel">
         <div class="row row-cols-2 row-cols-md-4 g-4 mobile-grid">
            <?php 
               $products2=Product::getProductsByCategory(6);
                  if ($products2) {
                      foreach ($products2 as $product) { 
                         if($product['discount'] >0){
                           if($product['active']==1){?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <span class="position-absolute top-0 end-0 bg-warning text-dark px-2 py-1 small fw-bold rounded-start">
                  -<?php echo $product['discount']; ?>%
                  </span>
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top lazy" alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-secondary text-decoration-line-through mb-0"><?php echo $product['price']; ?> lei</p>
                     <p class="text-danger fw-bold fs-5"><?php echo $reduced=$product['price']-($product['price']*$product['discount']/100) ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php }}else{
               if($product['active']==1){?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top lazy" alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-black fs-5"><?php echo $product['price']; ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php   }
               }}
               }
               ?>
         </div>
      </div>
      <div class="tab-pane fade" id="jucarii" role="tabpanel">
         <div class="row row-cols-2 row-cols-md-4 g-4 mobile-grid">
            <?php 
               $products3=Product::getProductsByCategory(7);
                  if ($products3) {
                      foreach ($products3 as $product) { 
                       if($product['active']==1){
                         if($product['discount'] >0){?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <span class="position-absolute top-0 end-0 bg-warning text-dark px-2 py-1 small fw-bold rounded-start">
                  -<?php echo $product['discount']; ?>%
                  </span>
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top lazy" alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-secondary text-decoration-line-through mb-0"><?php echo $product['price']; ?> lei</p>
                     <p class="text-danger fw-bold fs-5"><?php echo $reduced=$product['price']-($product['price']*$product['discount']/100) ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php }else{?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top lazy" alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-black fs-5"><?php echo $product['price']; ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php   
               }} }}
               
               
               ?>
         </div>
      </div>
      <div class="tab-pane fade" id="bauturi" role="tabpanel">
         <div class="row row-cols-2 row-cols-md-4 g-4 mobile-grid">
            <?php 
               $products4=Product::getProductsByCategory(8);
                  if ($products4) {
                      foreach ($products4 as $product) { 
                        if($product['active']==1){
                         if($product['discount'] >0){?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <span class="position-absolute top-0 end-0 bg-warning text-dark px-2 py-1 small fw-bold rounded-start">
                  -<?php echo $product['discount']; ?>%
                  </span>
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top lazy" alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-secondary text-decoration-line-through mb-0"><?php echo $product['price']; ?> lei</p>
                     <p class="text-danger fw-bold fs-5"><?php echo $reduced=$product['price']-($product['price']*$product['discount']/100) ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php }else{?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <img src="img/300x300.svg" data-src="img/<?php echo $product['image_url']; ?>" class="card-img-top " alt="tableta">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?php echo $product['product_id']; ?>">
                     <?php echo $product['name']; ?>
                     </a>
                     <p class="mb-1 text-small"><i class="bi bi-check-circle-fill me-2"></i>In stoc</p>
                     <p class="text-black fs-5"><?php echo $product['price']; ?> lei</p>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?php echo $product['product_id']; ?>">Adauga in cos</button>
                     </div>
                  </div>
               </div>
            </div>
            <?php   
               }} }
               }
               
               ?>
         </div>
      </div>
   </div>
</div>
</div>
<div class="container my-5">
   <div class="p-4 rounded bg-light-yellow">
      <div class="row align-items-center">
         <div class="col-lg-7">
            <h2 class="fw-semibold">Abonează-te la newsletter și fii la curent cu cele mai noi promoții!</h2>
            <ul class="list-unstyled mt-3">
               <li><span class="text-danger me-2">&#128966</span>Afli rapid despre promoții și reduceri</li>
               <li><span class="text-danger me-2">&#128966</span>Ești informat despre ultimele tendințe tehnologice</li>
            </ul>
            <form class="d-flex mt-3 flex-column flex-sm-row">
               <input type="email" class="form-control me-sm-2 mb-2 mb-sm-0 rounded" placeholder="Introdu adresa de email" required>
               <button class="btn btn-warning fw-bold" type="submit">Înscrie-te</button>
            </form>
            <small class="d-block mt-2 text-secondary">
            Prin abonarea la newsletter confirm că am peste 18 ani și sunt de acord cu
            <strong>Termenii și condițiile</strong> de utilizare.
            </small>
         </div>
         <div class="col-lg-5 text-center mt-4 mt-lg-0">
            <img src="img/300x300.svg" data-src="img/imagine5.avif" alt="" class="img-fluid lazy" style="max-height: 250px;">
         </div>
      </div>
   </div>
</div>
</div>
</div>
<?php
   include 'footer.php';
   ?>
<?php if(isset($_GET['msg']) && $_GET['msg'] === 'success'){ ?>
<script>
   $(document).ready(function(){
      $.growl.notice({ title: "Succes", message: "Comanda a fost plasată cu succes!" });
   });
</script>
<?php } ?>
<script>
   $(document).ready(function() {
   
   
   $(".col button").click(function(e){
      let $addButton = $(this);
      $addButton.prop('disabled', true);
   
      $.ajax({
         type: 'POST',
         dataType: 'json',
         data: {
            'action': 'addToCart',
            'idProduct': $(this).data('id-produs')
         },
   
         success: function(result) {
            if (result.isError) {
              $.growl.error({ message: "EROAREEE!!!" });
            } else {
               $.growl.notice({ title:"Success",message: "Produsul a fost adaugat in cos!" });
   
            }
   
            $addButton.prop('disabled', false);
         }
   });
   });
   });
</script>