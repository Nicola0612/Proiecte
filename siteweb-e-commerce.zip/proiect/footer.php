<footer class="p-3 text-bg-dark">
         <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
               <div class="row ">
                  <div class="col-6 col-md-2 mb-3 ">
                     <h5 >Despre</h5>
                     <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Despre noi</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Marketplace</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Cariere</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Branduri disponibile</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Categorii produse</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Protectia mediului</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Vanzari corporate</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Tax free</a>
                        </li>
                     </ul>
                  </div>
                  <div class="col-6 col-md-2 mb-3">
                     <h5 >Suport clienti</h5>
                     <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Articole suport</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Returneaza produse</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Reclamatii</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Reteaua de magazine</a>
                        </li>
                     </ul>
                  </div>
                  <div class="col-6 col-md-2 mb-3">
                     <h5 >Informatii legale</h5>
                     <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Informatii privind DEEE</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Politica cookie-uri</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Protectia datelor cu caracter personal</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Securitatea datelor</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Termeni si conditii</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">Date de identificare ale societatii</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">A.N.P.C</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">A.N.P.C-SAL</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white ">ODR</a>
                        </li>
                     </ul>
                  </div>
                  <div class="col-6 col-md-2 mb-3">
                     <h5>Contact</h5>
                     <ul class="nav flex-column ">
                        <li class="nav-item mb-2 ">
                           <a href="#" class="nav-link p-0 text-white">Telefon:t</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white">Fax</a>
                        </li>
                        <li class="nav-item mb-2">
                           <a href="#" class="nav-link p-0 text-white">Formular de contact</a>
                        </li>
                     </ul>
                  </div>
                  <div class="col-md-5 offset-md-1 mb-3 text-white">
                     <form>
                        <h5>Subscribe to our newsletter</h5>
                        <p>Monthly digest of what's new and exciting from us.</p>
                        <div class="d-flex flex-column flex-sm-row w-100 gap-2"> 
                           <label for="newsletter1" class="visually-hidden">Email address</label> 
                           <input id="newsletter1" type="email" class="form-control" placeholder="Email address"> 
                           <button class="btn btn-primary" type="button">Subscribe</button> 
                        </div>
                     </form>
                  </div>
               </div>
               <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top ">
                  <p>© 2025 Company, Inc. All rights reserved.</p>
                  <ul class="list-unstyled d-flex">
                     <li class="ms-3">
                        <a class="link-body-emphasis" href="#" aria-label="Instagram">
                        <i class="fa-brands fa-instagram"></i>
                        </a>
                     </li>
                     <li class="ms-3">
                        <a class="link-body-emphasis" href="#" aria-label="Facebook">
                        <i class="fa-brands fa-facebook"></i>
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"></script>
<script src="/proiect/jquery.growl/javascripts/jquery.growl.js"></script>
<script src="/proiect/jquery.growl/javascripts/lazyload.min.js"></script>
<script>
window.lazyLoadInstance = new LazyLoad({
    elements_selector: ".lazy",
    use_native: true
});
</script>
</body>
</html>
