<?php
   require_once '../db.php';
   session_start();
   
   function recalc_order_totals(mysqli $conn, int $orderId): void {
       
       $q = $conn->prepare("
           SELECT 
               COALESCE(SUM(quantity),0)               AS total_qty,
               COALESCE(SUM(quantity*price_final),0)  AS items_total
           FROM order_items
           WHERE order_id = ?
       ");
       $q->bind_param("i", $orderId);
       $q->execute();
       $agg = $q->get_result()->fetch_assoc() ?: ['total_qty'=>0,'items_total'=>0];
   
       $totalQty   = (int)$agg['total_qty'];
       $itemsTotal = (float)$agg['items_total'];
   
     
       $s = $conn->prepare("
           SELECT IFNULL(sh.cost,0) AS shipping_cost
           FROM orders o
           LEFT JOIN shippings sh ON sh.shipping_id = o.shipping_id
           WHERE o.order_id = ?
       ");
       $s->bind_param("i", $orderId);
       $s->execute();
       $sr = $s->get_result()->fetch_assoc();
       $shipping = (float)($sr['shipping_cost'] ?? 0);
   
       $grand = $itemsTotal + $shipping;
   
       $upd = $conn->prepare("UPDATE orders SET total_products=?, total_payment=? WHERE order_id=?");
       $upd->bind_param("idi", $totalQty, $grand, $orderId);
       $upd->execute();
   }
   
   
   if (isset($_POST['edit_order_item'], $_POST['order_item_id'])) {
       $orderItemId = (int)$_POST['order_item_id'];
       $quantity    = max(1, (int)$_POST['quantity']);
       $priceFinal  = max(0, (float)$_POST['price_final']);
       $discount    = max(0, (float)$_POST['discount']);
   
       $upd = $conn->prepare("UPDATE order_items SET quantity=?, price_final=?, discount=? WHERE order_item_id=?");
       $upd->bind_param("iddi", $quantity, $priceFinal, $discount, $orderItemId);
       $upd->execute();
   
       recalc_order_totals($conn, (int)$_GET['order_id']); 
   
       header("Location: order_details.php?order_id=".(int)$_GET['order_id']);
       exit;
   }
   

   if (isset($_POST['delete_order_item'], $_POST['order_item_id'])) {
       $orderItemId = (int)$_POST['order_item_id'];

       // Fetch order, product, quantity, and payment method for the item
       $infoQ = $conn->prepare("SELECT oi.order_id, oi.product_id, oi.quantity, o.payment_id FROM order_items oi INNER JOIN orders o ON o.order_id = oi.order_id WHERE oi.order_item_id=? LIMIT 1");
       $infoQ->bind_param("i", $orderItemId);
       $infoQ->execute();
       $info = $infoQ->get_result()->fetch_assoc();

       $orderId   = $info ? (int)$info['order_id'] : 0;
       $productId = $info ? (int)$info['product_id'] : 0;
       $qty       = $info ? (int)$info['quantity'] : 0;
       $paymentId = $info ? (int)$info['payment_id'] : 0;

       // If payment is cash-on-delivery (assumed id=2), restore stock
       if ($orderId > 0 && $productId > 0 && $qty > 0 && $paymentId === 2) {
           $restock = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?");
           $restock->bind_param("ii", $qty, $productId);
           $restock->execute();
       }

       // Delete the order item
       $del = $conn->prepare("DELETE FROM order_items WHERE order_item_id=?");
       $del->bind_param("i", $orderItemId);
       $del->execute();

       if ($orderId > 0) recalc_order_totals($conn, $orderId);

       header("Location: order_details.php?order_id=".$orderId);
       exit;
   }
   
   
   $searchResults=[];
   if(isset($_POST['search_products']) && !empty($_POST['product_search'])){
       $search=trim($_POST['product_search']);
       $stmt=$conn->prepare("SELECT product_id,name, price FROM products WHERE name LIKE CONCAT('%',?,'%') ORDER BY name ASC");
       $stmt->bind_param("s",$search);
       $stmt->execute();
       $searchResults=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
   
   }
   
   if(isset($_POST['add_product_to_order']) && isset($_POST['product_id']) && isset($_POST['order_id'])){
       $orderId=(int)$_POST['order_id'];
       $productId=(int)$_POST['product_id'];
       $quantity=max(1,(int)($_POST['quantity']?? 1));
   
       $prodstmt=$conn->prepare("SELECT name, price FROM products WHERE product_id=?");
       $prodstmt->bind_param("i",$productId);
       $prodstmt->execute();
       $prod=$prodstmt->get_result()->fetch_assoc();
   
       if($prod){
           $chk = $conn->prepare("
               SELECT order_item_id, quantity, price_final 
               FROM order_items 
               WHERE order_id=? AND product_id=? LIMIT 1
           ");
           $chk->bind_param("ii", $orderId, $productId);
           $chk->execute();
           $ex = $chk->get_result()->fetch_assoc();
   
           
           $refQ = $conn->prepare("SELECT order_reference FROM orders WHERE order_id=?");
           $refQ->bind_param("i", $orderId);
           $refQ->execute();
           $refR = $refQ->get_result()->fetch_assoc();
           $reference = $refR ? $refR['order_reference'] : '';
   
           $price = (float)$prod['price'];
   
           if ($ex) {
              
               $newQty = (int)$ex['quantity'] + $quantity;
               $upd = $conn->prepare("
                   UPDATE order_items 
                   SET quantity=?, price_final=? 
                   WHERE order_item_id=? AND order_id=?
               ");
               $upd->bind_param("idii", $newQty, $price, $ex['order_item_id'], $orderId);
               $upd->execute();
   
           } else {
               
               $ins = $conn->prepare("
                   INSERT INTO order_items
                       (order_id, product_id, product_name, quantity, price_final, price_original, discount, reference, created_at)
                   VALUES
                       (?,?,?,?,?,?,0,?,NOW())
               ");
               $ins->bind_param("iisidds", $orderId, $productId, $prod['name'], $quantity, $price, $price, $reference);
               $ins->execute();
           }
   
           
           recalc_order_totals($conn, $orderId);
       }
       header("LOCATION:order_details.php?order_id=" . $orderId);
       exit;
       }
   
   $orderID=isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
   if($orderID<=0)
   {
       die('Comanda invalida');
   }
   if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_state'])) {
     $newState  = isset($_POST['state_id']) ? (int)$_POST['state_id'] : 0;
     
     $orderId   = isset($_POST['order_id']) ? (int)$_POST['order_id'] : $orderId;
     $employeeID = isset($_SESSION['admin_logg']) ? (int)$_SESSION['admin_logg'] : 0;
   
     if ($orderId > 0 && $newState > 0) {


      $oldStateQ = $conn->prepare("SELECT current_state FROM orders WHERE order_id=?");
        $oldStateQ->bind_param("i", $orderId);
        $oldStateQ->execute();
        $oldStateRes = $oldStateQ->get_result()->fetch_assoc();
        $previousState = (int)($oldStateRes['current_state'] ?? 0);

        // Dacă noul status e "Anulata" (presupunem că ID-ul este 6) și comanda NU era deja anulată
        if ($newState === 6 && $previousState !== 6) {
            // Luăm toate produsele din comandă
            $productsInOrder = $conn->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
            $productsInOrder->bind_param("i", $orderId);
            $productsInOrder->execute();
            $result = $productsInOrder->get_result();

            while ($prod = $result->fetch_assoc()) {
                $pid = (int)$prod['product_id'];
                $qty = (int)$prod['quantity'];

                // Refacem stocul
                $restoreStock = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?");
                $restoreStock->bind_param("ii", $qty, $pid);
                $restoreStock->execute();
            }
        }
       
       $stmt = $conn->prepare("UPDATE orders SET current_state = ? WHERE order_id = ?");
       $stmt->bind_param("ii", $newState, $orderId);
       $stmt->execute();
   
       
       $stmt = $conn->prepare("
         INSERT INTO order_history (order_id, state_id, id_angajat, date_added)
         VALUES (?, ?, ?, NOW())
       ");
       $stmt->bind_param("iii", $orderId, $newState, $employeeID);
       $stmt->execute();
     }
   
     
     header("Location: order_details.php?order_id=".$orderId);
     exit;
   }
   
   
   $sql="
   SELECT o.*, os.name AS state_name,
   
   COALESCE(CONCAT(c.first_name, ' ', c.last_name), CONCAT(g.first_name, ' ', g.last_name), 'Client Necunoscut') AS customer_name,
   COALESCE(c.email, g.email) AS email,
   c.birth_date AS customer_birth,
   c.created_at AS customer_created,
   
   p.name AS payment_method,
   s.name AS courier,
   
   a.street_address,a.city,a.county,a.country,a.postal_code,a.company_name,a.tax_id
   
   FROM orders o
   LEFT JOIN customers c ON c.customer_id=o.customer_id
   LEFT JOIN guest g ON o.guest_id = g.guest_id
   LEFT JOIN payments p ON p.payment_id=o.payment_id
   LEFT JOIN shippings s ON s.shipping_id=o.shipping_id
   LEFT JOIN addresses a ON a.address_id=o.address_id
   LEFT JOIN order_state os ON o.current_state=os.id
   WHERE o.order_id=?
   ";
   $stmt=$conn->prepare($sql);
   $stmt->bind_param("i",$orderID);
   $stmt->execute();
   $order=$stmt->get_result()->fetch_assoc();
   
   $items=[];
   
   $stmt=$conn->prepare("SELECT order_item_id,product_id, product_name,quantity, price_final,price_original,discount,created_at
   FROM order_items 
   WHERE order_id=?
   ORDER BY order_item_id ASC");
   $stmt->bind_param("i",$orderID);
   $stmt->execute();
   $resItems=$stmt->get_result();
   while($row=$resItems->fetch_assoc()){ $items[]=$row;}
   
   
   $states=[];
   
   $resStates=$conn->query("SELECT id, name FROM order_state ORDER BY id ASC");
   while($s=$resStates->fetch_assoc()){$states[]=$s;}
   
   $history=[];
   
   $stmt=$conn->prepare("SELECT oh.*, os.name AS state_name
   FROM order_history oh
   LEFT JOIN order_state os ON os.id=oh.state_id
   WHERE oh.order_id=?
   ORDER BY oh.date_added DESC, oh.id DESC");
   $stmt->bind_param("i",$orderID);
   $stmt->execute();
   $resH=$stmt->get_result();
   while($h=$resH->fetch_assoc()){$history[]=$h;}
   
   
   $subtotal=0;
   
   foreach($items as $it){
       $subtotal+=(float)$it['price_final']*(int)$it['quantity'];
   }
   $total=(float)$order['total_payment'];
   ?>
<!DOCTYPE html>
<html lang="ro">
   <head>
      <meta charset="UTF-8">
      <title>Comandă </title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
         .card-title { font-weight: 600; }
         .sticky-top-bar { position: sticky; top: 0; z-index: 100; background: #fff; }
         .table thead th { position: sticky; top: 0; background: #212529; color:#fff; z-index: 2; }
      </style>
   </head>
   <body class="bg-light">
      <div class="container-fluid p-3 sticky-top-bar border-bottom mb-3">
         <div class="d-flex align-items-center justify-content-between">
            <div>
               <h5 class="mb-0">
                  Comanda <?php echo $order['order_reference']; ?>
                  <small class="text-muted">(#<?php echo (int)$order['order_id'];?>)</small>
               </h5>
               <small class="text-muted"><?php echo $order['created_at'];?></small>
            </div>
            <div class="d-flex gap-2">
               <a href="index.php#comenzi" class="btn btn-outline-secondary btn-sm">Inapoi la comenzi</a>
               <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
            </div>
         </div>
      </div>
      <div class="container">
      <div class="row g-3">
         <div class="col-12">
            <div class="card">
               <div class="card-body d-flex flex-wrap align-items-center gap-3">
                  <div>
                     <div class="text-muted small">Stare curenta</div>
                     <div class="fs-5 fw-semibold"><?php echo $order['state_name']?: '-';?></div>
                  </div>
                  <form method="post" class="d-flex align-items-center gap-2 ms-auto">
                     <input type="hidden" name="change_state" value="1">
                     <input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">
                     <select name="state_id" class="form-select form-select-sm" style="min-width:220px" required>
                        <?php foreach($states as $st): ?>
                        <option value="<?php echo (int)$st['id']; ?>"
                           <?php if((int)$st['id'] === (int)$order['current_state']) echo 'selected'; ?>>
                           <?php echo htmlspecialchars($st['name']); ?>
                        </option>
                        <?php endforeach; ?>
                     </select>
                     <button type="submit" class="btn btn-primary btn-sm">Actualizează status</button>
                  </form>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="card h-100">
               <div class="card-body">
                  <h6 class="card-title mb-3">Client</h6>
                  <div class="mb-2 fw-semibold"><?php echo $order['customer_name']?:'Client necunoscut';?></div>
                  <div class="text-muted small">Email: <?php echo $order['email']?: '-';?></div>
                  <div class="text-muted small">Data nasterii: <?php echo $order['customer_birth']?: '-';?></div>
                  <div class="text-muted small">Client din: <?php echo $order['customer_created']?: '-';?></div>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="card h-100">
               <div class="card-body">
                  <h6 class="card-title mb-3">Adresa de livrare</h6>
                  <div class="small mb-2">
                     <?php $addr=array_filter([
                        $order['street_address'] ?? '',
                        $order['city'] ?? '',
                        $order['county'] ?? '',
                        $order['country'] ?? '',
                        $order['postal_code'] ?? ''
                        ]);
                        echo implode(',',$addr)?: '-';?>
                  </div>
                  <?php if(!empty($order['company_name']) || !empty($order['tax_id'])){?>
                  <div class="small text-muted">
                     <div>Firma: <?php echo $order['company_name']?: '-';?></div>
                     <div>CUI:<?php echo $order['tax_id']?: '-';?></div>
                  </div>
                  <?php }?>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="card h-100">
               <div class="card-body">
                  <h6 class="card-title mb-3">Plata si Curier</h6>
                  <div class="small mb-2">
                     <span class="text-muted">Metoda Plata:</span>
                     <span class="fw-semibold">
                     <?php echo $order['payment_method']?: '-';?>
                     </span>
                  </div>
                  <div class="small">
                     <span class="text-muted">Curier:</span>
                     <span class="fw-semibold"><?php echo $order['courier']?: '-';?></span>   
                  </div>
               </div>
            </div>
         </div>
         <div class="col-12">
            <div class="card">
               <div class="card-body">
                  <h6 class="card-title mb-3">Produse:</h6>
                  <div class="table-responsive">
                     <table class="table table-bordered table-hover align-middle">
                        <thead class="table-dark">
                           <tr>
                              <th>#</th>
                              <th>Produs</th>
                              <th>Cant.</th>
                              <th>Pret unitar</th>
                             
                              <th>Total linie</th>
                              <th>Creat</th>
                              <th>Acțiuni</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php if(count($items)): $i=1; foreach($items as $it):
                              $rid = (int)$it['order_item_id'];
                              ?>
                           <tr data-item-id="<?= $rid ?>">
                              <td><?= $i++; ?></td>
                              <td><?= htmlspecialchars($it['product_name']); ?></td>
                              <td>
                                 <span class="view"><?= (int)$it['quantity'] ?></span>
                                 <input
                                    type="number"
                                    min="1"
                                    name="quantity"
                                    value="<?= (int)$it['quantity'] ?>"
                                    class="form-control form-control-sm edit d-none"
                                    style="max-width:90px"
                                    form="editForm<?= $rid ?>"
                                    >
                              </td>
                              <td>
                                 <span class="view"><?= number_format((float)$it['price_final'],2,',','.') ?> Lei</span>
                                 <div class="edit d-none" style="max-width:140px">
                                    <div class="input-group input-group-sm">
                                       <input
                                          type="number"
                                          step="0.01"
                                          name="price_final"
                                          value="<?= (float)$it['price_final'] ?>"
                                          class="form-control"
                                          form="editForm<?= $rid ?>"
                                          >
                                       <span class="input-group-text">Lei</span>
                                    </div>
                                 </div>
                              </td>
                              
                              <td><?= number_format((float)$it['price_final']*(int)$it['quantity'],2,',','.') ?> Lei</td>
                              <td class="text-muted small"><?= htmlspecialchars($it['created_at']) ?></td>
                              <td>
                                 <?php if ((int)$order['payment_id'] === 2): ?>
                                 <div class="view">
                                    <button type="button"
                                       class="btn btn-outline-secondary btn-sm btn-edit"
                                       data-row="<?= $rid ?>">
                                    Editează
                                    </button>
                                    <form method="post" class="d-inline"
                                       onsubmit="return confirm('Sigur ștergi acest produs din comandă?');">
                                       <input type="hidden" name="delete_order_item" value="1">
                                       <input type="hidden" name="order_item_id" value="<?= $rid ?>">
                                       <button type="submit" class="btn btn-danger btn-sm">Șterge</button>
                                    </form>
                                 </div>
                                 <div class="edit d-none">
                                    <form method="post" id="editForm<?= $rid ?>" class="d-inline">
                                       <input type="hidden" name="edit_order_item" value="1">
                                       <input type="hidden" name="order_item_id" value="<?= $rid ?>">
                                       <button type="submit" class="btn btn-warning btn-sm me-1">Salvează</button>
                                    </form>
                                    <button type="button"
                                       class="btn btn-light btn-sm btn-cancel"
                                       data-row="<?= $rid ?>">
                                    Renunță
                                    </button>
                                 </div>
                                 <?php else: ?>
                                    <span class="text-muted">Nu se poate modifica</span>
                                    <?php endif; ?>
                              </td>
                           </tr>
                           <?php endforeach; endif; ?>
                        </tbody>
                    </table>

                    <?php if ((int)$order['payment_id'] === 2): ?>
                     <h5 class="mt-4">Adauga produs în comanda</h5>
                     
                     <form method="post" class="row g-2 mb-3">
                        <input type="hidden" name="search_products" value="1">
                        <div class="col-auto">
                           <input type="text" name="product_search" class="form-control" placeholder="Caută după nume produs" required>
                        </div>
                        <div class="col-auto">
                           <button type="submit" class="btn btn-primary">Cauta</button>
                        </div>
                     </form>
                    <?php else: ?>
                        <div class="alert alert-warning mt-4">
                            Produsele nu pot fi adaugate sau modificate deoarece plata nu este ramburs.
                        </div>
                    <?php endif; ?>
                     <?php if (!empty($searchResults)) { ?>
                     <table class="table table-sm table-bordered">
                        <thead>
                           <tr>
                              
                              <th>Nume</th>
                              <th>Preț</th>
                              <th>Cantitate</th>
                              <th></th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php foreach ($searchResults as $prod) { ?>
                           <tr>
                              <form method="post">
                                 
                                 <td><?php echo htmlspecialchars($prod['name']); ?></td>
                                 <td><?php echo number_format($prod['price'], 2); ?> Lei</td>
                                 <td>
                                    <input type="number" name="quantity" value="1" min="1" class="form-control form-control-sm" style="width:80px;">
                                 </td>
                                 <td>
                                    <input type="hidden" name="add_product_to_order" value="1">
                                    <input type="hidden" name="product_id" value="<?php echo $prod['product_id']; ?>">
                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                    <button type="submit" class="btn btn-success btn-sm">Adaugă</button>
                                 </td>
                              </form>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
                     <?php } ?>
                     <div class="d-flex justify-content-end">
                        <div class="text-end">
                           <div class="small text-muted">Subtotal:</div>
                           <div class="fw-semibold mb-2"><?php echo number_format($subtotal,2);?> LEI</div>
                           <div class="small text-muted">Total:</div>
                           <div class="fs-5 fw-bold"><?php echo number_format($total,2);?> LEI</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-12">
               <div class="card">
                  <div class="card-body">
                     <h6 class="card-title mb-3">Jurnal modificari</h6>
                     <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle">
                           <thead class="table-light">
                              <tr>
                                 <th>Data</th>
                                 <th>Stare</th>
                                 <th>ID Angajat</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php if(count($history)): foreach($history as $h): ?>
                              <tr>
                                 <td class="text-muted small"><?php echo htmlspecialchars($h['date_added']); ?></td>
                                 <td><?php echo htmlspecialchars($h['state_name'] ?: ('#'.$h['state_id'])); ?></td>
                                 <td><?php echo (int)$h['id_angajat']; ?></td>
                              </tr>
                              <?php endforeach; else: ?>
                              <tr>
                                 <td colspan="3" class="text-center text-muted">Fără modificări încă.</td>
                              </tr>
                              <?php endif; ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      <script>
         $(function () {
           
           $(document).on('click', '.btn-edit', function () {
             var id  = $(this).data('row');
             var $row = $('tr[data-item-id="' + id + '"]');
             $row.find('.view').addClass('d-none');
             $row.find('.edit').removeClass('d-none');
           });
         
           
           $(document).on('click', '.btn-cancel', function () {
             var id  = $(this).data('row');
             var $row = $('tr[data-item-id="' + id + '"]');
             $row.find('.edit').addClass('d-none');
             $row.find('.view').removeClass('d-none');
           });
         
          
           $(document).on('input', 'input[name="quantity"], input[name="price_final"]', function () {
             var $row   = $(this).closest('tr');
             var qty    = parseFloat($row.find('input[name="quantity"]').val() || '0');
             var price  = parseFloat($row.find('input[name="price_final"]').val() || '0');
             var total  = (qty * price).toFixed(2);
         
             
             $row.find('td').eq(5).text(total.replace('.', ',') + ' Lei');
           });
         });
      </script>
   </body>
</html>