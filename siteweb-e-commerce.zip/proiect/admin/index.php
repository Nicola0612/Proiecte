<?php require_once '../db.php';
   session_start();
   if(!isset($_SESSION['admin_logg'])){
     header("Location: login.php");
     exit;
   }
   
   
   if(isset($_POST['add_product'])){
       $target_dir = "../img/";
       $fileName=basename($_FILES["image_url"]["name"]);
     $target_file = $target_dir . basename($_FILES["image_url"]["name"]);
     $uploadOk = 1;
     $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   
      $result = $conn->query("SELECT MAX(CAST(SUBSTRING(reference, 2) AS UNSIGNED)) AS max_ref FROM products");
       $row = $result->fetch_assoc();
       $nextRefNumber = $row['max_ref'] + 1;
       $reference = 'P' . $nextRefNumber;
   
     $isActive=isset($_POST['active'])?1:0;
   
   if (move_uploaded_file($_FILES["image_url"]["tmp_name"], $target_file)) {}
       $stmt=$conn->prepare("INSERT INTO products (reference,name, description, price, discount, stock_quantity, category_id,brand,image_url,active) VALUES (?,?,?,?,?,?,?,?,?,?)");
       $stmt->bind_param("sssdiiiss",$reference,$_POST['name'],$_POST['description'],$_POST['price'],$_POST['discount'],$_POST['stock_quantity'],$_POST['category_id'],$_POST['brand'],$fileName);
       $stmt->execute();
       header("Location: index.php");
       exit;
   }
   
   
   if(isset($_GET['delete'])){
   //   var_dump('text');
    
   //   
   //   var_dump($id);
   //   exit; 
   $id=$_GET['delete'];
       $stmt=$conn->prepare("DELETE FROM products WHERE product_id=?");
   
       $stmt->bind_param("i",$id);
       $stmt->execute();
       header("Location: index.php");
       exit;
   }
   
   if (isset($_POST['edit_product'])) {
       $image_url = $_POST['image_url']; 
       if (isset($_FILES['new_image']) && $_FILES['new_image']['error'] === UPLOAD_ERR_OK) {
           $target_dir = "../img/";
           $fileName = basename($_FILES["new_image"]["name"]);
           $target_file = $target_dir . $fileName;
   
          
           if (move_uploaded_file($_FILES["new_image"]["tmp_name"], $target_file)) {
               $image_url = $fileName; 
           }
       }
   
       $isActive = isset($_POST['active']) ? 1 : 0;
   
       $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, discount=?, stock_quantity=?, category_id=?, brand=?, image_url=?, active=? WHERE product_id=?");
       $stmt->bind_param(
           "ssdiiisssi",
           $_POST['name'],
           $_POST['description'],
           $_POST['price'],
           $_POST['discount'],
           $_POST['stock_quantity'],
           $_POST['category_id'],
           $_POST['brand'],
           $image_url,
           $isActive,
           $_POST['product_id']
       );
       $stmt->execute();
       header("Location: index.php");
       exit;
   }
   
   $categories_result = $conn->query("SELECT category_id, name FROM categories");
   
   $result=$conn->query("SELECT p.*, c.name AS category_name 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.category_id
   ");

if(isset($_POST['change_state']) && isset($_POST['order_id']) && isset($_POST['state_id'])){
  $orderID=intval($_POST['order_id']);
  $stateID=intval($_POST['state_id']);
  $employeeID=intval($_SESSION['admin_logg']);

   $oldStateQ = $conn->prepare("SELECT current_state FROM orders WHERE order_id=?");
        $oldStateQ->bind_param("i", $orderID);
        $oldStateQ->execute();
        $oldStateRes = $oldStateQ->get_result()->fetch_assoc();
        $previousState = (int)($oldStateRes['current_state'] ?? 0);

        // Dacă noul status e "Anulata" (presupunem că ID-ul este 6) și comanda NU era deja anulată
        if ($stateID === 6 && $previousState !== 6) {
            // Luăm toate produsele din comandă
            $productsInOrder = $conn->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
            $productsInOrder->bind_param("i", $orderID);
            $productsInOrder->execute();
            $result = $productsInOrder->get_result();

            while ($prod = $result->fetch_assoc()) {
                $pid = (int)$prod['product_id'];
                $qty = (int)$prod['quantity'];

                // Refacem stocul
                $restoreStock = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?");
                $restoreStock->bind_param("ii", $qty, $pid);
                $restoreStock->execute();
            }
        }


  $stmt=$conn->prepare("UPDATE orders SET current_state=? WHERE order_id=?");
  $stmt->bind_param("ii",$stateID,$orderID);
  $stmt->execute();

  $stmt=$conn->prepare("INSERT INTO order_history(order_id,state_id,id_angajat ,date_added) VALUES(?,?,?,NOW())");
  $stmt->bind_param("iii",$orderID,$stateID,$employeeID);
  $stmt->execute();

}
$states_res=$conn->query("SELECT id, name FROM order_state");
$order_state=[];
while($s=$states_res->fetch_assoc()){
  $order_state[]=$s;
}


$res=$conn->query("SELECT COUNT(*) AS total_comenzi FROM orders");
$r=$res->fetch_assoc();
$total_comenzi=$r['total_comenzi'];

$s="SELECT o.order_id, o.order_reference,o.current_state,o.total_payment, o.created_at,os.name AS state_name, COALESCE(CONCAT(c.first_name, ' ', c.last_name), CONCAT(g.first_name, ' ', g.last_name), 'Client Necunoscut') AS customer_name,p.name AS payment_method, s.name AS courier,a.street_address, a.city,a.county,a.country,a.postal_code
FROM orders o
LEFT JOIN guest g ON o.guest_id = g.guest_id
LEFT JOIN customers c ON c.customer_id=o.customer_id
LEFT JOIN payments p ON o.payment_id=p.payment_id
LEFT JOIN shippings s ON o.shipping_id=s.shipping_id
LEFT JOIN order_state os ON o.current_state=os.id
LEFT JOIN addresses a ON o.address_id=a.address_id
ORDER BY o.order_id DESC";
$orders=$conn->query($s);

?>
<!DOCTYPE html>
<html lang="ro">
   <head>
      <meta charset="UTF-8">
      <title>Admin - Produse</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   </head>
   <body class="bg-light">
  <div class="container-fluid">
    <div class="row g-0">


         <aside class="col-12 col-md-2 bg-white border-end min-vh-100 position-sticky top-0 p-3">
        <h5 class="mb-3">Meniu</h5>
        <div class="list-group">
          <a class="list-group-item list-group-item-action active"
             data-bs-toggle="tab" href="#produse" role="tab">Produse</a>
          <a class="list-group-item list-group-item-action"
             data-bs-toggle="tab" href="#comenzi" role="tab">Comenzi</a>
        </div>
      </aside>
    <main class="col-12 col-md-10 p-4">
      <div class="d-flex align-items-center justify-content-between mb-3">
         <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
         </div>
         
            <div class="tab-content" id="nav-tabContent">
               <div class="tab-pane fade show active" id="produse" role="tabpanel">
                  <h2 class="card my-4">Lista produse</h2>
                  <table class="table table-bordered table-striped table-hover">
                     <thead class="table-dark">
                        <tr>
                           <th>Imagine_url</th>
                           <th>ID</th>
                           <th>Nume</th>
                           <th>Categorie</th>
                           <th>Pret</th>
                           <th>Discount</th>
                           <th>Stoc</th>
                           <th>Brand</th>
                           <th>Activ</th>
                           <th>Actiuni</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php while($row=$result->fetch_assoc()){ ?>
                        <tr>
                           <td>
                              <img src="../img/<?php echo $row['image_url']; ?>" alt="Imagine produs" style="max-width: 60px; max-height: 60px;">
                           </td>
                           <td><?php echo $row['reference']?></td>
                           <td><?php echo $row['name']?></td>
                           <td><?php echo $row['category_name']; ?></td>
                           <td><?php echo number_format($row['price'],2)?></td>
                           <td><?php echo $row['discount']?></td>
                           <td><?php echo $row['stock_quantity']?></td>
                           <td><?php echo $row['brand']?></td>
                           <td><?php echo ($row['active']==1) ? 'DA':'NU'?></td>
                           <td>
                              <button
                                 type="button"
                                 class="btn btn-sm btn-primary btn-edit"
                                 data-bs-toggle="modal"
                                 data-bs-target="#editModal"
                                 data-id="<?php echo $row['product_id']?>"
                                 data-name="<?php echo $row['name']?>"
                                 data-price="<?php echo $row['price']?>"
                                 data-discount="<?php echo $row['discount']?>"
                                 data-stock="<?php echo $row['stock_quantity']?>"
                                 data-brand="<?php echo $row['brand']?>"
                                 data-description="<?php echo $row['description']?>"
                                 data-category="<?php echo $row['category_id']?>"
                                 data-image="<?php echo $row['image_url']?>"
                                 data-active="<?php echo $row['active']?>"
                                 >
                              Editează
                              </button>
                           </td>
                           <td>
                              <a href="?delete=<?php echo $row['product_id']?>" class="btn btn-sm btn-gander" onclick="return confirm('sigur stergi?')">Sterge</a>
                           </td>
                        </tr>
                        <?php }?>
                     </tbody>
                  </table>
                  <hr class="my-4">
                  <div class="d-flex justify-content-center my-4">
                     <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                     Adauga produs
                     </button>
                  </div>
               </div>

               <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                     <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h1 class="modal-title fs-5" id="staticBackdropLabel">Adauga produs</h1>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                           </div>
                           <div class="modal-body">
                              <form method="POST" enctype="multipart/form-data" class="row g-3">
                                 <input type="hidden" name="add_product" value="1">
                                 <div class="col-md-6">
                                    <label class="form-label">Nume</label>
                                    <input type="text" name="name" class="form-control" required>
                                 </div>
                                 <div class="col-md-6">
                                    <label class="form-label">Brand</label>
                                    <input type="text" name="brand" class="form-control">
                                 </div>
                                 <div class="col-md-12">
                                    <label class="form-label">Descriere</label>
                                    <textarea name="description" class="form-control" rows="3"></textarea>
                                 </div>
                                 <div class="col-md-3">
                                    <label class="form-label">Pret</label>
                                    <input type="number" step="0.01" name="price" class="form-control" required>
                                 </div>
                                 <div class="col-md-3">
                                    <label class="form-label">Discount</label>
                                    <input type="number"  name="discount" class="form-control" value="0">
                                 </div>
                                 <div class="col-md-3">
                                    <label class="form-label">Stock</label>
                                    <input type="number"  name="stock_quantity" class="form-control" required>
                                 </div>
                                 <div class="col-md-3">
                                    <label class="form-label">Categorie</label>
                                    <select name="category_id" class="form-select" required>
                                       <option value="">Alege o categorie</option>
                                       <?php while($c = $categories_result->fetch_assoc()) { ?>
                                       <option value="<?php echo $c['category_id']; ?>">
                                          <?php echo $c['name']; ?>
                                       </option>
                                       <?php } ?>
                                    </select>
                                 </div>
                                 <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="active" id="active" value="1" checked>
                                    <label class="form-check-label" for="active">
                                    Activ (vizibil pentru utilizatori)
                                    </label>
                                 </div>
                                 <div class="mb-3">
                                    <label for="image_url" class="form-label">Imagine produs</label>
                                    <input class="form-control" type="file" name="image_url" id="image_url" accept="image/*">
                                    <img id="previewImage" style="display:none; margin-top: 10px; max-width: 100%; height: auto; border: 1px solid #ccc; border-radius: 8px;" />
                                 </div>
                                 <div class="col-12">
                                    <button type="submit" class="btn btn-success">Adaugă Produs</button>
                                 </div>
                              </form>
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php
                  $categories_result2 = $conn->query("SELECT category_id, name FROM categories");
                  ?>
               <div class="modal fade" id="editModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h1 class="modal-title fs-5" id="editModalLabel">Editează produs</h1>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Închide"></button>
                        </div>
                        <div class="modal-body">
                           <form method="POST" class="row g-3" enctype="multipart/form-data">
                              <input type="hidden" name="edit_product" value="1">
                              <input type="hidden" name="product_id" id="edit-product-id">
                              <div class="col-md-6">
                                 <label class="form-label">Nume</label>
                                 <input type="text" name="name" id="edit-name" class="form-control" required>
                              </div>
                              <div class="col-md-6">
                                 <label class="form-label">Brand</label>
                                 <input type="text" name="brand" id="edit-brand" class="form-control">
                              </div>
                              <div class="col-md-12">
                                 <label class="form-label">Descriere</label>
                                 <textarea name="description" id="edit-description" class="form-control" rows="3"></textarea>
                              </div>
                              <div class="col-md-3">
                                 <label class="form-label">Preț</label>
                                 <input type="number" step="0.01" name="price" id="edit-price" class="form-control" required>
                              </div>
                              <div class="col-md-3">
                                 <label class="form-label">Discount</label>
                                 <input type="number" name="discount" id="edit-discount" class="form-control" value="0">
                              </div>
                              <div class="col-md-3">
                                 <label class="form-label">Stoc</label>
                                 <input type="number" name="stock_quantity" id="edit-stock" class="form-control" required>
                              </div>
                              <div class="col-md-3">
                                 <label class="form-label">Categorie</label>
                                 <select name="category_id" id="edit-category" class="form-select" required>
                                    <option value="">Alege o categorie</option>
                                    <?php while($c = $categories_result2->fetch_assoc()) { ?>
                                    <option value="<?php echo $c['category_id']; ?>">
                                       <?php echo $c['name']; ?>
                                    </option>
                                    <?php } ?>
                                 </select>
                              </div>
                              <div class="form-check">
                                 <input class="form-check-input" type="checkbox" name="active" id="edit-active" value="1" checked>
                                 <label class="form-check-label" for="active">
                                 Activ (vizibil pentru utilizatori)
                                 </label>
                              </div>
                              <div class="mb-3">
                                 <label for="edit-image-url" class="form-label">Imagine produs</label>
                                 <input type="hidden" name="image_url" id="edit-image-url">
                                 <input type="file" name="new_image" id="edit-new-image" class="form-control">
                                 <img id="edit-preview" src="" alt="Preview" style="display:none; margin-top:10px; max-width:100%; height:auto; border:1px solid #ccc; border-radius: 8px;">
                              </div>
                              <div class="col-12">
                                 <button type="submit" class="btn btn-success">Salvează</button>
                              </div>
                           </form>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Închide</button>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- aici se termina produse-->
               <div class="tab-pane fade" id="comenzi" role="tabpanel">
                  <h3>Comenzi (<?php echo number_format($total_comenzi);?>) </h3>
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead class="table-dark">
                        <tr>
                          <th>Referinta</th>
                          <th>Client</th>
                          <th>Total</th>
                          <th>Metoda Plata</th>
                          <th>Stare</th>
                          <th>Data</th>
                          <th>Curier</th>
                          <th>Adresa</th>
                          <th>Actiuni</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php while($order=$orders->fetch_assoc()){?>
                          <tr>
                            <td><?php echo $order['order_reference']?></td>
                            <td><?php echo $order['customer_name']?: 'Client Necunoscut'?></td>
                            <td><?php echo number_format($order['total_payment'],2)?> Lei</td>
                            <td><?php echo $order['payment_method']?></td>
                            <td>
                              <form method="post" style="margin:0;">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <input type="hidden" name="change_state" value="1">
                                <select name="state_id" class="form-select form-select-sm" onchange="this.form.submit()">
                                  <?php foreach($order_state as $state) { ?>
                                    <option value="<?php echo $state['id']; ?>" <?php if($state['id'] == $order['current_state']) echo 'selected'; ?>>
                                  <?php echo $state['name']; ?>
                                     </option>
                                  <?php } ?>
                                  </select>
                              </form>
                            </td>
                            <td><?php echo $order['created_at']?></td>
                            <td><?php echo $order['courier']?></td>
                            <td>
                              <?php echo $order['street_address'] . ', ' . $order['city'] . '. ' . $order['county'] . ', ' . $order['country'] . ', ' . $order['postal_code'];?>
                            </td>
                            <td>
                           <a href="order_details.php?order_id=<?php echo (int)$order['order_id']; ?>" class="btn btn-sm btn-outline-primary">Vezi Detalii</a>
                          </td>
                          </tr>
                          <?php }?>
                          
                      </tbody>
                    </table>
                  </div>
        </div>
      </main>
    </div>
  </div>
</body>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
   <script>
      $(document).ready(function() {
      $('.btn-edit').on('click', function() {
        $('#edit-product-id').val($(this).data('id'));
        $('#edit-name').val($(this).data('name'));
        $('#edit-price').val($(this).data('price'));
        $('#edit-discount').val($(this).data('discount'));
        $('#edit-stock').val($(this).data('stock'));
        $('#edit-brand').val($(this).data('brand'));
        $('#edit-description').val($(this).data('description'));
        $('#edit-category').val($(this).data('category'));
        $('#edit-active').prop('checked', $(this).data('active') == 1);
      
        const imageFile = $(this).data('image');
        const imageUrl = '../img/' + imageFile;
      
        $('#edit-image-url').val(imageFile); 
        if (imageFile && imageFile.trim() !== '') {
            $('#edit-preview').attr('src', imageUrl).show();
          } else {
            $('#edit-preview').attr('src', '').hide();
          }
        });
      
        $('#edit-new-image').on('change', function (event) {
          const input = event.target;
          if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
              $('#edit-preview').attr('src', e.target.result).show();
            };
            reader.readAsDataURL(input.files[0]);
          }
        });
      
        
        $('#editModal').on('hidden.bs.modal', function () {
          $('#edit-preview').attr('src', '').hide();
          $('#edit-new-image').val('');
        });
      });
      
   </script>
   <script>
      $(document).ready(function() {
        
        $('#image_url').on('change', function() {
          const file = this.files[0];
          if (file) {
            $('#previewImage').attr('src', URL.createObjectURL(file)).show();
          } else {
            $('#previewImage').attr('src', '').hide();
          }
        });
      
        $('#staticBackdrop').on('hidden.bs.modal', function () {
          $('#previewImage').attr('src', '').hide();
          $('#image_url').val('');
        });
      });
   </script>