<?php 
   session_start();
   require_once 'db.php';
   
   $categoryId=isset($_GET['id'])? (int) $_GET['id']:0;
   if($categoryId <=0){
       http_response_code(404);
       die('categorie lipsa');
   }
   
   $stmt=$conn->prepare("SELECT category_id, name FROM categories WHERE category_id=?");
   $stmt->bind_param("i",$categoryId);
   $stmt->execute();
   $category=$stmt->get_result()->fetch_assoc();
   
   if(!$category){
       http_response_code(404);
       die('categorie nu exista;');
   }
   
   $perPage=12;
   $page=max(1,(int)($_GET['page']?? 1));
   $offset=($page-1)*$perPage;
   
   $sort=$_GET['sort'] ?? 'nou';
   $orderBy="p.created_at DESC";
   if($sort=== 'pret_cresc') $orderBy="prez_efectiv ASC";
   if($sort=== 'pret_desc') $orderBy="prez_efectiv DESC";
   
   
   $countSQL="
   SELECT count(DISTINCT p.product_id) AS total
   FROM products p
   JOIN product_category pc ON pc.product_id=p.product_id
   WHERE pc.category_id=? AND p.active=1";
   
   $cnt=$conn->prepare($countSQL);
   $cnt->bind_param("i",$categoryId);
   $cnt->execute();
   
   $total=(int)($cnt->get_result()->fetch_assoc()['total']?? 0);
   $totalPages=max(1,(int)ceil($total/$perPage));
   $where="pc.category_id=? AND p.active=1";
   $params=[$categoryId];
   $types="i";
   //promotii
   if(isset($_GET['promo'])){
       $where.=" AND p.discount>0";
   }
   //preturi
   
   $pretWhere=[];
   if(!empty($_GET['pret']) && is_array($_GET['pret'])){
       foreach($_GET['pret'] as $range){
           switch($range){
               case 'sub100':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2)<100)";
                   break;
               case '100-200':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 100 AND 200)";
                   break;
               case '200-500':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 200 AND 500)";
                   break;
               case '500-1000':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 500 AND 1000)";
                   break;
               case '1000-1500':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 1000 AND 1500)";
                   break;
               case '1500-2000':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 1500 AND 2000)";
                   break;
               case '2000-3000':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 2000 AND 3000)";
                   break;
               case '3000-4000':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) BETWEEN 3000 AND 4000)";
                   break;
               case 'peste4000':
                   $pretWhere[]="(ROUND(p.price*(100-IFNULL(p.discount,0))/100,2)>4000)";
                   break;
           }
       }
       if(!empty($pretWhere)){
           $where.=" AND (" . implode(" OR ", $pretWhere) . ")";
       }
   }
   
   
   $sql="
   SELECT 
       p.product_id,p.name,p.price, IFNULL(p.discount,0) AS discount,
       ROUND(p.price*(100-IFNULL(p.discount,0))/100,2) AS prez_efectiv,
       p.image_url
   FROM products p
   JOIN product_category pc ON pc.product_id=p.product_id
   WHERE $where
   ORDER BY $orderBy
   LIMIT ? OFFSET ?";
   
   $ps=$conn->prepare($sql);
   $ps->bind_param("iii",$categoryId,$perPage,$offset);
   $ps->execute();
   $products=$ps->get_result()->fetch_all(MYSQLI_ASSOC);
   
   
   
   include 'header.php';
   ?>
<div class="container mt-4">
   <div class="row">

   <div class="col-md-3">
         <form method="get" class="mb-4">
            <input type="hidden" name="id" value="<?= (int)$categoryId ?>">
            <h5>Promotii</h5>
            <div class="mb-3">
               <input type="checkbox" name="promo" value="1" <?= isset($_GET['promo']) ? 'checked' : '' ?>>
               <label for="promo">Promotie</label>
            </div>
            <h5>Pret</h5>
            <?php
               $priceFilters = [
                 'sub100' => 'Sub 100',
                 '100-200' => '100 - 200',
                 '200-500' => '200 - 500',
                 '500-1000' => '500 - 1000',
                 '1000-1500' => '1000 - 1500',
                 '1500-2000' => '1500 - 2000',
                 '2000-3000' => '2000 - 3000',
                 '3000-4000' => '3000 - 4000',
                 'peste4000' => 'Peste 4000'
               ];
               
               foreach ($priceFilters as $key => $label): ?>
            <div>
               <input type="checkbox" name="pret[]" value="<?= $key ?>" <?= (isset($_GET['pret']) && in_array($key, $_GET['pret'])) ? 'checked' : '' ?>>
               <label><?= $label ?></label>
            </div>
            <?php endforeach; ?>
            <button type="submit" class="btn btn-primary mt-2">Filtreaza</button>
         </form>
      </div>


      <div class="col-md-9">
         <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
            <div>
               <h1 class="h4 mb-1"><?= htmlspecialchars($category['name']) ?></h1>
            </div>
            <form method="get" class="d-flex allign-items-center gao-2">
               <input type="hidden" name="id" value="<?=(int)$categoryId?>">
               <label class="text-nowrap small">Sorteaza:</label>
               <select name="sort" class="from-select form-select-sm" onchange="this.form.submit()">
                  <option value="nou" <?=$sort==='nou'?'selected': ''?>>Cele mai noi</option>
                  <option value="pret_cresc" <?=$sort==='pret_cresc'?'selected': ''?>>Pret crescator</option>
                  <option value="pret_desc" <?=$sort==='pret_desc'?'selected': ''?>>Pret descrescator</option>
               </select>
            </form>
         </div>
         <?php if ($total === 0): ?>
         <div class="alert alert-info">Nu există produse în această categorie.</div>
         <?php else: ?>
         <div class="row row-cols-1 row-cols-md-4 g-4 mobile-grid">
            <?php foreach ($products as $p): ?>
            <div class="col">
               <div class="card h-100 d-flex flex-column">
                  <?php if ((float)$p['discount'] > 0): ?>
                  <span class="position-absolute top-0 end-0 bg-warning text-dark px-2 py-1 small fw-bold rounded-start">
                  -<?= (int)$p['discount'] ?>%
                  </span>
                  <?php endif; ?>
                  <img src="img/<?= htmlspecialchars($p['image_url']) ?>"
                     class="card-img-top" alt="<?= htmlspecialchars($p['name']) ?>">
                  <div class="card-body text-start d-flex flex-column">
                     <a href="produs.php?id=<?= (int)$p['product_id'] ?>">
                     <?= htmlspecialchars($p['name']) ?>
                     </a>
                     <p class="mb-1 text-small">
                        <i class="bi bi-check-circle-fill me-2"></i>În stoc
                     </p>
                     <?php if ((float)$p['discount'] > 0): ?>
                     <p class="text-secondary text-decoration-line-through mb-0">
                        <?= number_format($p['price'], 2, ',', '.') ?> lei
                     </p>
                     <p class="text-danger fw-bold fs-5">
                        <?= number_format($p['prez_efectiv'], 2, ',', '.') ?> lei
                     </p>
                     <?php else: ?>
                     <p class="text-black fs-5">
                        <?= number_format($p['price'], 2, ',', '.') ?> lei
                     </p>
                     <?php endif; ?>
                     <div class="mt-auto">
                        <button class="btn btn-danger w-100" data-id-produs="<?= (int)$p['product_id'] ?>">
                        Adaugă în coș
                        </button>
                     </div>
                  </div>
               </div>
            </div>
            <?php endforeach; ?>
         </div>
      </div>
      <?php if ($totalPages > 1): ?>
      <nav class="mt-4">
         <ul class="pagination justify-content-center">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
               <a class="page-link"
                  href="?id=<?= (int)$categoryId ?>&sort=<?= urlencode($sort) ?>&page=<?= max(1, $page - 1) ?>">
               Inapoi
               </a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= $i === $page ? 'active' : '' ?>">
               <a class="page-link"
                  href="?id=<?= (int)$categoryId ?>&sort=<?= urlencode($sort) ?>&page=<?= $i ?>">
               <?= $i ?>
               </a>
            </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
               <a class="page-link"
                  href="?id=<?= (int)$categoryId ?>&sort=<?= urlencode($sort) ?>&page=<?= min($totalPages, $page + 1) ?>">
               Inainte
               </a>
            </li>
         </ul>
      </nav>
      <?php endif; ?>
      <?php endif; ?>
      <!-- Coloana din stânga: FILTRE -->
      
   </div>
</div>
<?php include 'footer.php'; ?>