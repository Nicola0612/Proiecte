<?php
session_start();
require_once 'db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

$message = '';
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT pr.customer_id, pr.expires_at FROM password_resets pr WHERE pr.token = ? LIMIT 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (strtotime($row['expires_at']) > time()) {
            if (isset($_POST['new_password'])) {
                $newPass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                $stmt2 = $conn->prepare("UPDATE customers SET password=? WHERE customer_id=?");
                $stmt2->bind_param("si", $newPass, $row['customer_id']);
                $stmt2->execute();

                $stmt3 = $conn->prepare("DELETE FROM password_resets WHERE token=?");
                $stmt3->bind_param("s", $token);
                $stmt3->execute();

                $_SESSION['customer_id'] = $row['customer_id']; 
                header("Location: index.php");
                exit;
            }
        } else {
            $message = "Linkul a expirat!";
        }
    } else {
        $message = "Token invalid!";
    }
}
?>
     <?php 
      include 'header.php';
      ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body">
                    <h4 class="card-title mb-3 text-center">Setează parola nouă</h4>
                    <?php if($message){ echo "<div class='alert alert-danger'>$message</div>"; } ?>
                    <?php if(isset($row) && strtotime($row['expires_at']) > time()){ ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label>Parola noua</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Reseteaza parola</button>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
 <?php 
      include 'footer.php';
      ?>
