<?php
session_start();
require_once 'db.php';

$error = '';



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM customers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['customer_id'] = $row['customer_id'];
            $customerId = $_SESSION['customer_id'];
            // $response = ["success" => true, "message" => "Autentificare reușită!"];
            
            if (isset($_SESSION['guest_id'])) {
              $choice = $_POST['choice'] ?? 'keep';
                if ($choice === 'keep') {
                    
                    $sql = "UPDATE shopping_cart SET customer_id = ?, guest_id = NULL WHERE guest_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ii", $customerId, $_SESSION['guest_id']);
                    $stmt->execute();

                    
                    $getCart = $conn->prepare("SELECT cart_id FROM shopping_cart WHERE customer_id=? ORDER BY updated_at DESC LIMIT 1");
                    $getCart->bind_param("i", $customerId);
                    $getCart->execute();
                    $cartRes = $getCart->get_result();
                    if ($cartRow = $cartRes->fetch_assoc()) {
                        $_SESSION['cart_id'] = $cartRow['cart_id'];
                    }
                } else {
                    
                    $del = $conn->prepare("DELETE FROM shopping_cart WHERE guest_id=?");
                    $del->bind_param("i", $_SESSION['guest_id']);
                    $del->execute();

                    $newCart = $conn->prepare("INSERT INTO shopping_cart (customer_id, created_at, updated_at) VALUES (?, NOW(), NOW())");
                    $newCart->bind_param("i", $customerId);
                    $newCart->execute();
                    $_SESSION['cart_id'] = $newCart->insert_id;
                }
              
                unset($_SESSION['guest_id']);
            } else {
                
                if (!isset($_SESSION['cart_id'])) {
                    $stmt = $conn->prepare("INSERT INTO shopping_cart (customer_id, created_at, updated_at) VALUES (?, NOW(), NOW())");
                    $stmt->bind_param("i", $customerId);
                    $stmt->execute();
                    $_SESSION['cart_id'] = $stmt->insert_id;
                }
            }
            $redirect=$_GET['finalizare'] ?? 'index.php';
            header("Location:". $redirect); 
            exit;
        } else {
            $error = "Parolă incorectă!";
            // $response = ["success" => false, "message" => "Parolă incorectă!"];
        }
    } else {
        $error = "Email inexistent!";
    //     $response = ["success" => false, "message" => "Email inexistent!"];
     }
    // die(json_encode($response));
}
?>

   <?php 
      include 'header.php';
      ?>
      <br><br><br>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="card shadow">
          <div class="card-body">
            <h4 class="card-title mb-3 text-center">Login</h4>
            <form method="POST" id="loginForm">
              <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
              </div>
              <div class="mb-3">
                <label>Parola</label>
                <input type="password" name="password" class="form-control" required>
              </div>
              <div class="text-center mt-3">
                <a href="forgot_password.php">Ai uitat parola?</a>
              </div>

              <?php if(isset($_SESSION['guest_id'])){?>
                  <div class="mb-3">
                    <label class="form-check">Cosul tau</label>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="choice" value="keep" checked>
                  <label class="form-check-label">Păstrează coșul actual (guest)</label>
                </div>

                <div class="form-check">
                  <input class="form-check-input" type="radio" name="choice" value="new">
                  <label class="form-check-label">Creează un coș nou</label>
                </div>
              </div>
              <?php } ?>
              <button type="submit" class="btn btn-primary w-100">Autentificare</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
    <br><br><br>
   <?php 
      include 'footer.php';
      ?>

<!-- <script>
  $(document).ready(function() {

   
      $("#loginForm").submit(function(e){
         let $submitBtn = $(this).find("button[type=submit]");
        $submitBtn.prop('disabled', true);


         $.ajax({
            type: 'POST',
            url:"autentificare.php",
            dataType: 'json',
           data:($this).serialize,

            success: function(result) {
               if (result.success) {
                 $.growl.notice({ title:"Success",message: "Autentificare reusita!" });
               } else {
                  $.growl.error({ message: "EROAREEE!!!" });

               }

               $addButton.prop('disabled', false);
            }
      });
      });
   });
</script> -->
