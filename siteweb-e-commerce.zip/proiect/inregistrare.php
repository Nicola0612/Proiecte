<?php
session_start();
require_once 'db.php';

$success='';
$error='';
if(isset($_POST['form_submit']) && $_POST['form_submit']=='1'){
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $email=$_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $birthdate=$_POST['birth_date'];

    $street=$_POST['street_address'];
     $city=$_POST['city'];
     $county=$_POST['county'];
     $country=$_POST['country'];
    $postalcode=$_POST['postal_code'];
    $companyname=$_POST['company_name'];
    $cui=$_POST['tax_id'];

    $stmt=$conn->prepare("INSERT INTO customers (first_name,last_name,email,password,birth_date) VALUES(?,?,?,?,?)");
    $stmt->bind_param("sssss",  $first_name,$last_name,$email,$password,$birthdate);
    if($stmt->execute()){
        $customerid=$conn->insert_id;

        $stmt2=$conn->prepare("INSERT INTO addresses (customer_id,street_address,city,county,country,postal_code,company_name,tax_id) VALUES(?,?,?,?,?,?,?,?)");
    $stmt2->bind_param("isssssss", $customerid,$street,$city,$county,$country,$postalcode,$companyname,$cui);
    $stmt2->execute();

    $success="client inregistrat";

     $_SESSION['customer_id'] = $customerid;
       header("Location: index.php");
    exit;

    }else{
        $error="eroaree";
    }
}

$judete=$conn->query("SELECT DISTINCT judet FROM ps_rc_fancourier_cities ORDER BY judet ASC");
$localitati=$conn->query("SELECT judet, localitate FROM ps_rc_fancourier_cities ORDER BY judet,localitate ASC");
$localitatiData=[];
while($row=$localitati->fetch_assoc()){
  $localitatiData[$row['judet']][]=$row['localitate'];
}

?>

   <?php 
      include 'header.php';
      ?>
<div class="container mt-5">
  <h2 class="mb-4">Formular de Înregistrare Client</h2>

  <form method="POST" class="row g-3">
    <input type="hidden" name="form_submit" value="1">

    <h5>Date client</h5> 
    
    <div class="col-md-6">
      <label class="form-label">Prenume</label>
      <input type="text" name="first_name" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Nume</label>
      <input type="text" name="last_name" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Parola</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Data nasterii</label>
      <input type="date" name="birth_date" class="form-control">
    </div>

    <hr class="mt-4">
    <h5>Adresa de livrare</h5>
     <div class="col-md-6">
      <label class="form-label">CUI</label>
      <input type="text" name="tax_id" id="cui" class="form-control">
    </div>
     <div class="col-md-6">
      <label class="form-label">Nume companie</label>
      <input type="text" name="company_name" id="company_name" class="form-control">
    </div>
    <div class="col-md-6">
        <label class="form-label">Nr. Inregistrare</label>
          <input type="text" id="reg_com" name="reg_com" class="form-control" readonly>
    </div>
    <div class="col-md-4">
      <label class="form-label">Țara</label>
      <select name="country" id="country" class="form-select" required>
        <option value="">Alege țara</option>
        <option value="Romania">România</option>
        <option value="Altele">Altele</option>
      </select>
    </div>

    <div class="col-md-4">
      <label class="form-label">Județ</label>
      <select name="county" id="county" class="form-select" required disabled>
        <option value="">Selectează județ</option>
        <?php foreach($judete as $row){ ?>
          <option value="<?php echo $row['judet']; ?>">
        <?php echo $row['judet']; ?>
          </option>
      <?php } ?>
      </select>
    </div>

    <div class="col-md-4">
      <label class="form-label">Oraș</label>
      <select name="city" id="city" class="form-select" required disabled>
        <option value="">Selectează oraș</option>
      </select>
    </div>

    <div class="col-md-6">
      <label class="form-label">Strada si numar</label>
      <input type="text" id="street_address" name="street_address" class="form-control" required>
    </div>
    
    
    <div class="col-md-4">
      <label class="form-label">Cod postal</label>
      <input type="text" id="postal_code" name="postal_code" class="form-control">
    </div>
   

    <div class="col-12 mt-4">
      <button type="submit" class="btn btn-primary">Înregistrează client</button>
    </div>
  </form>
</div>
<br><br><br>
 <?php 
      include 'footer.php';
      ?>




<script>
$(document).ready(function(){
    var localitati = <?php echo json_encode($localitatiData); ?>;

    $('#country').change(function(){
        if($(this).val() === 'Romania'){
            $('#county').prop('disabled', false);
        }
    });

    $('#county').change(function(){
        var judet = $(this).val();
        if(judet && localitati[judet]){
            var opt = '<option value="">Selectează oraș</option>';
            $.each(localitati[judet], function(i, oras){
                opt += '<option value="'+oras+'">'+oras+'</option>';
            });
            $('#city').html(opt).prop('disabled', false);
        } else {
            $('#city').prop('disabled', true).html('<option value="">Selectează oraș</option>');
        }
    });
});


function removeDiacritics(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function capitalizeWords(str) {
    return str.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
}


    $("#cui").on("focusout",function(){
        const cui=$(this).val().trim();
        if(cui.length>0){
            $.ajax({
                url:'anaf.php',
                type:"POST",
                data:{cui:cui},
                dataType:"json",
                success:function(response){
                    console.log("Răspuns ANAF:", response);
                    if(response.success){
                        $("#company_name").val(response.data.denumire);
                        $("#reg_com").val(response.data.nrRegCom);
                        $("#street_address").val(response.data.sdenumire_Strada);
                        $('#postal_code').val(response.data.scod_Postal);

                        console.log("Setez judet:", response.data.sdenumire_Judet);
                        console.log("Setez oras:", response.data.sdenumire_Localitate);
                        let rawJudet = response.data.sdenumire_Judet.trim();
                        let judetFaraDiacritice = removeDiacritics(rawJudet.toUpperCase());
                        let judetFinal = "";

                        if (judetFaraDiacritice === "MUNICIPIUL BUCURESTI") {
                            judetFinal = "Bucuresti";
                        } else if (judetFaraDiacritice === "BISTRITA-NASAUD" || judetFaraDiacritice === "BISTRITA NASAUD") {
                            judetFinal = "Bistrita-Nasaud";
                        } else if (judetFaraDiacritice === "CARAS-SEVERIN" || judetFaraDiacritice === "CARAS SEVERIN") {
                            judetFinal = "Caras-Severin";
                        } else {
                            judetFinal = capitalizeWords(removeDiacritics(rawJudet.toLowerCase()));
                        }       

                    $("#county").val(judetFinal).trigger('change');
                    console.log("Setez judet:", judetFinal);

                    
                    let rawOras = response.data.sdenumire_Localitate.trim();
                    let parts = rawOras.split('.');
                    let orasFinal = parts[parts.length - 1].trim();
                    orasFinal = capitalizeWords(removeDiacritics(orasFinal.toLowerCase()));

                    setTimeout(function () {
                        $("#city").val(orasFinal);
                        console.log("Setez oras:", orasFinal);
                    }, 300);
                    }else{
                        alert("CUI invalid sau comapnia nu a fost gasita");
                    }
                },
                error:function(){
                    alert("eroare la conectarea cu ANAF");
                }
            });
        }
    });

</script>