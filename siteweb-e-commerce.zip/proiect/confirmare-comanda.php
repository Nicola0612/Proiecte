<?php
session_start();
require_once 'db.php';

$orderId = $_GET['order_id'] ?? null;

if (!$orderId) {
    header("Location: index.php");
    exit;
}


$stmt = $conn->prepare("
    SELECT o.order_reference, o.total_products, o.total_payment, a.street_address, a.city, a.county, a.postal_code, a.company_name, a.tax_id
    FROM orders o
    JOIN addresses a ON o.address_id = a.address_id
    WHERE o.order_id = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: index.php");
    exit;
}

$stmtItems = $conn->prepare("
    SELECT product_name, quantity, price_final
    FROM order_items
    WHERE order_id = ?
");
$stmtItems->bind_param("i", $orderId);
$stmtItems->execute();
$items = $stmtItems->get_result()->fetch_all(MYSQLI_ASSOC);

include 'header.php';
?>
<div class="container my-5 text-center">
    <h2 class="text-success fw-bold">Comanda a fost plasată cu succes!</h2>
    <p>Mulțumim pentru achiziție! Codul comenzii tale este: <strong><?= htmlspecialchars($order['order_reference']) ?></strong></p>

    <h5>Adresa de livrare</h5>
    <p>
        <?= htmlspecialchars($order['street_address']) ?>, <?= htmlspecialchars($order['city']) ?>, <?= htmlspecialchars($order['county']) ?><br>
        <?= htmlspecialchars($order['postal_code']) ?><br>
        <?php if ($order['company_name']): ?>
            <strong><?= htmlspecialchars($order['company_name']) ?></strong> (CUI: <?= htmlspecialchars($order['tax_id']) ?>)
        <?php endif; ?>
    </p>

    <a href="index.php" class="btn btn-primary mt-3">Înapoi la Magazin</a>
</div>
<?php include 'footer.php'; ?>
