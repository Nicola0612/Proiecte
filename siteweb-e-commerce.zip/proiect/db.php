<?php
$servername = "localhost";
$database="proiect";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

$products = $result->fetch_all(MYSQLI_ASSOC);

DataBase::set($conn);

class DataBase{
  public $sql;
  //global$conn;
  private static $conn;


  public static function set($mysqli){
    self::$conn=$mysqli;
  }


  private static function executeStatement($query, $params = []) {
        $stmt = self::$conn->prepare($query);
        if (!$stmt) {
            die("Eroare prepare: " . self::$conn->error);
        }

        if (!empty($params)) {
            $types = str_repeat('s', count($params)); 
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        return $stmt;
    }
  public static function getAll($query,$params=[]){
    
     $stmt = self::executeStatement($query, $params);
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);

  }

  public static function getValue($query, $params=[]){
    
    $stmt = self::executeStatement($query, $params);
        $result = $stmt->get_result();
        $row = $result->fetch_row();
        return $row[0] ?? null;
  }

  public static function getRow($query, $params=[]){
    
    $stmt = self::executeStatement($query, $params);
        $result = $stmt->get_result();
        return $result->fetch_assoc();
  }
}


class Product {
    public static function getProducts($limit = 10, $category_id = null, $sort_by = null, $order = 'ASC') {
        $query = "SELECT * FROM products";
        $params = [];

        $where = [];

        if ($category_id !== null) {
            $where[] = "category_id = ?";
            $params[] = $category_id;
        }

        if (!empty($where)) {
            $query .= " WHERE " . implode(" AND ", $where);
        }

        if ($sort_by !== null) {
            $query .= " ORDER BY `$sort_by` " . (strtoupper($order) === 'DESC' ? 'DESC' : 'ASC');
        }

        $query .= " LIMIT ?";
        $params[] = (int)$limit;

        return DataBase::getAll($query, $params);
    }

    public static function getDiscountProducts() {
        $query = "SELECT * FROM products WHERE discount > 0";
        return DataBase::getAll($query);
    }

    public static function getProductsByCategory($category_id) {
      $query = "SELECT * FROM products WHERE category_id = ?";
      return DataBase::getAll($query, [$category_id]);
  }
   public static function getProductsByCategoryanddiscount($category_id) {
      $query = "SELECT * FROM products WHERE category_id = ? AND discount >0";
      return DataBase::getAll($query, [$category_id]);
  }


}

// if ($result->num_rows > 0) {
//   // output data of each row
//   while($row = $result->fetch_assoc()) {
//     echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
//   }
// } else {
//   echo "0 results";
// }
//$conn->close();
?>