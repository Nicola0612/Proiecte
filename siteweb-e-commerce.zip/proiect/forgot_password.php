<?php
session_start();
require_once 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

$message = '';

if (isset($_POST['forgot_password'])) {
    $email = $_POST['email'];
    $stmt = $conn->prepare("SELECT customer_id FROM customers WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        $token = bin2hex(random_bytes(16));
        $expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

        
        $stmt2 = $conn->prepare("INSERT INTO password_resets (customer_id, token, expires_at) VALUES (?, ?, ?)");
        $stmt2->bind_param("iss", $user['customer_id'], $token, $expires);
        $stmt2->execute();

        
        $resetLink = "http://localhost/proiect/reset_passsword.php?token=" . $token;
       $mail = new PHPMailer(true);

        try {
           
            $mail->isSMTP();
            $mail->Host = 'sandbox.smtp.mailtrap.io'; 
            $mail->SMTPAuth = true;
            $mail->Username = '48c1beb3fab6c6'; 
            $mail->Password = '46b28686d24d29';  
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 2525;

            $mail->setFrom('andreeanicola2003@gmail.com', 'Mailer');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Resetare parola';
            $mail->Body = "Apasa pe link pentru resetarea parolei:<br>
                           <a href='$resetLink'>$resetLink</a>";
            $v=$mail->send();
            exit;
            $message = "Ți-am trimis un email cu instrucțiunile de resetare!";
        } catch (Exception $e) {
            $message = "Eroare la trimiterea emailului: {$mail->ErrorInfo}";
        }
    } else {
        $message = "Nu există un cont cu acest email!";
    }
}
?>

     <?php 
      include 'header.php';
      ?>
      <br><br><br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body">
                    <h4 class="card-title mb-3 text-center">Recuperează parola</h4>
                    <?php if($message){ echo "<div class='alert alert-info'>$message</div>"; } ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <button type="submit" name="forgot_password" class="btn btn-primary w-100">Trimite link</button>
                    </form>
                    <div class="mt-3 text-center">
                        <a href="autentificare.php">Inapoi la autentificare</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   <br><br><br>
 <?php 
      include 'footer.php';
      ?>
