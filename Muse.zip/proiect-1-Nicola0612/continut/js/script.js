var canvas, ctx;
var startX, startY;
var isDrawing = false;
var rectangles = [];


var selectedCell = null;
var tableHistory = [];
var lastCellColor = null;


function start() {
    init();
    initTable();
    f();
    setInterval(f, 1000);
    drawInitialContent();
}

function init() {
    canvas = document.getElementById('myCanvas');
    ctx = canvas.getContext('2d');

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mouseup', handleMouseUp);
}

function handleMouseDown(event) {
    startX = event.offsetX;
    startY = event.offsetY;
    isDrawing = true;
}

function handleMouseUp(event) {
    if (!isDrawing) return;

    const endX = event.offsetX;
    const endY = event.offsetY;

    rectangles.push({
        x1: Math.min(startX, endX),
        y1: Math.min(startY, endY),
        x2: Math.max(startX, endX),
        y2: Math.max(startY, endY),
        borderColor: document.getElementById('border').value,
        fillColor: document.getElementById('fill').value
    });

    redrawCanvas();
    isDrawing = false;
}

function drawRectangle(rect) {
    const width = rect.x2 - rect.x1;
    const height = rect.y2 - rect.y1;

    ctx.strokeStyle = rect.borderColor;
    ctx.fillStyle = rect.fillColor;
    ctx.lineWidth = 3;

    ctx.beginPath();
    ctx.rect(rect.x1, rect.y1, width, height);
    ctx.fill();
    ctx.stroke();
}

function redrawCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);


    drawInitialContent();

    rectangles.forEach(rect => {
        drawRectangle(rect);
    });
}

function drawInitialContent() {
    ctx.font = '16px Arial';
    ctx.fillStyle = '#0000102';
    ctx.fillText('Desenează aici!', 10, 30);


}

function clearCanvas() {
    rectangles = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawInitialContent();
}


function f() {
    const d = new Date();
    document.getElementById("data").innerHTML = "Timp: " + d.toLocaleTimeString();

    let origin = window.location.href;
    document.getElementById("location").innerHTML = "URL: " + origin;

    let language = window.navigator.language;
    document.getElementById("navigator").innerHTML = "Limba: " + language;



    let agent = navigator.userAgent;
    document.getElementById("ceva").innerHTML = agent;

}

function initTable() {
    document.getElementById('addRowBtn').addEventListener('click', addRow);
    document.getElementById('addColBtn').addEventListener('click', addColumn);


    document.getElementById('inventoryTable').addEventListener('click', (e) => {
        const cell = e.target.closest('td, th');
        if (cell) {
            if (selectedCell) {
                selectedCell.style.backgroundColor = lastCellColor;
                selectedCell.classList.remove('selected');
            }
            lastCellColor = cell.style.backgroundColor || '';
            selectedCell = cell;
            cell.classList.add('selected');
        }
    });

    document.getElementById('inventoryTable').addEventListener('focusout', (e) => {
        const cell = e.target.closest('td, th');
        if (cell && cell.isContentEditable) {
            cell.style.backgroundColor = lastCellColor;
        }
    });
}


function addRow() {
    const table = document.getElementById('inventoryTable');
    const rowPos = parseInt(document.getElementById('rowPos').value) || table.rows.length;
    const color = document.getElementById('rowColor').value;
    const content = document.getElementById('rowContent').value || "Nou";
    const newRow = table.insertRow(rowPos - 1);


    for (let i = 0; i < table.rows[0].cells.length; i++) {
        const cell = newRow.insertCell(i);
        cell.textContent = content;
        cell.contentEditable = true;
        cell.style.backgroundColor = color;

        cell.dataset.originalColor = color;
    }
    document.getElementById('rowContent').value = "";
}


function addColumn() {
    const table = document.getElementById('inventoryTable');
    const colPos = parseInt(document.getElementById('colPos').value) || table.rows[0].cells.length;
    const color = document.getElementById('colColor').value;
    const content = document.getElementById('colContent').value || "Nou";

    for (let i = 0; i < table.rows.length; i++) {
        const cell = table.rows[i].insertCell(colPos - 1);
        if (i === 0) {
            cell.textContent = content || "Detaliu";
            cell.style.fontWeight = "bold";
        } else {
            cell.textContent = content;
            cell.contentEditable = true;
        }
        cell.style.backgroundColor = color;
        cell.dataset.originalColor = color;
    }
    document.getElementById('colContent').value = "";
}

function loadDoc() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("demo").innerHTML =
                this.responseText;
        }
    };
    xhttp.open("GET", "ajax_info.txt", true);
    xhttp.send();
}



function inregistreazaUtilizator() {
    const formData = new FormData();
    formData.append('utilizator', document.getElementById('utilizator').value);
    formData.append('parola', document.getElementById('parola').value);
    formData.append('nume', document.getElementById('nume').value);
    formData.append('prenume', document.getElementById('prenume').value);
    formData.append('email', document.getElementById('email').value);
    formData.append('phone', document.getElementById('phone').value);
    formData.append('gen', document.getElementById('gen').value);
    formData.append('preferata', document.getElementById('preferata').value);
    formData.append('color', document.getElementById('color').value);
    formData.append('nastere', document.getElementById('nastere').value);
    formData.append('ora', document.getElementById('ora').value);
    formData.append('varsta', document.getElementById('varsta').value);
    formData.append('adresa', document.getElementById('adresa').value);
    formData.append('descriere', document.getElementById('descriere').value);

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/api/utilizatori", true);
    xhttp.setRequestHeader("Content-Type", "application/json");

    xhttp.onreadystatechange = function () {
        if (xhttp.readyState === 4 && xhttp.status === 200) {
            alert("Utilizator înregistrat cu succes!");

        }
    };


    const formObject = {};
    formData.forEach((value, key) => {
        formObject[key] = value;
    });
    const jsonData = JSON.stringify(formObject);

    xhttp.send(jsonData);
}

function verificaUtilizator() {
    var utilizator = document.getElementById("utilizator").value;
    var parola = document.getElementById("parola").value;

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var utilizatori = JSON.parse(this.responseText);
            var mesaj = "Utilizatorul sau parola sunt incorecte.";
            for (var i = 0; i < utilizatori.length; i++) {
                if (utilizatori[i].utilizator === utilizator && utilizatori[i].parola === parola) {
                    mesaj = "Autentificare reușită!";
                    break;
                }
            }
            document.getElementById("rezultat").innerText = mesaj;
        }
    };
    xhttp.open("GET", "resurse/utilizatori.json", true);
    xhttp.send();
}