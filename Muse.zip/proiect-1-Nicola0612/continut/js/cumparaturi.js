class Produs {
    constructor(nume, cantitate, id) {
        this.nume = nume;
        this.cantitate = cantitate;
        this.id = id;
    }
}

class Stocare {
    constructor() {
        this.listaCumparaturi = [];
    }

    adaugaProdus(produs) {
        this.listaCumparaturi.push(produs);
        this.salvare();
    }

    salvare() {
    }


    citesteLista() {
        return this.listaCumparaturi;
    }
}

class StocareLocalStorage extends Stocare {
    constructor() {
        super();
        this.listaCumparaturi = JSON.parse(localStorage.getItem('listaCumparaturi')) || [];
    }
    salvare() {
        localStorage.setItem('listaCumparaturi', JSON.stringify(this.listaCumparaturi));
    }
}

class StocareIndexedDB extends Stocare {
    constructor() {
        super();
        this.db = null;
        this.deschideBazaDeDate();
    }
    deschideBazaDeDate() {
        const request = indexedDB.open('CumpărăturiDB', 1);

        request.onupgradeneeded = (event) => {
            this.db = event.target.result;
            if (!this.db.objectStoreNames.contains('produse')) {
                this.db.createObjectStore('produse', { keyPath: 'id' });
            }
        };

        request.onsuccess = (event) => {
            this.db = event.target.result;
            this.citesteLista();
        };

        request.onerror = (event) => {
            console.error("Eroare la deschiderea bazei de date IndexedDB", event);
        };
    }

    salvare() {
        const transaction = this.db.transaction(['produse'], 'readwrite');
        const store = transaction.objectStore('produse');

        this.listaCumparaturi.forEach(produs => {
            store.put(produs);
        });

        transaction.oncomplete = () => {
            console.log("Lista a fost salvată în IndexedDB");
        };

        transaction.onerror = (event) => {
            console.error("Eroare la salvarea datelor în IndexedDB", event);
        };
    }

    citesteLista() {
        const transaction = this.db.transaction(['produse'], 'readonly');
        const store = transaction.objectStore('produse');
        const request = store.getAll();

        request.onsuccess = (event) => {
            this.listaCumparaturi = event.target.result;
            afiseazaListaCumparaturi();
        };
    }
}

const worker = new Worker('js/worker.js');

let stocare;
function selecteazaStocare() {
    const stocareSelectata = document.querySelector('input[name="stocare"]:checked').value;
    if (stocareSelectata === 'localStorage') {
        stocare = new StocareLocalStorage();
    } else if (stocareSelectata === 'indexedDB') {
        stocare = new StocareIndexedDB();
    }
}

function adaugaProdus() {
    if (!stocare) {
        selecteazaStocare();
    }

    const nume = document.getElementById('nume').value;
    const cantitate = document.getElementById('cantitate').value;
    const id = new Date().getTime();

    if (nume && cantitate) {
        const produs = new Produs(nume, cantitate, id);

        stocare.adaugaProdus(produs);
        afiseazaListaCumparaturi();
        worker.postMessage(produs);
    } else {
        alert("Completează toate câmpurile!");
    }
}
function afiseazaListaCumparaturi() {
    const listaCumparaturi = stocare.citesteLista();
    const tabelElement = document.getElementById('tabel-cumparaturi').getElementsByTagName('tbody')[0];
    tabelElement.innerHTML = '';

    listaCumparaturi.forEach((produs, index) => {
        const tr = document.createElement('tr');

        const nrTd = document.createElement('td');
        nrTd.textContent = index + 1;
        tr.appendChild(nrTd);

        const numeTd = document.createElement('td');
        numeTd.textContent = produs.nume;
        tr.appendChild(numeTd);

        const cantitateTd = document.createElement('td');
        cantitateTd.textContent = produs.cantitate;
        tr.appendChild(cantitateTd);
        tabelElement.appendChild(tr);
    });
}

const stergeLista = () => {
    if (stocare instanceof StocareLocalStorage) {
        localStorage.removeItem('listaCumparaturi');
    } else if (stocare instanceof StocareIndexedDB) {
        const transaction = stocare.db.transaction(['produse'], 'readwrite');
        const store = transaction.objectStore('produse');
        const request = store.clear();

        request.onsuccess = () => {
            console.log("Lista a fost stearss din IndexedDB");
        };

        request.onerror = (event) => {
            console.error("Eroare la stergerea din IndexedDB", event);
        };
    }

    afiseazaListaCumparaturi();
};

worker.addEventListener('message', function (e) {
    console.log('Mesaj de la Worker:', e.data);
});

function initializeazaStocare() {
    selecteazaStocare();
    afiseazaListaCumparaturi();
}
