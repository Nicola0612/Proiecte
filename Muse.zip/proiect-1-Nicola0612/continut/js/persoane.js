function incarcaPersoane() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            console.log('Cererea a fost efectuată cu succes');
            try {
                var xmlDoc = this.responseXML;


                if (!xmlDoc || !xmlDoc.getElementsByTagName("persoana").length) {
                    throw new Error("XML invalid sau gol");
                }

                var persoane = xmlDoc.getElementsByTagName("persoana");
                var html = '<table class="persoane-table">';
                html += '<thead><tr>';
                html += '<th>ID</th><th>Nume</th><th>Prenume</th>';
                html += '<th>Vârstă</th><th>Adresă</th><th>Telefon</th>';
                html += '</tr></thead><tbody>';

                for (var i = 0; i < persoane.length; i++) {
                    var p = persoane[i];
                    var adresa = p.getElementsByTagName("adresa")[0];

                    html += '<tr>';
                    html += '<td>' + p.getAttribute("id") + '</td>';
                    html += '<td>' + getNodeValue(p, "nume") + '</td>';
                    html += '<td>' + getNodeValue(p, "prenume") + '</td>';
                    html += '<td>' + getNodeValue(p, "varsta") + '</td>';
                    html += '<td>' +
                        getNodeValue(adresa, "strada") + ' ' +
                        getNodeValue(adresa, "numar") + ', ' +
                        getNodeValue(adresa, "localitate") + ', ' +
                        getNodeValue(adresa, "tara") +
                        '</td>';
                    html += '<td>' + getNodeValue(p, "telefon") + '</td>';
                    html += '</tr>';
                }

                html += '</tbody></table>';
                document.getElementById("continut").innerHTML = html;
            } catch (e) {
                console.error("Eroare la procesarea XML:", e);

            }

        }
    };

    xhttp.open("GET", "resurse/persoane.xml", true);
    xhttp.send();
}


function getNodeValue(parent, tagName) {
    var node = parent.getElementsByTagName(tagName)[0];
    return node ? node.childNodes[0].nodeValue : '';
}