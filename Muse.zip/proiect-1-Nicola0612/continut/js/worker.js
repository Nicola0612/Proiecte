
self.addEventListener('message', function (e) {
    const produs = e.data;
    console.log('Mesaj primit în Worker:', produs);
    self.postMessage(`Produsul ${produs.nume} a fost adăugat în lista de cumpărături.`);
});
