import socket
import json
import os
import gzip
import threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

def get_content_type(resursa):
    extensii = {
        'html': 'text/html; charset=utf-8',
        'css': 'text/css; charset=utf-8',
        'js': 'application/javascript; charset=utf-8',
        'json': 'application/json; charset=utf-8',
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'gif': 'image/gif',
        'ico': 'image/x-icon',
        'xml': 'application/xml; charset=utf-8',
        'txt': 'text/plain; charset=utf-8'
    }
    extensie = resursa.split('.')[-1].lower()
    return extensii.get(extensie, 'text/plain; charset=utf-8')

def handle_client(clientsocket, address):
    try:
        cerere = clientsocket.recv(1024).decode('utf-8', errors='ignore')
        if not cerere:
            return

        linie_start = cerere.split('\r\n')[0]
        parti = linie_start.split()
        if len(parti) < 2:
            return

        metoda, resursa = parti[0], parti[1]

        if resursa == "/":
            resursa = "/index.html"

       
        if metoda == "POST" and resursa == "/api/utilizatori":
            content_length = 0
            for linie in cerere.split('\r\n'):
                if linie.lower().startswith("content-length"):
                    content_length = int(linie.split(":")[1].strip())
            
           
            body = cerere[-content_length:].strip()

            try:
                
                utilizator = json.loads(body)

                
                fisier_utilizatori = 'continut/resurse/utilizatori.json'
                if os.path.exists(fisier_utilizatori):
                    with open(fisier_utilizatori, 'r', encoding='utf-8') as f:
                        utilizatori = json.load(f)
                else:
                    utilizatori = []

                
                utilizatori.append(utilizator)

                
                with open(fisier_utilizatori, 'w', encoding='utf-8') as f:
                    json.dump(utilizatori, f, indent=4, ensure_ascii=False)

                
                raspuns = {
                    "status": "succes",
                    "mesaj": "Utilizatorul a fost înregistrat cu succes."
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 200 OK\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))
                return

            except json.JSONDecodeError as e:
                
                print(f"[{threading.current_thread().name}] Eroare la parsarea JSON: {str(e)}")
                raspuns = {
                    "status": "eroare",
                    "mesaj": "Datele trimise nu sunt într-un format JSON valid."
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 400 Bad Request\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))

            except Exception as e:
               
                print(f"[{threading.current_thread().name}] Eroare: {str(e)}")
                raspuns = {
                    "status": "eroare",
                    "mesaj": f"A apărut o eroare la procesarea cererii: {str(e)}"
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 500 Internal Server Error\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))
                return

        
        cale_fisier = os.path.abspath(os.path.join("continut", resursa.lstrip('/')))
        if os.path.isfile(cale_fisier):
            with open(cale_fisier, 'rb') as f:
                continut = f.read()

            content_type = get_content_type(resursa)
            if resursa.endswith('.xml'):
                
                try:
                    from xml.dom.minidom import parseString
                    parseString(continut.decode('utf-8'))
                except Exception as e:
                    print(f"XML invalid: {str(e)}")
                    raise ValueError("Fișier XML invalid")
            
            accepta_gzip = 'gzip' in cerere.lower()

            if accepta_gzip and content_type.startswith(('text/', 'application/')):
                continut = gzip.compress(continut)
                headers = (
                    f"HTTP/1.1 200 OK\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: {content_type}\r\n"
                    f"Content-Encoding: gzip\r\n"
                    f"Content-Length: {len(continut)}\r\n"
                    f"\r\n"
                )
            else:
                headers = (
                    f"HTTP/1.1 200 OK\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: {content_type}\r\n"
                    f"Content-Length: {len(continut)}\r\n"
                    f"\r\n"
                )

            clientsocket.sendall(headers.encode('utf-8') + continut)
        else:
            mesaj_eroare = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Eroare 404</title>
                <style>body {{ font-family: Arial; padding: 20px; }}</style>
            </head>
            <body>
                <h1> Eroare 404</h1>
            </body>
            </html>
            """.encode('utf-8')

            headers = (
                f"HTTP/1.1 404 Not Found\r\n"
                f"Content-Type: text/html; charset=utf-8\r\n"
                f"Content-Length: {len(mesaj_eroare)}\r\n"
                f"\r\n"
            )
            clientsocket.sendall(headers.encode('utf-8') + mesaj_eroare)
    
    except Exception as e:
        print(f"[{threading.current_thread().name}]  Eroare: {str(e)}")
        mesaj_eroare = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Eroare 500</title>
        </head>
        <body>
            <h1>Eroare Internă a Serverului</h1>
            <p>Detalii eroare: {str(e)}</p>
        </body>
        </html>
        """.encode('utf-8')

        headers = (
            f"HTTP/1.1 500 Internal Server Error\r\n"
            f"Content-Type: text/html; charset=utf-8\r\n"
            f"Content-Length: {len(mesaj_eroare)}\r\n"
            f"\r\n"
        )
        clientsocket.sendall(headers.encode('utf-8') + mesaj_eroare)
    finally:
        clientsocket.close()

def run_server():
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as serversocket:
        serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        serversocket.bind(('localhost', 5678))
        serversocket.listen(10)  
        print("\n Serverul rulează pe portul 5678 (http://localhost:5678)")
        print(f" Director curent: {os.getcwd()}")
        with ThreadPoolExecutor(max_workers=10) as executor:
            while True:
                clientsocket, address = serversocket.accept()
                executor.submit(handle_client, clientsocket, address)

if __name__ == '__main__':
    run_server()
