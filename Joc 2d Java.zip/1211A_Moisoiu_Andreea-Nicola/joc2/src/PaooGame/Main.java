package PaooGame;

public class Main {
    public static void main(String[] args) {
        Game paooGame = Game.getInstance("În căutarea ștrumfiței", 960, 768);
        paooGame.StartGame();
    }
}