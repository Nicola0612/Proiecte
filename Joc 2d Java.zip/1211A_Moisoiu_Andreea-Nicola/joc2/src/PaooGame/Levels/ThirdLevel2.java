package PaooGame.Levels;
import PaooGame.Collision.Heart;
import PaooGame.Collision.SuperObject;
import PaooGame.Game;
import PaooGame.KeyHandler.KeyHandler;
import PaooGame.Tiles.Tile;
import PaooGame.Tiles.TileFlyweight;
import PaooGame.Tiles.TileFlyweightFactory;


import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import static PaooGame.Collision.HelpMethods.CanMoveHere;
import static PaooGame.Game.strumf2;
import static PaooGame.Game.strumf3;

public class ThirdLevel2 {
    private static Graphics g;


    private int aniIndex, aniSpeed;
    public boolean hasJumped=false;
    public int velocityX=-4;
    public static double velocityY = 0;
    double gravity = 0.5;
    double damping=0.5;

    private int cameraX = 0;
    private int cameraY = 0;
    //public static int[][] table;// matrice tabela joc
    private static TileFlyweight[][] table;
    private int gameWidth;//lungimea ferestrei
    private int gameHeigth;// inaltimea ferestre;
    private int widthInTiles;//lungime tile
    private int heigthInTiles;//inaltime tile
 private int borderDepth;//grosime bordura;
    public static double score = 0;
    public boolean started = false;
    public static boolean jump;
    public static boolean winned = false;
    public static boolean gameover = false;
    private boolean isPaused = false;
    public static boolean restart=false;
    long start;
    long stop;
    long timeElapsed;
    private long pauseStartTime;
    private long totalPauseTime;
    public static int mapNum[][];
    // imagini pentru viață (plin/gol)
    BufferedImage heart_full, heart_blank;

    public ThirdLevel2(int gameWidth, int gameHeigth) {
        this.gameHeigth = gameHeigth;

        this.gameWidth = gameWidth;
        widthInTiles = gameWidth / Tile.TILE_WIDTH;
        heigthInTiles = gameHeigth / Tile.TILE_HEIGTH;
        borderDepth = 2;
        mapNum = new int[Game.maxRow + 1][Game.maxCol + 1];
        //table = new int[Game.maxRow + 1][Game.maxCol+ 1];
        table = new TileFlyweight[Game.maxRow + 1][Game.maxCol + 1];
        SuperObject heart=new Heart(g);
        heart_full=heart.image;
        heart_blank=heart.image3;
        loadThirdMap();
        DrawThirdTable();
    }

    public void loadThirdMap() {
        try {
            InputStream is = getClass().getResourceAsStream("/map05.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col = 0;
            int row = 0;
            while (col < Game.maxCol && row < Game.maxRow) {
                String line = br.readLine();
                while (col < Game.maxCol) {
                    String numbers[] = line.split(" ");
                    int num = Integer.parseInt(numbers[col]);
                    if (num == 0) {
                        mapNum[row][col] = 6;
                    } else {
                        mapNum[row][col] = num;
                    }
                    col++;

                }
                if (col == Game.maxCol) {
                    col = 0;
                    row++;
                }
            }
            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DrawThirdTable() {
        int col = 0;
        int row = 0;
        int x = 0;
        int y = 0;
        for (int i = 0; i < Game.maxRow; ++i) {
            for (int j = 0; j < Game.maxCol; ++j) {

                int tileId = mapNum[i][j];
                table[i][j] = TileFlyweightFactory.getTileFlyweight(tileId);
            }
        }
    }

    public void DrawMap(Graphics g) {
        this.g = g;

        for (int i = 0; i < Game.maxRow; ++i) {
            for (int j = 0; j < Game.maxCol; ++j) {
                int tileX=j*Tile.TILE_WIDTH-Game.cameraX;
                int tileY=i*Tile.TILE_HEIGTH-Game.cameraY;
                if(tileX + Tile.TILE_WIDTH < 0 || tileX >Game.SCREEN_WIDTH ||
                tileY + Tile.TILE_HEIGTH < 0 || tileY > Game.SCREEN_HEIGHT ) {
                // Dacă dala este în afara ecranului, nu o desenăm
                continue;
                }
                //Tile.tiles[table[i][j]].Draw(g, j * Tile.TILE_WIDTH, i * Tile.TILE_HEIGTH);
                //Tile.tiles[table[i][j]].Draw(g,tileX,tileY);
                TileFlyweight tile = table[i][j];
                if (tile != null) {
                    tile.Draw(g, tileX, tileY);
                }
            }
        }
        drawPlayerLife();
    }
    //viata strumf
    public void drawPlayerLife() {

        int x=Tile.TILE_HEIGTH/2;
        int y=Tile.TILE_WIDTH/2;
        int i=0;
        //draw blank heart
        while(i< strumf3.maxLife){
            g.drawImage(heart_blank,x,y,null);
            i++;
            x+=Tile.TILE_WIDTH;
        }
        //reset
        x=Tile.TILE_WIDTH/2;
        y=Tile.TILE_HEIGTH/2;
        i=0;
        //draw current life
        while(i<strumf3.life){

            if(i<strumf3.life){
                g.drawImage(heart_full,x,y,null);

            }
            i++;
            x+=Tile.TILE_WIDTH;
        }

    }
    public void Update() {
        KeyHandler keyH = Game.wnd.getKeyHandler();

        //se misca strumful
       // System.out.println("Pozitie initiala: X=" + strumf3.strumfPozX + ", Y=" + strumf3.strumfPozY);
        if(!isPaused) {
            stop = System.currentTimeMillis();
            timeElapsed = stop - Game.start - totalPauseTime;
            if (keyH.rightPressed == true || keyH.leftPressed == true) {
                if (keyH.leftPressed == true) {
                    if (CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX - strumf3.speed, strumf3.solidArea.y + strumf3.strumfPozY, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
                        if (strumf3.strumfPozX - Game.strumf.speed >= 0) {
                            Game.strumf3.strumfPozX -= 2;
                        }
                        Game.strumf3.direction = "left";
                        applyGravity();
                    } else {
                        System.out.println("coliziune detectata STANGA");
                    }

                } else if (keyH.rightPressed == true) {
                    if (CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX + strumf3.speed, strumf3.solidArea.y + strumf3.strumfPozY, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
                        if (strumf3.strumfPozX + strumf3.speed <= gameWidth - strumf3.strumfWidth) {
                            strumf3.strumfPozX += 1;
                        }
                        strumf3.direction = "right";
                        applyGravity();
                    } else {
                        System.out.println("coliziune detectata DREAPTA");
                    }
                }


                strumf3.counter++;
                if (strumf3.counter > 20) {
                    if (strumf3.num == 1)
                        strumf3.num = 2;
                    else if (strumf3.num == 2)
                        strumf3.num = 1;
                    strumf3.counter = 0;
                }

            }
            if (keyH.spacePresssed == true && hasJumped == false) {

                if (keyH.upPressed == true) {
                    velocityX = 0; // sare doar în sus
                } else {
                    velocityX = 2; // sari spre dreapta
                }

                jump();
                strumf3.direction = "jump";
            }


            if (strumf3.inAir) {
                applyGravity();
            }
            if (CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX, strumf3.solidArea.y + strumf3.strumfPozY + strumf3.speed, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
                move();
            }
            // verifică dacă strumf-ul a căzut în apă
            if (strumf3.strumfPozX >= 192 && strumf3.strumfPozX <= 2880 && strumf3.strumfPozY >= 672 && strumf3.strumfPozY<=768) {
                strumf3.life--;
                if (strumf3.life == 0) {
                    gameover = true;
                    isPaused = true;

                } else {
                    Game.getInstance(null,0,0).restartlevel3();
                }
            }
        }


        if (Game.wnd.gameState == Game.wnd.pauseState3) {
            if (!isPaused) {
                pauseStartTime = System.currentTimeMillis();
                isPaused = true;
            }
            return;
        }
         else {
            if (isPaused) {
                long pauseEndTime = System.currentTimeMillis();
                totalPauseTime += (pauseEndTime - pauseStartTime);
                isPaused = false;
            }
        }
         if(strumf3.strumfPozX>3024){
             Win();
             isPaused=true;
         }
        if(strumf3.life<=0){
            gameover=true;
            isPaused=true;
        }
         updateCamera();
    }
    //metoda pt actualizarea camerei
    private void updateCamera() {
        KeyHandler keyH = Game.wnd.getKeyHandler();
        if (Game.countLevel == 3) { // Verificăm dacă suntem în nivelul 3
            // calculăm noile coordonate ale camerei
            Game.cameraX = Math.max(0, Math.min(strumf3.strumfPozX - Game.SCREEN_WIDTH / 2, Game.worldWidth - Game.SCREEN_WIDTH));
            Game.cameraY = Math.max(0, Math.min(strumf3.strumfPozY - Game.SCREEN_HEIGHT / 2, Game.worldHeight - Game.SCREEN_HEIGHT));

            //vedem daca strumful se poate mișca până la marginea hărții
            if (strumf3.strumfPozX < Game.cameraX) {
                strumf3.strumfPozX = Game.cameraX;


            }
            if (strumf3.strumfPozX > Game.cameraX ) {
                if(keyH.rightPressed){
                if (CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX + strumf3.speed, strumf3.solidArea.y + strumf3.strumfPozY, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
                    if (strumf3.strumfPozX + strumf3.speed <= 3120 - strumf3.strumfWidth) {
                        strumf3.strumfPozX += 2;
                    }
                    strumf3.direction = "right";
                    applyGravity();
                } else {
                    System.out.println("coliziune detectata DREAPTA");
                }
            }
            }
            if (strumf3.strumfPozY < Game.cameraY) {
                strumf3.strumfPozY = Game.cameraY;

            }
            if (strumf3.strumfPozY > Game.cameraY + Game.SCREEN_HEIGHT - strumf3.strumfHeight) {
                strumf3.strumfPozY = Game.cameraY + Game.SCREEN_HEIGHT - strumf3.strumfHeight;

            }

           // System.out.println("CameraX: " + Game.cameraX + " CameraY: " + Game.cameraY);
            //System.out.println("PlayerX: " + strumf3.strumfPozX + " PlayerY: " + strumf3.strumfPozY);
        }
    }
    //metoda pt aplicarea gravitatiei
    private void applyGravity() {
        velocityY += gravity;
        strumf3.strumfPozY += velocityY;
        strumf3.strumfPozX += velocityX;

        if (strumf3.strumfPozY >= 768 - strumf3.strumfHeight) {
            strumf3.strumfPozY = 768 - strumf3.strumfHeight;
            hasJumped = false;
            velocityY = 0;
            velocityX = 0;
            strumf3.inAir = false;
        } else if (!CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX, strumf3.solidArea.y + strumf3.strumfPozY + (int)velocityY, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
            strumf3.strumfPozY -= velocityY;
            hasJumped = false;
            velocityY = 0;
            velocityX = 0;
            strumf3.inAir = false;
        }
    }
    //metoda pt miscarea jucatorului
    public void move() {

        if (CanMoveHere(strumf3.solidArea.x + strumf3.strumfPozX, strumf3.solidArea.y + strumf3.strumfPozY + (int)velocityY, strumf3.solidArea.width, strumf3.solidArea.height, mapNum)) {
            strumf3.strumfPozY += velocityY;
        } else {
            hasJumped = false;
            velocityY = 0;
            velocityX = 0;
            strumf3.inAir = false;
        }



}

    //metoda pt saritura jucatorului
    private void jump() {
        if (hasJumped==false) {
            hasJumped = true;
            strumf3.inAir=true;
            velocityY = -7; // Setează viteza inițială a săriturii
            //velocityX = 3;
        }
    }
    public long getTime(){
        return timeElapsed;
    }
    public void restartLevel3(){
        loadThirdMap();
        score=0;
        winned=false;
        gameover=false;
        timeElapsed=0;
        totalPauseTime=0;
        strumf3.strumfPozX=50;
        strumf3.strumfPozY=590;
    }
    public static void Win(){
        winned=true;

    }
    public static void GameOver(){
        gameover=true;
    }


}

