package PaooGame.Levels;

import PaooGame.Game;

import PaooGame.GameWindow.GameWindow;
import PaooGame.KeyHandler.KeyHandler;
import PaooGame.Player.PlayerStrumf;
import PaooGame.Tiles.Tile;
import PaooGame.Tiles.TileFlyweight;
import PaooGame.Tiles.TileFlyweightFactory;

import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;

import static PaooGame.Collision.HelpMethods.CanMoveHere;

public class FirstLevel {
    private static Graphics g;
    //private static int[][] table;// matrice tabela joc
    private static TileFlyweight[][] table;
    private int gameWidth;//lungimea ferestrei
    private int gameHeigth;// inaltimea ferestre;
    private int widthInTiles;//lungime tile
    private int heigthInTiles;//inaltime tile
    private int borderDepth;//grosime bordura;
    private static int[][] cadouTable; // matricea pentru obiecte
    public static int score;
    public static boolean winned = false;
    public static boolean gameover = false;
    private boolean isPaused = false;
    long start;
    long stop;
    long timeElapsed;
    private long pauseStartTime;
    private long totalPauseTime;


    public static int mapNum[][];

    public FirstLevel(int gameWidth, int gameHeigth) {
        this.gameHeigth = gameHeigth;
        this.gameWidth = gameWidth;
        widthInTiles = gameWidth / Tile.TILE_WIDTH;
        heigthInTiles = gameHeigth / Tile.TILE_HEIGTH;
        borderDepth = 2;
        mapNum = new int[heigthInTiles + 1][widthInTiles + 1];
        //table = new int[heigthInTiles + 1][widthInTiles + 1];
        table = new TileFlyweight[heigthInTiles + 1][widthInTiles + 1];
        cadouTable = new int[heigthInTiles + 1][widthInTiles + 1];
        cadouTable[9][5] = 3;
        cadouTable[12][8] = 3;
        cadouTable[10][14] = 3;
        cadouTable[3][11] =3;
        loadMap();
        //DrawTable();
    }

    //functie pentru incarcarea mapei
    public void loadMap() {
        try {
            InputStream is = getClass().getResourceAsStream("/map01.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col = 0;
            int row = 0;
            while (col < widthInTiles && row < heigthInTiles) {
                String line = br.readLine();
                while (col < widthInTiles) {
                    String numbers[] = line.split(" ");
                    int num = Integer.parseInt(numbers[col]);
                    table[row][col] = TileFlyweightFactory.getTileFlyweight(num);
                    mapNum[row][col] = num;
                    col++;

                }
                if (col == widthInTiles) {
                    col = 0;
                    row++;
                }
            }
            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   /* public void DrawTable() {
        int col = 0;
        int row = 0;
        int x = 0;
        int y = 0;
        for (int i = 0; i < heigthInTiles; ++i) {
            for (int j = 0; j < widthInTiles; ++j) {
                if (mapNum[i][j] == 0) {
                    table[i][j] = Tile.iarba.GetId();

                } else if (mapNum[i][j] == 1) {
                    table[i][j] = Tile.piatra.GetId();
                }
                if (mapNum[i][j] == 2) {
                    table[i][j] = Tile.tree.GetId();
                }
                //table[i][j]=Tile.iarba.GetId();

            }
        }
    }*/

    //desenare mapa
    public void DrawMap(Graphics g) {
        this.g = g;


        for (int i = 0; i < heigthInTiles; ++i) {
            for (int j = 0; j < widthInTiles; ++j) {
                TileFlyweight flyweight = table[i][j];
                if (flyweight != null) {
                    flyweight.Draw(g, j * Tile.TILE_WIDTH, i * Tile.TILE_HEIGTH);
                }
            }
        }
        Font fnt0 = new Font("Monospaced", Font.BOLD, 14);
        g.setFont(fnt0);
        g.setColor(Color.white);
        g.drawString("Punctaj: " + score, 850, 10);
        for (int i = 0; i < heigthInTiles; ++i)
            for (int j = 0; j < widthInTiles; ++j)
                if (cadouTable[i][j] != 0) {
                    //Tile.tiles[cadouTable[i][j]].Draw(g, j * Tile.TILE_WIDTH, i * Tile.TILE_HEIGTH);
                    TileFlyweightFactory.getTileFlyweight(3).Draw(g, j * Tile.TILE_WIDTH, i * Tile.TILE_HEIGTH);

                }
    }

    public void SelectCadou(int x, int y) {
        int pozX, pozY;
        pozX = x / Tile.TILE_WIDTH;
        pozY = y / Tile.TILE_HEIGTH;
        if (cadouTable[pozX][pozY] != 0) {
            cadouTable[pozX][pozY] = 0;
            score++;
            DrawMap(g);
        }
    }

    //se gaseste cadou sau nu
    public static boolean isCadou(int aux1, int aux2) {
        int pozX, pozY;
        pozX = aux1 / Tile.TILE_WIDTH;
        pozY = aux2 / Tile.TILE_HEIGTH;

        return cadouTable[pozX][pozY] == 3;
    }

    public int getScore() {
        return score;
    }

    public void Update() {
        KeyHandler keyH = Game.wnd.getKeyHandler();

        //se misca strumful
        if(!isPaused) {
        stop = System.currentTimeMillis();
        timeElapsed = stop - Game.start - totalPauseTime;
        if (keyH.upPressed == true || keyH.downPressed == true || keyH.rightPressed == true || keyH.leftPressed == true) {

            if (keyH.upPressed == true) {
                if (CanMoveHere(Game.strumf.solidArea.x + Game.strumf.strumfPozX, Game.strumf.strumfPozY - Game.strumf.solidArea.y - Game.strumf.speed, Game.strumf.solidArea.width, Game.strumf.solidArea.height, mapNum)) {
                    if (Game.strumf.strumfPozY - Game.strumf.speed >= 0) {
                        Game.strumf.strumfPozY -= Game.strumf.speed;
                    }
                    Game.strumf.direction = "up";

                }

            } else if (keyH.downPressed == true) {
                if (CanMoveHere(Game.strumf.solidArea.x + Game.strumf.strumfPozX, Game.strumf.strumfPozY - Game.strumf.solidArea.y + Game.strumf.speed, Game.strumf.solidArea.width, Game.strumf.solidArea.height, mapNum)) {
                    if (Game.strumf.strumfPozY + Game.strumf.speed <= 768 - Game.strumf.strumfHeight) {
                        Game.strumf.strumfPozY += Game.strumf.speed;
                    }
                    Game.strumf.direction = "down";
                }

            } else if (keyH.leftPressed == true) {
                if (CanMoveHere(Game.strumf.solidArea.x - Game.strumf.speed + Game.strumf.strumfPozX, Game.strumf.strumfPozY - Game.strumf.solidArea.y, Game.strumf.solidArea.width, Game.strumf.solidArea.height, FirstLevel.mapNum)) {
                    if (Game.strumf.strumfPozX - Game.strumf.speed >= 0) {
                        Game.strumf.strumfPozX -= Game.strumf.speed;
                    }
                    Game.strumf.direction = "left";
                }

            } else if (keyH.rightPressed == true) {
                if (CanMoveHere(Game.strumf.solidArea.x + Game.strumf.speed + Game.strumf.strumfPozX, Game.strumf.strumfPozY - Game.strumf.solidArea.y, Game.strumf.solidArea.width, Game.strumf.solidArea.height, FirstLevel.mapNum)) {
                    if (Game.strumf.strumfPozX + Game.strumf.speed <= gameWidth - Game.strumf.strumfWidth) {
                        Game.strumf.strumfPozX += Game.strumf.speed;
                    }
                    Game.strumf.direction = "right";
                }


            }


            Game.strumf.counter++;
            if (Game.strumf.counter > 20) {
                if (Game.strumf.num == 1)
                    Game.strumf.num = 2;
                else if (Game.strumf.num == 2)

                    Game.strumf.num = 1;
                Game.strumf.counter = 0;
            }

        }
    }
        //face ca timpul sa porneasca de unde s-a oprit inainte de pauza
        if(Game.wnd.gameState==Game.wnd.pauseState){
            if(!isPaused){
                pauseStartTime=System.currentTimeMillis();
                isPaused=true;
            }
        }
        else{
            if(isPaused) {
                long pauseEndTime=System.currentTimeMillis();
                totalPauseTime+=(pauseEndTime-pauseStartTime);
                isPaused = false;
            }
        }
         Game.strumf.Update();
        //pierde daca jucatorul castiga
        if (getScore() == 4) {
            if (Game.strumf.strumfPozX >= 912 && Game.strumf.strumfPozX <= 960 && Game.strumf.strumfPozY >= 240 && Game.strumf.strumfPozY <= 336) {
                if (timeElapsed / 1000. <= 180) {
                    Win();
                    Game.wnd.gameState=Game.wnd.winState;
                    isPaused=true;
                }
            }
        }
        //verifica jucatorul pierde
        if(getScore()!=4){
            if(timeElapsed/1000. >=180){
                GameOver();
                Game.wnd.gameState=Game.wnd.gameoverState;
                isPaused=true;
            }
            if(Game.strumf.strumfPozX >= 912 && Game.strumf.strumfPozX <= 960 && Game.strumf.strumfPozY >= 240 && Game.strumf.strumfPozY <= 336){
                GameOver();
                Game.wnd.gameState=Game.wnd.gameoverState;
                isPaused=true;
            }
        }

    }
    public static void Win(){
        winned=true;

    }
    public static void GameOver(){
        gameover=true;
    }
    public long getTime(){
        return timeElapsed;
    }

    public void restartLevel() {
        loadMap();
        //DrawMap(g);
        score = 0;
       winned = false;
        gameover = false;
        timeElapsed = 0;
        totalPauseTime = 0;
        Game.strumf.strumfPozY=200;
        Game.strumf.strumfPozX=80;

    }



}
