package PaooGame.Levels;

import PaooGame.Collision.Column;
import PaooGame.Collision.Heart;
import PaooGame.Collision.SuperObject;
import PaooGame.Game;
import PaooGame.Graphics.ImageLoader;
import PaooGame.Player.PlayerStrumf2;
import PaooGame.Tiles.Tile;
import PaooGame.Tiles.TileFlyweight;
import PaooGame.Tiles.TileFlyweightFactory;
import PaooGame.KeyHandler.KeyHandler;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import static PaooGame.Collision.HelpMethods.CanMoveHere;
import static PaooGame.Game.strumf2;

public class SecondLevel2 extends JFrame {
    private static Graphics g;

    private int cameraX=0;
    private int cameraY=0;
   // private static int [][] table;// matrice tabela joc
   private static TileFlyweight[][] table;
    private int gameWidth;//lungimea ferestrei
    private int gameHeigth;// inaltimea ferestre;
    private int widthInTiles;//lungime tile
    private int heigthInTiles;//inaltime tile
    private int borderDepth;//grosime bordura;
    public static double score=0;
    int velocityX = -4;
    public static double velocityY = 0;
    double gravity = 0.05;
    double damping=0.5;
    public boolean started=false;

    public static boolean winned=false;
    public static boolean gameover=false;
    private boolean isPaused = false;
    long start;
    long stop;
    long timeElapsed;
    private long pauseStartTime;
    private long totalPauseTime;
    public List<Column> columns= new ArrayList<>();
    public Random rand=new Random();
    public int columnspacing=3000;
    public int  columnCounter=0;
    int lastPassedColumnIndex = -1;
    BufferedImage heart_full, heart_half,heart_blank;

    public static int mapNum[][];

    public SecondLevel2(int gameWidth, int gameHeigth) {
        this.gameHeigth = gameHeigth;

        this.gameWidth = gameWidth;
        widthInTiles = gameWidth / Tile.TILE_WIDTH;
        heigthInTiles = gameHeigth / Tile.TILE_HEIGTH;
        borderDepth = 2;
        SuperObject heart= new Heart(g);
        heart_full=heart.image;
        heart_half=heart.image2;
        heart_blank=heart.image3;
        mapNum = new int[heigthInTiles + 1][widthInTiles + 1];
        table = new TileFlyweight[heigthInTiles + 1][widthInTiles + 1];
        loadSecondMap();
        DrawSecondTable();


}
//functie oentru incarcarea mapei
public void loadSecondMap() {
    try {
        InputStream is = getClass().getResourceAsStream("/map03.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        int col = 0;
        int row = 0;
        while (col < widthInTiles && row < heigthInTiles) {
            String line = br.readLine();
            while (col < widthInTiles) {
                String numbers[] = line.split(" ");
                int num = Integer.parseInt(numbers[col]);
                if (num == 0) {
                    mapNum[row][col] = 6;
                } else {
                    mapNum[row][col] = num;
                }
                col++;

            }
            if (col == widthInTiles) {
                col = 0;
                row++;
            }
        }
        br.close();

    } catch (Exception e) {
        e.printStackTrace();
    }
}

public void DrawSecondTable() {
    int col = 0;
    int row = 0;
    int x = 0;
    int y = 0;
    for (int i = 0; i < heigthInTiles; ++i) {
        for (int j = 0; j < widthInTiles; ++j) {
            int tileId = mapNum[i][j];
            table[i][j] = TileFlyweightFactory.getTileFlyweight(tileId);

        }
    }

}
//desenare mapa
public void DrawMap(Graphics g) {
    this.g = g;

    for(Column column:columns){
        column.draw(g);
    }
    drawPlayerLife();
}

public void drawPlayerLife() {

        int x=Tile.TILE_HEIGTH/2;
        int y=Tile.TILE_WIDTH/2;
        int i=0;
        //draw blank heart
        while(i< strumf2.maxLife){
            g.drawImage(heart_blank,x,y,null);
            i++;
            x+=Tile.TILE_WIDTH;
        }
        //reset
        x=Tile.TILE_WIDTH/2;
        y=Tile.TILE_HEIGTH/2;
        i=0;
        //draw current life
        while(i<strumf2.life){
            //g.drawImage(heart_half,x,y,null);
            //i++;
            if(i<strumf2.life){
                g.drawImage(heart_full,x,y,null);

            }
            i++;
            x+=Tile.TILE_WIDTH;
        }

}
private boolean hasJumped=false;
public void Update() {

    KeyHandler keyH = Game.wnd.getKeyHandler();
    if(!isPaused) {
        stop = System.currentTimeMillis();
        timeElapsed=stop-Game.start-totalPauseTime;
        if (keyH.spacePresssed) {
            started = true;
        }
        if (started) {


            updateGame();
            if (keyH.spacePresssed && hasJumped == false) {
                jump();
            }

            if (checkCollisions() == false) {// verifica coliziunea cu coloanele
                move();
            }
            strumf2.counter++;
            if (strumf2.counter > 20) {
                if (strumf2.num == 1)
                    strumf2.num = 2;
                else if (strumf2.num == 2)
                    strumf2.num = 1;
                strumf2.counter = 0;
            }

        }


    }
    if(Game.wnd.gameState==Game.wnd.pauseState2){
        if(!isPaused){
            pauseStartTime=System.currentTimeMillis();
            isPaused=true;
        }
    }
    else{
        if(isPaused) {
            long pauseEndTime=System.currentTimeMillis();
            totalPauseTime+=(pauseEndTime-pauseStartTime);
            isPaused = false;
        }
    }
    if (score == 5) {
        winned = true;
        isPaused=true;


    }
    if(strumf2.life<=0){
        gameover=true;
        isPaused=true;
    }
    if(strumf2.strumfPozY>gameHeigth){
        gameover=true;
        isPaused=true;
    }
}
//cade cand nu apas space
public void move() {

    velocityY += gravity;

    strumf2.strumfPozY += velocityY;
    strumf2.strumfPozY=Math.max(strumf2.strumfPozY,0);
    //se misca strumful
    if (!isPaused) {
        stop = System.currentTimeMillis();
        timeElapsed = stop - Game.start - totalPauseTime;
    }
    hasJumped=false;
}

    private void jump(){
    if(!started){
        started=true;
        start=System.currentTimeMillis();
    }
    if (hasJumped==false) {
        hasJumped = true;
        velocityY = -2; // setează viteza inițială a săriturii
    }
}
    public void updateCamera() {
        // Centrarea camerei pe jucător
        cameraX = strumf2.strumfPozX - gameWidth / 2;
        cameraY = strumf2.strumfPozY - gameHeigth / 2;

        cameraX = Math.max(0, Math.min(cameraX, widthInTiles * Tile.TILE_WIDTH - gameWidth));
        cameraY = Math.max(0, Math.min(cameraY, heigthInTiles * Tile.TILE_HEIGTH - gameHeigth));
    }
    public void updateGame() {
        columnCounter+=5;
        if(columnCounter>=columnspacing) { // ajustează probabilitatea pentru a controla frecvența coloanelor
            int gapHeight = 250; // inălțimea spațiului prin care trebuie să treacă strumfului
            int gapPosition = rand.nextInt(gameHeigth - gapHeight - 200) + 100; // poziția spațiului, evitând marginile prea apropiate de sus sau jos
            int columnWidth=30;

            int columnHeightTop = gapPosition; // inălțimea coloanei de sus
            int columnHeightBottom = gameHeigth - (gapPosition + gapHeight); // inălțimea coloanei de jos


            columns.add(new Column(gameWidth, 0, 30,columnHeightTop));


            columns.add(new Column(gameWidth, gapPosition + gapHeight, 30, columnHeightBottom));
            columnCounter=0;
        }

        // actualizează pozițiile coloanelor
        for (int i = 0; i < columns.size(); i++) {
            Column column = columns.get(i);
            if (Game.strumf2.strumfPozX> column.x + column.width && lastPassedColumnIndex != i) {


            }
            column.update();

            // elimină coloanele care au ieșit din ecran
            if (column.x + column.width < 0) {
                columns.remove(i);
                i--;
            }
        }
        checkPassColumns();

        // actualizează camera și alte elemente ale jocului
        updateCamera();
    }
    public boolean checkCollisions() {
        Rectangle playerRect = new Rectangle(strumf2.strumfPozX, strumf2.strumfPozY, strumf2.strumfWidth, strumf2.strumfHeight);
        boolean hasCollisionOccurred = false;
        for (Column column:columns) {
            Rectangle columnTopRect = new Rectangle(column.x, column.y, column.width, column.height);
            Rectangle columnBottomRect = new Rectangle(column.x, column.y + 300 + column.height, column.width, gameHeigth - (column.y + column.height +300 ));

            if (playerRect.intersects(columnTopRect)  ) {
                if (!column.hasCollided) {
                    // gestionare coliziune

                    System.out.println("s-a lovit");
                    strumf2.life--;
                    System.out.println("Current life: " + strumf2.life);

                    column.hasCollided = true;
                    hasCollisionOccurred = true;

                }
            }
            if(playerRect.intersects(columnBottomRect)){
                if (!column.hasCollided) {

                    System.out.println("s-a lovit");
                    strumf2.life=strumf2.life-0.25;
                    System.out.println("Current life: " + strumf2.life);

                    column.hasCollided = true;
                    hasCollisionOccurred = true;

                }
            }

            if (strumf2.strumfPozX > column.x + column.width) {
                column.hasCollided = false;
                //System.out.println("Collision reset for a column.");
            }
        }
        return  hasCollisionOccurred;
    }
    public boolean playerCollidesWithColumn(PlayerStrumf2 player, Column column) {
        int playerTop = player.strumfPozY;
        int playerBottom = player.strumfPozY + player.strumfHeight;

        return playerBottom < column.gapstart || playerTop > column.gapstart + column.height;
    }
    public static void Win(){
        winned=true;

    }
    private void checkPassColumns() {
        for (Column column : columns) {
            if (strumf2.strumfPozX > column.x + column.width && !column.hasPassed && !column.hasCollided) {
                score=score+0.5;
                System.out.println("Scor incrementat: " + score);
                column.hasPassed = true;  // Marcam coloana ca fiind trecută.
            }
        }
    }
    public long getTime(){
        return timeElapsed;
    }
    public void restartLevel(){
    loadSecondMap();
    score=0;
    winned=false;
    gameover=false;
    timeElapsed=0;
    totalPauseTime=0;
    strumf2.strumfPozX=200;
    strumf2.strumfPozY=200;
    }
    public static void GameOver(){
        gameover=true;
    }


}

