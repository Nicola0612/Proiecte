package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

import java.util.HashMap;
import java.util.Map;

public class TileFlyweightFactory {
    private static final Map<Integer, TileFlyweight> flyweights = new HashMap<>();

    public static TileFlyweight getTileFlyweight(int id) {
        //verifica daca flyweight-ul exista deja
        TileFlyweight flyweight = flyweights.get(id);
        if (flyweight == null) {
            //creeaza un nou flyweight daca nu exista
            switch (id) {
                case 0:
                    flyweight = new TileFlyweight(Assets.iarba, id, false);
                    break;
                case 1:
                    flyweight = new TileFlyweight(Assets.piatra, id, true);
                    break;
                case 2:
                    flyweight = new TileFlyweight(Assets.tree, id, true);
                    break;
                case 3:
                    flyweight = new TileFlyweight(Assets.cadou, id, false);
                    break;
                case 4:
                    flyweight = new TileFlyweight(Assets.papa, id, true);
                    break;
                case 5:
                    flyweight = new TileFlyweight(Assets.lemn, id, true);
                    break;
                case 6:
                    flyweight = new TileFlyweight(null, id, false);
                    break;
                case 7:
                    flyweight = new TileFlyweight(Assets.iarba2, id, true);
                    break;
                case 8:
                    flyweight = new TileFlyweight(Assets.water, id, false);
                    break;
                case 9:
                    flyweight = new TileFlyweight(Assets.wood1, id, true);
                    break;
                case 10:
                    flyweight = new TileFlyweight(Assets.wood2, id, true);
                    break;
                case 11:
                    flyweight = new TileFlyweight(Assets.smurfette, id, false);
                    break;
                default:
                    flyweight = new TileFlyweight(null, id, false);
                    break;
            }
            //stocheaza noul flyweight
            flyweights.put(id, flyweight);
        }
        return flyweight;
    }
}

