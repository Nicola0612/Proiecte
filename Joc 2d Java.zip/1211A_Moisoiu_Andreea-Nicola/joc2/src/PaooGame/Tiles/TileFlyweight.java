package PaooGame.Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;

public class TileFlyweight {
    private BufferedImage img;
    private final int id;
    private boolean coli;

    public TileFlyweight(BufferedImage img, int id, boolean coli) {
        this.img = img;
        this.id = id;
        this.coli = coli;
    }

    public void Draw(Graphics g, int x, int y) {
        g.drawImage(img, x, y, Tile.TILE_WIDTH, Tile.TILE_HEIGTH, null);
    }

    public boolean IsSolid() {
        return coli;
    }

    public int GetId() {
        return id;
    }
}

