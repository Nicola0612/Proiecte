package PaooGame.Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Tile {

    public static final int TILE_WIDTH=48;// latimea fiecarui tile
    public static final int TILE_HEIGTH=48;// inaltimea fiecarui tile

    private final TileFlyweight flyweight;//referinta catre flyweight-ul comun
    private final int x, y; // poziția unică a fiecărui tile

    public Tile(int id, int x, int y) {
        this.flyweight = TileFlyweightFactory.getTileFlyweight(id);
        this.x = x;
        this.y = y;
    }

    public void Draw(Graphics g) {
        flyweight.Draw(g, x, y);
    }
    //verifica daca tile-ul este solid
    public boolean IsSolid() {
        return flyweight.IsSolid();
    }

    public int GetId() {
        return flyweight.GetId();
    }

}
