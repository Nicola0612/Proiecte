package PaooGame.Player;

import PaooGame.Game;
import PaooGame.Graphics.Assets;
import PaooGame.KeyHandler.KeyHandler;
import PaooGame.Levels.FirstLevel;

import java.awt.*;
import java.awt.image.BufferedImage;

public class PlayerStrumf {
    //dimensiunile jucatorului
    public final int strumfWidth=32;
    public final int strumfHeight=32;

    private KeyHandler keyHandler;
   private int worldX;
   private int worldY;
   //coordonatele jucatorului
    public int strumfPozX;
    public int strumfPozY;

    public String direction="right";
    public int counter=0;
    public int num=1;
    public int imgRow=0;
    public int imgCol=0;
    public int speed=2;


    public BufferedImage img;
    private int nr=0;
    //coliziune
    public Rectangle solidArea;
    public boolean inAir=false;
    public int velocityY = -6;
    public int gravity = 1;
    public double maxLife;
    public double life;
   // public boolean collisionOn=false;

    public PlayerStrumf(int x,int y){
        this.strumfPozX=x;
        this.strumfPozY=y;
        img= Assets.strumf[2][0];
        solidArea=new Rectangle(5,0,20,20);
        maxLife=3;// viata maxima
        life=maxLife;//viata curenta
        //this.keyHandler = keyHandler;

    }
    public PlayerStrumf(int x,int y,BufferedImage image){
        this.strumfPozX=x;
        this.strumfPozY=y;
        img= image;
        solidArea=new Rectangle(5,0,20,20);

        //this.keyHandler = keyHandler;

    }
    public void Update() {
        if (inAir) {
            velocityY += gravity;  // Apply gravity effect
            strumfPozY += velocityY;  // Update position

            if (strumfPozY > 600 - strumfHeight) {  // Check for ground collision
                strumfPozY = 600 - strumfHeight;
                inAir = false;
                velocityY = 0;
                //this.img = Assets.strumf[4][0];  // Reset to idle image when landing
            }
        }


        //img = Assets.strumf[x][y];
        // verificare dacă jucătorul a colectat un cadou
        if(CheckIfScored(strumfPozY,strumfPozX))
            Game.map.SelectCadou(strumfPozY, strumfPozX);
        else if(CheckIfScored(strumfPozY,strumfPozX+strumfHeight))
            Game.map.SelectCadou(strumfPozY, strumfPozX+strumfHeight);
        else if(CheckIfScored(strumfPozY+strumfWidth, strumfPozX))
            Game.map.SelectCadou(strumfPozY+strumfWidth, strumfPozX);
        else if(CheckIfScored(strumfPozY+strumfWidth,strumfPozX+strumfHeight))
            Game.map.SelectCadou(strumfPozY+strumfWidth, strumfPozX+strumfHeight);

    }
    // metodă pentru a sări
    public void jump() {
        if (!inAir) {
            inAir = true;
            //ThirdLevel.hasJumped=true;
            velocityY = -10;  // Set initial jump velocity
            //this.img = Assets.strumf[4][1];  // Set jumping sprite
        }
    }

    //verificam daca este cadou
    public boolean CheckIfScored(int x, int y) {
        int x1 = x;
        int y1 = y;

        int x2 = x1 + strumfWidth;
        int y2 = x2 + strumfHeight;

        if(FirstLevel.isCadou(x1, y1))
            return true;
        if(FirstLevel.isCadou(x2,y1))
            return true;
        if(FirstLevel.isCadou(x1,y2))
            return true;
        if(FirstLevel.isCadou(x2,y2))
            return true;
        return false;
    }
    public void DrawPlayer(Graphics g){
       // System.out.println("Drawing player in direction: " + direction);
       int screenX = strumfPozX - Game.cameraX;
        int screenY = strumfPozY - Game.cameraY;

        BufferedImage image=null;
        switch (direction){
            case "up":
                if(num==1){
                    image=Assets.strumf[3][0];
                }
                if(num==2){
                    image=Assets.strumf[3][1];
                }
                break;
            case "down":
                if(num==1){
                    image=Assets.strumf[1][0];
                }
                if(num==2){
                    image=Assets.strumf[1][1];
                }
                break;
            case "right":
                if(num==1){
                    image=Assets.strumf[2][0];
                }
                if(num==2){
                    image=Assets.strumf[2][1];
                }
                break;
            case "left":
                if(num==1){
                    image=Assets.strumf[0][0];
                }
                if(num==2){
                    image=Assets.strumf[0][1];
                }
                break;
            case "jump":
                if(num==1){
                    image=Assets.strumf[2][0];
                }
                if(num==2){
                    image=Assets.strumf[2][1];
                }
                break;
        }
        // desenează imaginea jucătorului în funcție de starea jocului
        if(Game.wnd.gameState==Game.wnd.playState){
        g.drawImage(image,strumfPozX,strumfPozY,strumfWidth,strumfHeight,null);}
        if(Game.wnd.gameState==Game.wnd.thirdlevel) {
            g.drawImage(image, screenX, screenY, strumfWidth, strumfHeight, null);
        }
        g.setColor(Color.RED); // Setare culoare pentru dreptunghi

        //g.drawRect(screenX + solidArea.x, screenY + solidArea.y, solidArea.width, solidArea.height);
    }
    // setare și obținere scor
    public void setScore(int s){
      FirstLevel.score = s;
    }
    public int getScore(){
        return FirstLevel.score;
    }
    // setare și obținere viteza
    public int getSpeed(){
        return this.speed;
    }
    // setare și obținere viață
    public double getLife(){
        return life;
    }
    public void setLife(double s){
        this.life = s;
    }
    // setare și obținere direcție
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
    //setare și obținere coordonate
    public int getpozx(){
        return strumfPozX;
    }
    public void setpozx(int strumfPozX){
        this.strumfPozX = strumfPozX;
    }
    public int getpozy(){
        return strumfPozY;
    }
    public void setpozy(int strumfPozY){
        this.strumfPozY = strumfPozY;
    }
    public void setImgRow(int row){ imgRow=row;}
    public void setImgCol(int col){ imgCol=col;}
    public int getImgRow(){return imgRow;}
    public int getImgCol(){return imgCol;}



    public int getWorldX() {
        return worldX;
    }

    public int getWorldY() {
        return worldY;
    }

    public void setWorldX(int worldX) {
        this.worldX = worldX;
    }

    public void setWorldY(int worldY) {
        this.worldY = worldY;
    }

    public void reset() {
        // Reset player position to initial starting position
        this.strumfPozX = 80;  // Example starting x position
        this.strumfPozY = 200; // Example starting y position
        this.direction = "right";  // Default direction
        this.counter = 0;  // Reset any counters
        this.num = 1;  // Reset animation or state counters if used
        this.worldX = strumfPozX;  // Align world position with screen position
        this.worldY = strumfPozY;

        // Set the initial image (if needed)
        this.img = Assets.strumf[2][0];  // Initial image based on direction and state
    }

}
