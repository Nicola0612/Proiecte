package PaooGame.Player;
import PaooGame.Graphics.Assets;
import PaooGame.Levels.SecondLevel2;

import java.awt.*;
import java.awt.image.BufferedImage;


public class PlayerStrumf2 {
    // dimensiunile jucătorului
    public final int strumfWidth = 32;
    public final int strumfHeight = 32;
    // coordonatele jucătorului
    public int strumfPozX;
    public int strumfPozY;
    // viteza și starea de mișcare a jucătorului
    public int velocityY = -6;
    private boolean inAir = false;
    // imaginea curentă a jucătorului
    public BufferedImage img;
    public int counter=0;
    public int num=1;
    // zona de coliziune a jucătorului
    public Rectangle solidArea;
    public int gravity = 1;
    // starea jucătorului
    public double maxLife;
    public double life;

    public PlayerStrumf2(int x, int y) {
        this.strumfPozX = x;
        this.strumfPozY = y;
        this.img = Assets.strumf[4][0];  // Set initial sprite
        this.solidArea = new Rectangle(5, 0, 20, 20);
        maxLife=3;
        life=maxLife;
     }

    public void update() {
        if (inAir) {
            velocityY += gravity;  //aplica efectul gravitatiei
            strumfPozY += velocityY;  //actualizeaza pozitia jucatorului

            if (strumfPozY > 600 - strumfHeight) {
                strumfPozY = 600 - strumfHeight;
                inAir = false;
                velocityY = 0;
                this.img = Assets.strumf[4][0];
            }
        }
    }

    public void jump() {
        if (!inAir) {
            inAir = true;
            velocityY = -15;  // seteaza viteza initiala a sariturii
            this.img = Assets.strumf[4][1];  //seteaza sprite-ul pt saritura
        }
    }

    public void drawPlayer(Graphics g) {
        if(num==1){
            img=Assets.strumf[4][0];
        }
        if(num==2){
            img=Assets.strumf[4][1];
        }
        g.drawImage(img, strumfPozX, strumfPozY, strumfWidth, strumfHeight, null);
    }
    public Rectangle getBound() {
        return new Rectangle(strumfPozX, strumfPozY, strumfWidth, strumfHeight);
    }

    public double getScore() {
        return SecondLevel2.score; // presupuși că ai o variabilă score în SecondLevel2
    }

    public void setScore(double score) {
        SecondLevel2.score = score;
    }

    public int getpozx() {
        return strumfPozX;
    }

    public void setpozx(int x) {
        this.strumfPozX = x;
    }

    public int getpozy() {
        return strumfPozY;
    }

    public void setpozy(int y) {
        this.strumfPozY = y;
    }

    public String getDirection() {
        return "right"; // exemplu; schimbă după cum ai nevoie
    }



    public double getLife() {
        return life;
    }

    public void setLife(double life) {
        this.life = life;
    }
}
