package PaooGame.Player;

import PaooGame.Game;
import PaooGame.GameWindow.GameWindow;
import PaooGame.Graphics.Assets;

import java.awt.*;
import java.awt.image.BufferedImage;
import PaooGame.Collision.Dialog;

//import static PaooGame.Game.wnd;

public class PlayerPapa {
    Game game;

    public int papaPozX;
    public int papaPozY;
    public BufferedImage img;
    String dialogues[]=new String[20];
   public Dialog d;
    public PlayerPapa(int x,int y,Game game){
        //this.w=wnd;
        this.papaPozX=x;
        this.papaPozY=y;
        img= Assets.papa;
        this.game=game;
        d=new Dialog(this.game);
        setDialogue();
        speak();
    }
    //ce se afiseaza in caseta de dialog
    public void setDialogue(){

            dialogues[0] = "Pentru a trece acest nivel, trebuie să ajungi la capătul labirintului și\n să colectezi cadourile în 3 minute!";
            dialogues[1] = "La nivelul 2, trebuie să reușești să treci printre 5 coloane pentru a\n câștiga. Ai grijă să nu te lovești,\n altfel vei pierde o viață!!";
            dialogues[2]="Ai ajuns la ultimul nivel. Ca să termini jocul, sari pe lemne fără să cazi în apă\n. Daca vei cadea vei piede o\n si vei incepe din nou nivelul!!";
    }

    public void speak(){
        if(Game.wnd.gameState==1) {
            d.currentDialog = dialogues[0];

        }else{
            if(Game.wnd.gameState==5){
                d.currentDialog = dialogues[1];
            }else if(Game.wnd.gameState==8){
                d.currentDialog = dialogues[2];
            }
        }

    }
    public void Draw(Graphics g){
        g.drawImage(img,papaPozX,papaPozY,32,48,null);
    }
}
