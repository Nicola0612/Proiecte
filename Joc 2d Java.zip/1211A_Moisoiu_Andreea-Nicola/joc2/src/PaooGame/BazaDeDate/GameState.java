package PaooGame.BazaDeDate;

public class GameState {
    private int currentLevel;
    private int score;
    private int gameState;
    private int timeElapsed;

    public GameState(int currentLevel, int score, int gameState, int timeElapsed) {
        this.currentLevel = currentLevel;
        this.score = score;
        this.gameState = gameState;
        this.timeElapsed = timeElapsed;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public int getScore() {
        return score;
    }

    public int getGameState() {
        return gameState;
    }

    public int getTimeElapsed() {
        return timeElapsed;
    }
}

