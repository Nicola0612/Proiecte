package PaooGame.BazaDeDate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LevelStateDAO {
    public void saveLevelState(LevelState levelState) {
        String sql = "INSERT INTO LevelState(levelId, status, score, timeElapsed) VALUES(?, ?, ?, ?)";
        Connection conn = null;
        try {
            conn = DatabaseConnection.connect();
            if (conn == null) {
                System.out.println("Failed to make connection!");
                return;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, levelState.getLevelId());
                pstmt.setString(2, levelState.getStatus());
                pstmt.setInt(3, levelState.getScore());
                pstmt.setInt(4, levelState.getTimeElapsed());
                pstmt.executeUpdate();
                System.out.println("Level state saved successfully.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        }
    }

    public LevelState loadLevelState(int levelId) {
        String sql = "SELECT status, score, timeElapsed FROM LevelState WHERE levelId = ?";
        LevelState levelState = null;
        Connection conn = null;
        try {
            conn = DatabaseConnection.connect();
            if (conn == null) {
                System.out.println("Failed to make connection!");
                return null;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, levelId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String status = rs.getString("status");
                    int score = rs.getInt("score");
                    int timeElapsed = rs.getInt("timeElapsed");
                    levelState = new LevelState(levelId, status, score, timeElapsed);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        }
        return levelState;
    }
    public LevelState loadLastLevelState() {
        String sql = "SELECT * FROM LevelState ORDER BY id DESC LIMIT 1";
        LevelState levelState = null;
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int levelId = rs.getInt("levelId");
                String status = rs.getString("status");
                int score = rs.getInt("score");
                int timeElapsed = rs.getInt("timeElapsed");
                levelState = new LevelState(levelId, status, score, timeElapsed);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return levelState;
    }

}
