package PaooGame.BazaDeDate;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static Connection connect() {
        Connection conn = null;
        try {
            // asiguram că driverul SQLite JDBC este încărcat
            Class.forName("org.sqlite.JDBC");

            // parametrii bazei de date
            String url = "jdbc:sqlite:game_state.db";
            // Creează o conexiune la baza de date
            conn = DriverManager.getConnection(url);

            System.out.println("Connection to SQLite has been established.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite JDBC driver not found.");
            e.printStackTrace();
        }
        return conn;
    }
}



