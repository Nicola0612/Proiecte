package PaooGame.BazaDeDate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GameStateDAO {
    //salveaza starea jocului in baza de date
    public void saveGameState(GameState gameState) {
        String sql = "INSERT INTO GameState(currentLevel, score, gameState, timeElapsed) VALUES(?, ?, ?, ?)";
        Connection conn = null;
        try {
            conn = DatabaseConnection.connect();
            if (conn == null) {
                System.out.println("Failed to make connection!");
                return;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, gameState.getCurrentLevel());
                pstmt.setInt(2, gameState.getScore());
                pstmt.setInt(3, gameState.getGameState());
                pstmt.setInt(4, gameState.getTimeElapsed());
                pstmt.executeUpdate();
                System.out.println("Game state saved successfully.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        }
    }
    //incarca starea jocului din baza de date pe baza id-ului furnizat
    public GameState loadGameState(int id) {
       String sql = "SELECT currentLevel, score, gameState, timeElapsed FROM GameState WHERE id = ?";
        //String sql = "SELECT * FROM GameState ORDER BY id DESC LIMIT 1";
        GameState gameState = null;
        Connection conn = null;
        try {
            conn = DatabaseConnection.connect();
            if (conn == null) {
                System.out.println("Failed to make connection!");
                return null;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    int currentLevel = rs.getInt("currentLevel");
                    int score = rs.getInt("score");
                    int gameStateValue = rs.getInt("gameState");
                    int timeElapsed = rs.getInt("timeElapsed");
                    gameState = new GameState(currentLevel, score, gameStateValue, timeElapsed);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        }
        return gameState;
    }
    public GameState loadLastGameState() {
        String sql = "SELECT * FROM GameState ORDER BY id DESC LIMIT 1";
        GameState gameState = null;
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int currentLevel = rs.getInt("currentLevel");
                int score = rs.getInt("score");
                int gameStateValue = rs.getInt("gameState");
                int timeElapsed = rs.getInt("timeElapsed");
                gameState = new GameState(currentLevel, score, gameStateValue, timeElapsed);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return gameState;
    }

}
