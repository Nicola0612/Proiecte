package PaooGame.BazaDeDate;



public class PlayerState {
    private int playerId;
    private int positionX;
    private int positionY;
    private String direction;
    private double life;

    public PlayerState(int playerId, int positionX, int positionY, String direction, double life) {
        this.playerId = playerId;
        this.positionX = positionX;
        this.positionY = positionY;
        this.direction = direction;
        this.life = life;
    }

    public int getPlayerId() {
        return playerId;
    }

    public int getPositionX() {
        return positionX;
    }

    public int getPositionY() {
        return positionY;
    }

    public String getDirection() {
        return direction;
    }

    public double getLife() {
        return life;
    }
}

