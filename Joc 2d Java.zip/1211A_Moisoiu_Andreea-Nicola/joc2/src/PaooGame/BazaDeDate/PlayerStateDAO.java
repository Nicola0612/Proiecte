package PaooGame.BazaDeDate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerStateDAO {
    public void savePlayerState(PlayerState playerState) {
        String sql = "INSERT INTO PlayerState(playerId, positionX, positionY, direction, life) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, playerState.getPlayerId());
            pstmt.setInt(2, playerState.getPositionX());
            pstmt.setInt(3, playerState.getPositionY());
            pstmt.setString(4, playerState.getDirection());
            pstmt.setDouble(5, playerState.getLife());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public PlayerState loadPlayerState() {
        String sql = "SELECT playerId, positionX, positionY, direction, life FROM PlayerState ORDER BY id DESC LIMIT 1";
        PlayerState playerState = null;
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            //pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int playerId = rs.getInt("playerId");
                int positionX = rs.getInt("positionX");
                int positionY = rs.getInt("positionY");
                String direction = rs.getString("direction");
                double life = rs.getDouble("life");
                playerState = new PlayerState(playerId, positionX, positionY, direction, life);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return playerState;
    }
    public boolean playerStateExists(int id) {
        String sql = "SELECT COUNT(*) FROM PlayerState WHERE id = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    public PlayerState loadLastPlayerState() {
        String sql = "SELECT * FROM PlayerState ORDER BY id DESC LIMIT 1";
        PlayerState playerState = null;
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int playerId = rs.getInt("playerId");
                int positionX = rs.getInt("positionX");
                int positionY = rs.getInt("positionY");
                String direction = rs.getString("direction");
                double life = rs.getDouble("life");
                playerState = new PlayerState(playerId, positionX, positionY, direction, life);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return playerState;
    }

}
