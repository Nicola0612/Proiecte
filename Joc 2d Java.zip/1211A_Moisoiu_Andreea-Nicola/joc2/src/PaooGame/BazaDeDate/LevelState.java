package PaooGame.BazaDeDate;
//clasa LevelState stocheaza informațiile despre starea unui nivel: ID-ul nivelului, statusul (in progres, castigat, pierdut), scorul si timpul scurs. Metodele getter oferă acces la aceste date.
public class LevelState {
    public static final String IN_PROGRESS = "in-progress";
    public static final String WON = "won";
    public static final String LOST = "lost";

    private int levelId;
    private String status;
    private int score;
    private int timeElapsed;

    public LevelState(int levelId, String status, int score, int timeElapsed) {
        this.levelId = levelId;
        this.status = status;
        this.score = score;
        this.timeElapsed = timeElapsed;
    }

    public int getLevelId() {
        return levelId;
    }

    public String getStatus() {
        return status;
    }

    public int getScore() {
        return score;
    }

    public int getTimeElapsed() {
        return timeElapsed;
    }
}

