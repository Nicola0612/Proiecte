package PaooGame.GameWindow;

import PaooGame.KeyHandler.KeyHandler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;

public class GameWindow extends MouseAdapter {
    public static JFrame wndFrame; //fereastra principala joc
    private String wndTitle;  // titlul ferestrei
    private int wndWidth; //latimea
    private int wndHeight; //inaltimea ferestrei
    public  Canvas canvas; //panza in care se poate desena
    public KeyHandler keyH;
    // Game State
    public int gameState;
    public final int playState=1;
    public final int pauseState=2;
    public final int winState=3;
    public final int gameoverState=4;
    public final int nextlevel=5;
    public final int restartState=6;
    public final int pauseState2=7;
    public final int thirdlevel=8;
    public final int pauseState3=9;
    public final int optionMenuState = 10;

    public GameWindow(String title,int width, int height){
        wndTitle=title;
        wndHeight=height;
        wndWidth=width;
        keyH=new KeyHandler(this);
        gameState=1;
    }

    public void BuildGameWindow(){

            wndFrame = new JFrame(wndTitle);
            wndFrame.setSize(wndWidth, wndHeight);
            wndFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            wndFrame.setResizable(false);
            wndFrame.setLocationRelativeTo(null);
            canvas = new Canvas();
            canvas.setPreferredSize(new Dimension(wndWidth, wndHeight));
            canvas.setFocusable(false);//  imaginea nu mai primeste focus la click
            canvas.setMaximumSize(new Dimension(wndWidth, wndHeight));
            canvas.setMinimumSize(new Dimension(wndWidth, wndHeight));
            canvas.addKeyListener(keyH);

            canvas.setFocusable(true);
            //adaugare canvas in fereastra
            wndFrame.add(canvas);
            wndFrame.pack();
            wndFrame.setVisible(true);



    }


    public int GetWndWidth(){
        return wndWidth;
    }
    public int GetWndHeight(){
        return wndHeight;
    }

    public Canvas GetCanvas(){
        return canvas;
    }
    public KeyHandler getKeyHandler(){
        return keyH;
    }
    public void addPanel(JPanel panel) {
       wndFrame.add(panel);
    }




}
