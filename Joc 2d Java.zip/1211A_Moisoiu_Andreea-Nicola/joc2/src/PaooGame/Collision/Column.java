package PaooGame.Collision;

import java.awt.*;

public class Column {
    public int x, y, width, height;
    public int gapstart;
    public boolean hasCollided=false;
    public boolean hasPassed=false;

    public Column(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void draw(Graphics g) {
        g.fillRect(x, y, width, height);//height // Desenează coloana
        //g.fillRect(x, gapstart + height, width, 768 - (gapstart + height));
    }

    public void update() {
        x -= 1; // Mișcă coloana spre stânga
    }
}

