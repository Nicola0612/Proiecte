package PaooGame.Collision;

import PaooGame.Game;
import PaooGame.KeyHandler.KeyHandler;
import PaooGame.Player.PlayerPapa;
import PaooGame.Player.PlayerStrumf;
import PaooGame.Player.PlayerStrumf2;
import PaooGame.Tiles.Tile;

import java.awt.*;

public class Dialog {
    Game game;
    public String currentDialog="";

    public Dialog(Game game)
    {
        this.game=game;
    }
    //afiseaza casuta de dialog daca se intalneste cu Papa Strumf
   public void draw(Graphics2D g, PlayerStrumf strumf,PlayerPapa papa){
        if(Game.wnd.gameState==Game.wnd.playState) {
            if (strumf.strumfPozY >= 192 && strumf.strumfPozY <= 240 && strumf.strumfPozX >= 0 && strumf.strumfPozX <= 48)
                drawDialogScreen(g, papa);
        }
        if(Game.wnd.gameState==Game.wnd.thirdlevel) {
            if(strumf.strumfPozX<=50 ){
                drawDialogScreen(g, papa);
            }
        }
    }
    //
    public void drawDialogScreen(Graphics2D g,PlayerPapa papa){
        //window
        int x= Tile.TILE_HEIGTH;
        int y=Tile.TILE_WIDTH/2;
        int width=940-(Tile.TILE_HEIGTH*4);
        int height=Tile.TILE_HEIGTH*5;
        drawSubWindow(g,x,y,width,height);
        g.setFont(g.getFont().deriveFont(Font.PLAIN,16F));
        x+=Tile.TILE_HEIGTH;
        y+=Tile.TILE_WIDTH;

        for(String line:papa.d.currentDialog.split("\n")){
            g.drawString(line,x,y);
            y+=40;

        }
       // g.drawString(papa.d.currentDialog,x,y);

    }
    public void drawSubWindow(Graphics2D g,int x, int y,int width,int height){
        Color c= new Color(32, 44, 142,150);
        g.setColor(c);

        g.fillRoundRect(x,y,width,height,35,35);
        c=new Color(255,255,255);
        g.setColor(c);
        g.setStroke(new BasicStroke(5));
        g.drawRoundRect(x+5,y+5,width-10,height-10,25,25);
    }
    public void draw2(Graphics2D g, PlayerPapa papa, PlayerStrumf2 strumf2) {
        KeyHandler keyH = Game.wnd.getKeyHandler();
        if (keyH.enterPressed == true)
            drawDialogScreen(g, papa);
    }


    }

