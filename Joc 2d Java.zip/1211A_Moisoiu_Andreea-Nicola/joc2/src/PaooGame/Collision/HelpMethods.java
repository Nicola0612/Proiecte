package PaooGame.Collision;

import PaooGame.Game;
import PaooGame.Tiles.Tile;
import PaooGame.Tiles.TileFlyweight;
import PaooGame.Tiles.TileFlyweightFactory;

import java.awt.*;

public class HelpMethods {
    //functia care verifica dacă se realizeaza coliziune sau nu
    public static boolean CanMoveHere(int x, int y, int width, int height, int[][] lvlData) {

        if(!IsSolid(x,y,lvlData))
           if(!IsSolid(x+width,y+height,lvlData))
                if(!IsSolid(x+width,y,lvlData))
                    if(!IsSolid(x,y+height,lvlData))
                        return true;
        return false;
    }


    public static boolean IsSolid(int x, int y, int[][] levelData)
    {
        int maxWidth = levelData[0].length * Tile.TILE_WIDTH;

        if(x < 0 || x >= maxWidth)
            return true;

        if(y < 0 || y >= Game.SCREEN_HEIGHT)
            return true;

        float xIndex =(float) x / Tile.TILE_HEIGTH;
        float yIndex =(float) y / Tile.TILE_HEIGTH;

        int value = levelData[(int)yIndex][(int)xIndex];
        if (value < 0)
            return true;
        else {
            return TileFlyweightFactory.getTileFlyweight(value).IsSolid();
        }


    }
    public static int GetEntityPosNextToWall(Rectangle solidarea, int speed){
        int currentTile=solidarea.x/Tile.TILE_HEIGTH;
        if(speed>0){
            int tilePos=currentTile*Tile.TILE_WIDTH;
            int xOffsett=Tile.TILE_WIDTH*solidarea.width;
            return tilePos+xOffsett-1;
        }else{
            return currentTile*Tile.TILE_WIDTH;
        }

    }
    public static int GetEntityPosUnderRoofOrAboveFloor(Rectangle solidarea, int speed){
        int currentTile=solidarea.y/Tile.TILE_HEIGTH;
        if(speed>0){
            //Falling -touching floor
            int tilePos=currentTile*Tile.TILE_WIDTH;
            int yOffsett=Tile.TILE_WIDTH*solidarea.height;
            return tilePos+yOffsett-1;
        }else{
            return currentTile*Tile.TILE_WIDTH;
        }
    }
    public static boolean IsEntityOnFloor(Rectangle hitbox, int[][] levelData)
    {
        // check the pixel below bottomleft and bottomright corner
        // adica sa cada cand nu are nimic sub

        if(!IsSolid(hitbox.x,hitbox.y+hitbox.height+1,levelData))
            if(!IsSolid(hitbox.x + hitbox.width, hitbox.y + hitbox.height+1, levelData)) // adaugam +1 ca l-am scazut in celelalte metode
                return false;

        return true;
    }
}
