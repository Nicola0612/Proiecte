package PaooGame.Collision;

import PaooGame.Game;
import PaooGame.Graphics.ImageLoader;

import java.awt.*;
import java.io.IOException;
//obiecte pentru a reprezenta viata in joc
public class Heart extends SuperObject {
        Graphics g;
        public Heart(Graphics g) {
            this.g = g;
            name="Heart";

                image= ImageLoader.LoadImage("/heartsfull.png");
                image2= ImageLoader.LoadImage("/hearthalf.png");
                image3= ImageLoader.LoadImage("/heart.png");
        }
}
