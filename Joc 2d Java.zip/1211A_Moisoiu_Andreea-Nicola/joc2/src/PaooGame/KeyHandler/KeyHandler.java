package PaooGame.KeyHandler;
import PaooGame.Game;
import PaooGame.GameWindow.GameWindow;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;



public class KeyHandler implements KeyListener {
    public boolean oReleased,oPressed,lPressed,kPressed, jumpPressed,restartPressed,restartPressed2,spacePresssed,upPressed, downPressed,leftPressed,rightPressed,enterPressed;
    GameWindow gp;
    public KeyHandler(GameWindow gp){
        this.gp=gp;

    }
    @Override

    public void keyTyped(KeyEvent e){

    }
    @Override
    public void keyPressed(KeyEvent e){
        int code=e.getKeyCode();

        if (code == KeyEvent.VK_W){
            upPressed=true;

        }
        if(code== KeyEvent.VK_S){
            downPressed=true;

        }
        if(code== KeyEvent.VK_A){
            leftPressed=true;

        }
        if(code== KeyEvent.VK_D){
            rightPressed=true;

        }
        if (code == KeyEvent.VK_P) {
            if (Game.wnd.gameState == Game.wnd.playState) {
                Game.wnd.gameState = Game.wnd.pauseState;
            } else if (Game.wnd.gameState == Game.wnd.pauseState) {
                Game.wnd.gameState = Game.wnd.playState;
            } else if (Game.wnd.gameState == Game.wnd.nextlevel) {
                Game.wnd.gameState = Game.wnd.pauseState2;
            } else if (Game.wnd.gameState == Game.wnd.pauseState2) {
                Game.wnd.gameState = Game.wnd.nextlevel;
            } else if (Game.wnd.gameState == Game.wnd.thirdlevel) {
                Game.wnd.gameState = Game.wnd.pauseState3;
            } else if (Game.wnd.gameState == Game.wnd.pauseState3) {
                Game.wnd.gameState = Game.wnd.thirdlevel;
            }
        }

        if(code== KeyEvent.VK_ENTER){
            enterPressed=true;
        }
        if(code== KeyEvent.VK_R){
            restartPressed=true;
            restartPressed2=true;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            spacePresssed=true;
            System.out.println("Jump pressed: " + spacePresssed);

        }
        if(code== KeyEvent.VK_J){
             jumpPressed = true;
        }
        if(code==KeyEvent.VK_O){
            oPressed=true;
        }
        if(code==KeyEvent.VK_L){
            lPressed=true;
        }
        if(code==KeyEvent.VK_K){
            kPressed=true;
        }
    }
    @Override
    public void keyReleased(KeyEvent e){
        int code=e.getKeyCode();
        if (code == KeyEvent.VK_W){
            upPressed=false;
        }
        if(code== KeyEvent.VK_S){
            downPressed=false;
        }
        if(code== KeyEvent.VK_A){
            leftPressed=false;
        }
        if(code== KeyEvent.VK_D){
            rightPressed=false;
        }
        if(code== KeyEvent.VK_ENTER){
            enterPressed=false;
        }
        if(code== KeyEvent.VK_SPACE){
            spacePresssed=false;
            System.out.println("Jump released: " + spacePresssed);
        }
        if(code==KeyEvent.VK_R){
            restartPressed=false;
            restartPressed2=false;
        }
        if(code==KeyEvent.VK_J){
            jumpPressed = false;
        }
        if(code==KeyEvent.VK_O){
            oPressed=false;
        }


    }
    public void togglePauseState() {
        if (Game.wnd.gameState == Game.wnd.playState) {
            Game.wnd.gameState = Game.wnd.pauseState;
        } else if (Game.wnd.gameState == Game.wnd.pauseState) {
            Game.wnd.gameState = Game.wnd.playState;
        } else if (Game.wnd.gameState == Game.wnd.nextlevel) {
            Game.wnd.gameState = Game.wnd.pauseState2;
        } else if (Game.wnd.gameState == Game.wnd.pauseState2) {
            Game.wnd.gameState = Game.wnd.nextlevel;
        } else if (Game.wnd.gameState == Game.wnd.thirdlevel) {
            Game.wnd.gameState = Game.wnd.pauseState3;
        } else if (Game.wnd.gameState == Game.wnd.pauseState3) {
            Game.wnd.gameState = Game.wnd.thirdlevel;
        }
    }

    public void Update() {
        upPressed = false;
        downPressed = false;
        leftPressed = false;
        rightPressed = false;
    }
}