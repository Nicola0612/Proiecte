package PaooGame;

import PaooGame.BazaDeDate.*;
import PaooGame.GameWindow.GameWindow;
import PaooGame.Graphics.Assets;
import PaooGame.Graphics.ImageLoader;
import PaooGame.KeyHandler.KeyHandler;
import PaooGame.Levels.*;
import PaooGame.Player.PlayerPapa;
import PaooGame.Player.PlayerStrumf;
import PaooGame.Player.PlayerStrumf2;
import PaooGame.Tiles.Tile;
import PaooGame.Collision.Dialog;


import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import static PaooGame.Collision.HelpMethods.*;

public class Game  implements Runnable  {

    public static Game instance = null;
    public static GameWindow wnd; // fereastra in care se va desena tabla jocului
    public boolean runState;
    private Thread gameThread;//Referinta catre thread-ul de update si draw al ferestrei
    private BufferStrategy bs;//Referinta catre un mecanism cu care se organizeaza memoria complexa pentru un canvas
    private int gameWidth;
    private int gameHeight;
    private String gameTitle;
    Thread ThreadStrumf;
    public static PlayerStrumf strumf;
    public static PlayerStrumf2 strumf2;
    public static PlayerStrumf strumf3;
    public static PlayerPapa papa;
    public static PlayerPapa papa2;
    //world settings
    public static int maxCol = 65;
    public static int maxRow = 16;
    public static int worldWidth = Tile.TILE_WIDTH * maxCol;
    public static int worldHeight = Tile.TILE_HEIGTH * maxRow;
    public static int cameraX;
    public static int cameraY;
    public static final int SCREEN_WIDTH = 940; // Dimensiunile ecranului
    public static final int SCREEN_HEIGHT = 768;

    public static FirstLevel map;
    public static SecondLevel2 lvl2;
    public static ThirdLevel2 lvl3;
    private static final BufferedImage imgi = ImageLoader.LoadImage("/nori.png");
    private static final BufferedImage imgi2= ImageLoader.LoadImage("/lemn.png");
    private static final BufferedImage img4=ImageLoader.LoadImage("/smurfette.png");
    private int nr = 0; //ca sa schimbe imaginea caracterului

    //time measure
    public static long start;
    long stop;
    long timeElapsed;
    private boolean isPaused = false;
    private long pauseStartTime;
    private long totalPauseTime;


    public Graphics g;//Referinta catre un context grafic
    public Graphics2D g2;

    private Dialog d;
    private Dialog d2;
    private BufferedImage img;
    public static int countLevel;
    private int selectedOption = 0;

    //Singleton Pattern
    public static Game getInstance(String title, int width, int height) {
        if (instance == null) {
            instance = new Game(title, width, height);
        }
        return instance;
    }
    //constructor privat
    private Game(String title, int width, int height) {
        gameHeight = height;
        gameWidth = width;
        gameTitle = title;
        d2= new Dialog(this);
        wnd = new GameWindow(gameTitle, gameWidth, gameHeight);
        //InitGame();
        runState = false;

    }

    // inițializarea jocului
    private void InitGame() {
        wnd = new GameWindow(gameTitle, gameWidth, gameHeight);
        wnd.BuildGameWindow();
        SwingUtilities.invokeLater(() -> {
            wnd.GetCanvas().createBufferStrategy(3);
            bs = wnd.GetCanvas().getBufferStrategy();
        });
        Assets.Init();
        map = new FirstLevel(gameWidth, gameHeight);
        strumf2=new PlayerStrumf2(200,200);
        lvl2 = new SecondLevel2(gameWidth,gameHeight);
        strumf = new PlayerStrumf(80, 200);
        d = new Dialog(this);
        papa = new PlayerPapa(15, 192, this);
        papa2=new PlayerPapa(0, 590, this);
        lvl3=new ThirdLevel2(gameWidth,gameHeight);
        strumf3=new PlayerStrumf(50,590);
        //cameraX = 0;
        //cameraY = 0;
    }

    //Aceasta functie va actualiza starea jocului si va redesena tabla de joc (va actualiza fereastra grafica)
    @Override
    public void run() {
        InitGame();
        long oldTime = System.nanoTime();
        long currenTime;

        final int FPS = 60;
        final double timeFrame = 1000000000 / FPS;//durata unui frame in nanosecunde
        double delta = 0;

        while (runState == true) {
            currenTime = System.nanoTime();
            delta += (currenTime - oldTime) / timeFrame;
            if (delta >= 1) {
                Update();
                Draw();
                delta--;
            }


        }
    }
    // metodă sincronizata pentru a porni jocul
    public synchronized void StartGame() {
        if (runState == false) {
            wnd.gameState = 1;
            runState = true;
            start = System.currentTimeMillis();
            gameThread = new Thread(this);
            gameThread.start();// este lansat in executie

        } else {
            return;//este creat si pornit deja
        }
    }
    // metodă sincronizata pentru a opri jocul
    public synchronized void StopGame() {
        if (runState == true) {
            runState = false;
            try {
                gameThread.join();
                ThreadStrumf.join();

            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } else {
            return;
        }
    }

    //Actualizeaza starea elementelor din joc.
//
//        Metoda este declarata privat deoarece trebuie apelata doar in metoda run()
    private void Update() {
        KeyHandler keyH = Game.wnd.getKeyHandler();
        //cameraX = strumf.getWorldX() - SCREEN_WIDTH / 2;
        //cameraY = strumf.getWorldY() - SCREEN_HEIGHT / 2;
        // gestionarea intrarii  si iesirii din meniul de opțiuni
        if (keyH.oPressed) {
            if (wnd.gameState == wnd.optionMenuState) {
                if(countLevel==1) {
                    wnd.gameState = wnd.playState;

                }
                if(countLevel==2) {
                    wnd.gameState = wnd.nextlevel;

                }
                if(countLevel==3) {
                    wnd.gameState = wnd.thirdlevel;
                }

                keyH.togglePauseState();
            } else {
                wnd.gameState = wnd.optionMenuState;
                keyH.togglePauseState();

            }
            keyH.oPressed = false;
        }
        // navigarea si selecția in meniul de opțiuni
        if (wnd.gameState == wnd.optionMenuState) {
            if (keyH.upPressed ) {
                // gestionează navigarea în meniu
                selectedOption = (selectedOption - 1 + 3) % 3; // Navigare în sus în meniu
                keyH.upPressed = false;
            }else if (keyH.downPressed) {
                selectedOption = (selectedOption + 1) % 3; // Navigare în jos în meniu
                keyH.downPressed = false;
            }
            if (keyH.enterPressed) {
                // gestionează selecția în meniu
                handleOptionMenuSelection();

                keyH.enterPressed = false;
            }

            return;
        }


        // actualizare joc in funcție de starea jocului
        if (wnd.gameState == wnd.optionMenuState) {
            // Nu face update pentru elementele jocului când meniul de opțiuni este deschis
            return;
        }
        if (wnd.gameState == wnd.playState) {
            map.Update();
            countLevel=1;
           // System.out.println("nivel 1");
            if (map.getScore() == 4) {
                if (keyH.enterPressed == true) {
                    keyH.enterPressed = false;
                    wnd.gameState = wnd.nextlevel;

                }
            }
        }

        if (wnd.gameState == wnd.restartState || keyH.restartPressed) {

            if(countLevel==1) {
                wnd.gameState = wnd.playState;
                restartlevel1();

                keyH.restartPressed = false;
                Update();
                Draw();
            }
            if(countLevel==2) {
                wnd.gameState = wnd.nextlevel;
                restartlevel2();
                keyH.restartPressed = false;
                Update();
                Draw();
            }
            if(countLevel==3 && lvl3.gameover==false){
                strumf3.life=3;
                wnd.gameState=wnd.thirdlevel;
                restartlevel3();
                keyH.restartPressed = false;
                Update();
                Draw();
            }

        }
        if (keyH.restartPressed) {
            if (countLevel == 3) {
                strumf3.life = 3;  // resetare vieți
                restartlevel3();
                keyH.restartPressed = false;
                Update();
                Draw();
            }
        }
        if (wnd.gameState == wnd.nextlevel) {
            lvl2.Update();
            countLevel=2;
            System.out.println("nivel 2");
        }
        if(wnd.gameState==wnd.thirdlevel){
           // System.out.println(wnd.gameState);
            lvl3.Update();
            countLevel=3;

        }
        if(lvl3.winned==true){
            if (keyH.downPressed) {
                restartAllLevels();
                keyH.downPressed = false;
                return; // ieșim din metoda Update pentru a evita orice altă logică până la următorul frame
            }

        }
        if (keyH.kPressed) {
            saveGame();
            keyH.kPressed = false;
        }

        if (keyH.lPressed) {
            loadGame();
            keyH.lPressed = false;
        }



        //updateCamera();

    }


    //Deseneaza elementele grafice in fereastra coresponzator starilor actualizate ale elementelor.
//
//        Metoda este declarata privat deoarece trebuie apelata doar in metoda run()
    private void Draw() {
        KeyHandler keyH = Game.wnd.getKeyHandler();
        bs = wnd.GetCanvas().getBufferStrategy();
        if (bs == null || bs.contentsLost()) {
            try {
                wnd.GetCanvas().createBufferStrategy(3);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        do {
            do {
                g = bs.getDrawGraphics();
                g.clearRect(0, 0, gameWidth, gameHeight);
                if (wnd.gameState == wnd.optionMenuState) {
                    drawOptionMenu(g);
                }else {
                    if (wnd.gameState == wnd.playState || wnd.gameState == wnd.winState || wnd.gameState == wnd.gameoverState || wnd.gameState == wnd.pauseState) {
                        map.DrawMap(g);//deseneaza mapa
                        strumf.DrawPlayer(g);//afiseaza juacator
                        papa.Draw(g);
                        g2 = (Graphics2D) g;
                        d.draw(g2, strumf, papa);//afisare dialog
                        Font fnt1 = new Font("Monospaced", Font.BOLD, 14);
                        g.setFont(fnt1);
                        g.setColor(Color.white);
                        g.drawString("Timp " + map.getTime() / 1000. + "s", 450, 10);//afisare timp
                        if (wnd.gameState == wnd.winState) {
                            drawWin();
                            if (keyH.enterPressed) {
                                wnd.gameState = wnd.nextlevel;
                                start = System.currentTimeMillis();
                            }
                        }
                        if (wnd.gameState == wnd.gameoverState) {
                            drawGameOver();

                        }
                        if (wnd.gameState == wnd.playState) {

                        }
                        //afisare mesaj de pauza,daca apsam pe tasta P
                        if (wnd.gameState == wnd.pauseState) {
                            drawPauseScreen();
                        }
                    }
                    //nivel 2
                    if (wnd.gameState == wnd.nextlevel || wnd.gameState == wnd.pauseState2) {
                        g.drawImage(imgi, 0, 0, null);
                        g.drawImage(imgi2, 15, 240, null);

                        papa.speak();
                        lvl2.DrawMap(g);
                        strumf2.drawPlayer(g);
                        papa.Draw(g);
                        g2 = (Graphics2D) g;
                        d.draw2(g2, papa, strumf2);
                        Font fnt1 = new Font("Monospaced", Font.BOLD, 14);
                        g.setFont(fnt1);
                        g.setColor(Color.white);
                        g.drawString("Timp " + lvl2.getTime() / 1000. + "s", 450, 10);
                        if (lvl2.winned == true) {
                            drawWin();
                            if (keyH.enterPressed) {
                                wnd.gameState = wnd.thirdlevel;
                                start = System.currentTimeMillis();

                            }
                        }
                        if (wnd.gameState == wnd.pauseState2) {
                            drawPauseScreen();
                            System.out.println("Drawing pause screen...");

                        }
                        if (lvl2.gameover == true) {
                            drawGameOver();

                        }
                    }//nivel 3
                    if (wnd.gameState == wnd.thirdlevel || wnd.gameState == wnd.pauseState3) {
                        g.drawImage(imgi, 0, 0, null);
                        if(strumf3.strumfPozX>=2300) {
                            g.drawImage(img4, 3072, 624, null);
                        }
                        lvl3.DrawMap(g);

                        strumf3.DrawPlayer(g);
                        //papa2.w.gameState = 8;
                        papa2.speak();
                        g2 = (Graphics2D) g;
                        //papa2.Draw(g);
                        d.draw(g2, strumf3, papa2);
                        Font fnt1 = new Font("Monospaced", Font.BOLD, 14);
                        g.setFont(fnt1);
                        g.setColor(Color.white);
                        g.drawString("Timp " + lvl3.getTime() / 1000. + "s", 450, 10);
                        if (wnd.gameState == wnd.pauseState3) {
                            drawPauseScreen();
                            System.out.println("Drawing pause screen...");
                        }
                        if (lvl3.winned == true) {
                            drawWin();
                        }
                        if (lvl3.gameover == true) {
                            drawGameOver();

                        }

                    }
                }
                bs.show();
                g.dispose();
            } while (bs.contentsLost());
        } while (bs.contentsLost());
    }
    // desenează meniul de opțiuni
    private void drawOptionMenu(Graphics g) {
        Font fnt2 = new Font("ARIAL", Font.BOLD, 50);
        g.setFont(fnt2);
        g.setColor(Color.white);
        String text = "OPTIONS MENU";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 4;
        int x = gameWidth / 2 - length / 2;
        g.drawString(text, x, y);

        Font fnt1 = new Font("ARIAL", Font.BOLD, 30);
        g.setFont(fnt1);

        String restartText = "1. Restart Level";
        length = (int) g.getFontMetrics().getStringBounds(restartText, g).getWidth();
        y += 100;
        x = gameWidth / 2 - length / 2;
        if (selectedOption == 0) {
            g.setColor(Color.yellow);
        } else {
            g.setColor(Color.white);
        }
        g.drawString(restartText, x, y);

        String quitText = "2. Quit Game";
        length = (int) g.getFontMetrics().getStringBounds(quitText, g).getWidth();
        y += 100;
        x = gameWidth / 2 - length / 2;
        if (selectedOption == 1) {
            g.setColor(Color.yellow);
        } else {
            g.setColor(Color.white);
        }
        g.drawString(quitText, x, y);

        String startText = "3. Start from Level 1";
        length = (int) g.getFontMetrics().getStringBounds(startText, g).getWidth();
        y += 100;
        x = gameWidth / 2 - length / 2;
        if (selectedOption == 2) {
            g.setColor(Color.yellow);
        } else {
            g.setColor(Color.white);
        }
        g.drawString(startText, x, y);
    }
    // gestionarea selecției in meniul de opțiuni
    private void handleOptionMenuSelection() {
        if (selectedOption == 0) {
            // restart Level
            if (countLevel == 1) {
                wnd.gameState = wnd.playState;
                restartlevel1();
            } else if (countLevel == 2) {
                wnd.gameState = wnd.nextlevel;
                restartlevel2();
            } else if (countLevel == 3) {
                strumf3.life = 3;
                wnd.gameState = wnd.thirdlevel;
                restartlevel3();
            }
        } else if (selectedOption == 1) {
            // quit Game
            System.exit(0);
        } else if (selectedOption == 2) {
            // start from Level 1
            restartAllLevels();
            wnd.gameState = wnd.playState;
        }
    }

    public int getCameraX() {
        return cameraX;
    }

    public int getCameraY() {
        return cameraY;
    }

    // desenează ecranul de pauză
    public void drawPauseScreen() {
        Font fnt2 = new Font("ARIAL", Font.BOLD, 50);
        g.setFont(fnt2);
        g.setColor(Color.white);
        String text = "PAUSED";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2;
        int x = gameWidth / 2 - length / 2;
        g.drawString(text, x, y);
    }
    // desenează ecranul de victorie
    public void drawWin() {
        Font fnt2 = new Font("ARIAL", Font.BOLD, 50);
        g.setFont(fnt2);
        g.setColor(Color.white);
        String text = "WIN";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2 - 48;
        int x = gameWidth / 2 - 48;
        g.drawString(text, x, y);
    }
    // desenează ecranul de game over
    public void drawGameOver() {
        Font fnt2 = new Font("ARIAL", Font.BOLD, 50);
        g.setFont(fnt2);
        g.setColor(Color.white);
        String text = "Game Over";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2 - 48 * 3;
        int x = gameWidth / 2 - 48 * 3;
        g.drawString(text, x, y);
    }
    // repornirea nivelului 1
    public synchronized void restartlevel1() {

        map = new FirstLevel(gameWidth, gameHeight);
        map.loadMap();  // Reload the map configuration
        map.restartLevel();  // Reset any level-specific settings

        strumf = new PlayerStrumf(80, 200);  // Reset player position
        papa = new PlayerPapa(15, 192, this);  // Reset Papa Smurf

        start = System.currentTimeMillis();  // Reset the game timer
        wnd.gameState = wnd.playState;
    }
    // repornirea nivelului 2
    public synchronized  void restartlevel2(){
        lvl2=new SecondLevel2(gameWidth, gameHeight);
        lvl2.loadSecondMap();
        lvl2.restartLevel();
        strumf2=new PlayerStrumf2(200,200);
        papa = new PlayerPapa(15, 192, this);
        start=System.currentTimeMillis();
        wnd.gameState=wnd.nextlevel;
    }
    // repornirea nivelului 3
    public synchronized void restartlevel3(){
        lvl3=new ThirdLevel2(gameWidth, gameHeight);
        lvl3.loadThirdMap();
        lvl3.restartLevel3();
       strumf3.strumfPozY=590;
       strumf3.strumfPozX=50;
        papa2 = new PlayerPapa(0, 590, this);
        start=System.currentTimeMillis();
        wnd.gameState=wnd.thirdlevel;
    }
    // actualizează poziția camerei
    public void updateCamera() {
        if (countLevel == 3) { // Verificăm dacă suntem în nivelul 3
            int oldCameraX = cameraX;
            int oldCameraY = cameraY;
            cameraX = Math.max(0, Math.min(strumf3.strumfPozX - SCREEN_WIDTH / 2, worldWidth - SCREEN_WIDTH));
            cameraY = Math.max(0, Math.min(strumf3.strumfPozY - SCREEN_HEIGHT / 2, worldHeight - SCREEN_HEIGHT));
            if (cameraX == oldCameraX && strumf3.strumfPozX > oldCameraX + SCREEN_WIDTH - strumf3.strumfWidth) {
                strumf3.strumfPozX = oldCameraX + SCREEN_WIDTH - strumf3.strumfWidth;
            }
            if (cameraX == oldCameraX && strumf3.strumfPozX < oldCameraX) {
                strumf3.strumfPozX = oldCameraX;
            }
            if (cameraY == oldCameraY && strumf3.strumfPozY > oldCameraY + SCREEN_HEIGHT - strumf3.strumfHeight) {
                strumf3.strumfPozY = oldCameraY + SCREEN_HEIGHT - strumf3.strumfHeight;
            }
            if (cameraY == oldCameraY && strumf3.strumfPozY < oldCameraY) {
                strumf3.strumfPozY = oldCameraY;
            }
            System.out.println("CameraX: " + cameraX + " CameraY: " + cameraY);

        }
    }
    // repornirea tuturor nivelurilor
    public synchronized void restartAllLevels() {
        restartlevel1();
        restartlevel2();
        restartlevel3();
        countLevel = 1;
        wnd.gameState = wnd.playState;
    }
    // salvarea jocului
    public void saveGame() {
        GameState gameState = new GameState(
                countLevel,
                strumf.getScore(),
                wnd.gameState,
                (int) (System.currentTimeMillis() - start)
        );
        GameStateDAO dao = new GameStateDAO();
        dao.saveGameState(gameState);
        /*PlayerState playerState = new PlayerState(1, getCurrentPlayerX(),
                getCurrentPlayerY(),
                getCurrentPlayerDirection(),
                getCurrentPlayerLife())
                ;*/
        Object currentPlayer = getCurrentPlayer();
        int playerId = 1; // Poți schimba acest lucru pentru a se potrivi nevoilor tale

        int posX = 0, posY = 0;
        String direction = "";
        double life = 0;

        if (currentPlayer instanceof PlayerStrumf) {
            PlayerStrumf player = (PlayerStrumf) currentPlayer;
            posX = player.getpozx();
            posY = player.getpozy();
            direction = player.getDirection();
            life = player.getLife();
        } else if (currentPlayer instanceof PlayerStrumf2) {
            PlayerStrumf2 player = (PlayerStrumf2) currentPlayer;
            posX = player.strumfPozX;
            posY = player.strumfPozY;
            direction = "right"; // Schimbă în funcție de implementarea specifică
            life = player.life;
        }

        PlayerState playerState = new PlayerState(
                playerId,
                posX,
                posY,
                direction,
                life
        );
        PlayerStateDAO playerStateDAO = new PlayerStateDAO();
        playerStateDAO.savePlayerState(playerState);

        String levelStatus = LevelState.IN_PROGRESS;
        if (countLevel == 1 && FirstLevel.winned) {
            levelStatus = LevelState.WON;
        } else if (countLevel == 1 && FirstLevel.gameover) {
            levelStatus = LevelState.LOST;
        } else if (countLevel == 2 && SecondLevel2.winned) {
            levelStatus = LevelState.WON;
        } else if (countLevel == 2 && SecondLevel2.gameover) {
            levelStatus = LevelState.LOST;
        } else if (countLevel == 3 && ThirdLevel2.winned) {
            levelStatus = LevelState.WON;
        } else if (countLevel == 3 && ThirdLevel2.gameover) {
            levelStatus = LevelState.LOST;
        }

        LevelState levelState = new LevelState(countLevel, levelStatus, getCurrentPlayerScore(),
                (int) (System.currentTimeMillis() - start));
        LevelStateDAO levelStateDAO = new LevelStateDAO();
        levelStateDAO.saveLevelState(levelState);
    }
    // incărcarea jocului
    public void loadGame() {

        GameStateDAO gameStateDAO = new GameStateDAO();
        PlayerStateDAO playerStateDAO = new PlayerStateDAO();
        LevelStateDAO levelStateDAO = new LevelStateDAO();

        GameState gameState = gameStateDAO.loadLastGameState(); // Load the first saved game state
       // PlayerState playerState = playerStateDAO.loadPlayerState(); // Load the player state for the current game state
        PlayerState playerState = playerStateDAO.loadLastPlayerState();
        if (gameState != null) {
            System.out.println("Loaded game state: Level " + gameState.getCurrentLevel() + ", Score " + gameState.getScore() + ", Game State " + gameState.getGameState());

            countLevel = gameState.getCurrentLevel();
            wnd.gameState = gameState.getGameState();
            start = System.currentTimeMillis() - gameState.getTimeElapsed();
            if(playerState!=null) {
                if (countLevel == 1) {
                    strumf = new PlayerStrumf(playerState.getPositionX(), playerState.getPositionY());
                    strumf.setScore(gameState.getScore());
                    strumf.setLife(playerState.getLife());
                    strumf.setDirection(playerState.getDirection());
                    wnd.gameState = gameState.getGameState();
                    restartlevel1();
                } else if (countLevel == 2) {
                    strumf2 = new PlayerStrumf2(playerState.getPositionX(), playerState.getPositionY());
                    strumf2.life = playerState.getLife(); // Assuming you have a life field in PlayerStrumf2
                    wnd.gameState = gameState.getGameState();
                    restartlevel2();
                } else if (countLevel == 3) {
                    strumf3 = new PlayerStrumf(playerState.getPositionX(), playerState.getPositionY());
                    strumf3.setScore(gameState.getScore());
                    strumf3.setLife(playerState.getLife());
                    strumf3.setDirection(playerState.getDirection());
                    wnd.gameState = gameState.getGameState();
                    restartlevel3();
                }
            }else{
                System.out.println("Player state is null. Cannot load player state.");
            }
            //LevelState levelState = levelStateDAO.loadLevelState(countLevel);
            LevelState levelState = levelStateDAO.loadLastLevelState();
            if (levelState != null) {
                if (levelState.getStatus().equals(LevelState.WON)) {
                    if (countLevel == 1) {
                        FirstLevel.Win();
                    } else if (countLevel == 2) {
                        SecondLevel2.Win();
                    } else if (countLevel == 3) {
                        ThirdLevel2.Win();
                    }
                } else if (levelState.getStatus().equals(LevelState.LOST)) {
                    if (countLevel == 1) {
                        FirstLevel.GameOver();
                    } else if (countLevel == 2) {
                        SecondLevel2.GameOver();
                    } else if (countLevel == 3) {
                        ThirdLevel2.GameOver();
                    }
                }
            }
        }

    }
    // obține player-ul curent în funcție de nivel
    private Object getCurrentPlayer() {
        if (countLevel == 1) {
            return strumf;
        } else if (countLevel == 2) {
            return strumf2;
        } else if (countLevel == 3) {
            return strumf3;
        }
        return null;
    }
    // metode pentru obținerea și setarea poziției și stării jucătorului curent
    private int getCurrentPlayerX() {
        if (countLevel == 1 || countLevel == 3) {
            return ((PlayerStrumf)getCurrentPlayer()).getpozx();
        } else if (countLevel == 2) {
            return ((PlayerStrumf2)getCurrentPlayer()).strumfPozX;
        }
        return 0;
    }

    private int getCurrentPlayerY() {
        if (countLevel == 1 || countLevel == 3) {
            return ((PlayerStrumf)getCurrentPlayer()).getpozy();
        } else if (countLevel == 2) {
            return ((PlayerStrumf2)getCurrentPlayer()).strumfPozY;
        }
        return 0;
    }

    private String getCurrentPlayerDirection() {
        if (countLevel == 1 || countLevel == 3) {
            return ((PlayerStrumf)getCurrentPlayer()).getDirection();
        } else if (countLevel == 2) {
            return "right"; // Sau implementați metoda getDirection() în PlayerStrumf2
        }
        return "right";
    }

    private double getCurrentPlayerLife() {
        if (countLevel == 1 || countLevel == 3) {
            return ((PlayerStrumf)getCurrentPlayer()).getLife();
        } else if (countLevel == 2) {
            return ((PlayerStrumf2)getCurrentPlayer()).life;
        }
        return 0;
    }

    private int getCurrentPlayerScore() {
        if (countLevel == 1 || countLevel == 3) {
            return ((PlayerStrumf)getCurrentPlayer()).getScore();
        } else if (countLevel == 2) {
            return (int)strumf2.getScore(); // Sau implementați metoda getScore() în PlayerStrumf2
        }
        return 0;
    }

    private void setCurrentPlayerX(int x) {
        if (countLevel == 1 || countLevel == 3) {
            ((PlayerStrumf)getCurrentPlayer()).setpozx(x);
        } else if (countLevel == 2) {
            ((PlayerStrumf2)getCurrentPlayer()).strumfPozX = x;
        }
    }

    private void setCurrentPlayerY(int y) {
        if (countLevel == 1 || countLevel == 3) {
            ((PlayerStrumf)getCurrentPlayer()).setpozy(y);
        } else if (countLevel == 2) {
            ((PlayerStrumf2)getCurrentPlayer()).strumfPozY = y;
        }
    }

    private void setCurrentPlayerDirection(String direction) {
        if (countLevel == 1 || countLevel == 3) {
            ((PlayerStrumf)getCurrentPlayer()).setDirection(direction);
        } else if (countLevel == 2) {
            // Implementați metoda setDirection() în PlayerStrumf2 dacă este necesar
        }
    }

    private void setCurrentPlayerLife(double life) {
        if (countLevel == 1 || countLevel == 3) {
            ((PlayerStrumf)getCurrentPlayer()).setLife(life);
        } else if (countLevel == 2) {
            ((PlayerStrumf2)getCurrentPlayer()).life = life;
        }
    }

    private void setCurrentPlayerScore(int score) {
        if (countLevel == 1 || countLevel == 3) {
            ((PlayerStrumf)getCurrentPlayer()).setScore(score);
        } else if (countLevel == 2) {
            SecondLevel2.score = score;
        }
    }





}





