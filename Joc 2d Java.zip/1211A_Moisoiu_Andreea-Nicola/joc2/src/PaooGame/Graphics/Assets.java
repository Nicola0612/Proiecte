package PaooGame.Graphics;

import java.awt.image.BufferedImage;

public class Assets {
    public static BufferedImage iarba;
    public static BufferedImage piatra;
    public static BufferedImage tree;
    public static BufferedImage [][] strumf;
    public static BufferedImage cadou;
    public static BufferedImage papa;
    public static BufferedImage lemn;
    public static BufferedImage water;
    public static BufferedImage iarba2;
    public static BufferedImage wood1;
    public static BufferedImage wood2;
    public static BufferedImage smurfette;

    public static void Init(){
        SpriteSheet sheetIarba=new SpriteSheet(ImageLoader.LoadImage("/paoo.png"));
        SpriteSheet sheetPitra=new SpriteSheet(ImageLoader.LoadImage("/paoo.png"));

        iarba=sheetIarba.crop(0,0);
        piatra=sheetPitra.crop(3,0);
        tree=sheetIarba.crop(3,1);
        water=sheetIarba.crop(2,0);
        iarba2=sheetIarba.crop(1,0);

        strumf=new BufferedImage[5][2];
        strumf[0][0]=ImageLoader.LoadImage("/left1.png");
        strumf[0][1]=ImageLoader.LoadImage("/left2.png");
        strumf[1][0]=ImageLoader.LoadImage("/down1.png");
        strumf[1][1]=ImageLoader.LoadImage("/down2.png");
        strumf[2][0]=ImageLoader.LoadImage("/right1.png");
        strumf[2][1]=ImageLoader.LoadImage("/right2.png");
        strumf[3][0]=ImageLoader.LoadImage("/up1.png");
        strumf[3][1]=ImageLoader.LoadImage("/up2.png");
        strumf[4][0]=ImageLoader.LoadImage("/fly.png");
        strumf[4][1]=ImageLoader.LoadImage("/fly2.png");
        cadou=ImageLoader.LoadImage("/cadou.png");
        papa=ImageLoader.LoadImage("/papastrumf.png");
        lemn=ImageLoader.LoadImage("/lemn.png");
        wood1=ImageLoader.LoadImage("/wood1.png");
        wood2=ImageLoader.LoadImage("/wood2.png");
        smurfette=ImageLoader.LoadImage("/smurfette.png");




    }
}
