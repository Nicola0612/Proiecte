const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const bodyParser = require('body-parser');
const session = require('express-session');
const app = express();
const port = 6789;
const sqlite3 = require('sqlite3').verbose();
const dbPath = './cumparaturi.db';
const blocaje = {};
const durataBlocare = 60 * 1000;
const limitaIncercari = 5;
const incercariNereusiteIP = {};
const incercariNereusiteUser = {};

const durataBlocareScurta = 1 * 60 * 1000;
const durataBlocareLunga = 10 * 60 * 1000;

const limitaScurta = 5;
const limitaLunga = 15;

const incercariAutentificare = {};

const csrf = require('csurf');


const cookieParser = require('cookie-parser');
// directorul 'views' va conține fișierele .ejs (html + js executat la server)
app.set('view engine', 'ejs');
// suport pentru layout-uri - implicit fișierul care reprezintă template-ul site-ului
//este views/layout.ejs
app.use(cookieParser());
app.use(session({
    secret: 'nicola',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax' }
}));

app.use(expressLayouts);

app.use(express.urlencoded({ extended: true }));
// directorul 'public' va conține toate resursele accesibile direct de către client
//(e.g., fișiere css, javascript, imagini)
app.use(express.static('public'));
// corpul mesajului poate fi interpretat ca json; datele de la formular se găsesc în
//format json în req.body
app.use(bodyParser.json());
// utilizarea unui algoritm de deep parsing care suportă obiecte în obiecte
app.use(bodyParser.urlencoded({ extended: true }));
// la accesarea din browser adresei http://localhost:6789/ se va returna textul 'Hello
//World'
// proprietățile obiectului Request - req - https://expressjs.com/en/api.html#req
// proprietățile obiectului Response - res - https://expressjs.com/en/api.html#res
//app.get('/', (req, res) => {
//  res.render('index');
//});
// la accesarea din browser adresei http://localhost:6789/chestionar se va apela funcția
//specificată 
const fs = require('fs');
const path = require('path');

app.use(csrf());


app.use((req, res, next) => {
    res.locals.csrfToken = req.csrfToken();
    next();
});


app.use((req, res, next) => {
    const ip = req.ip;
    const acum = Date.now();
    if (blocaje[ip] && blocaje[ip] > acum) {
        return res.status(403).send("Ai fost blocat temporar pentru accesarea unor resurse inexistente. Încearcă mai târziu.");
    }
    if (blocaje[ip] && blocaje[ip] <= acum) {
        delete blocaje[ip];
    }
    next();
});

app.use((req, res, next) => {
    res.locals.utilizator = req.session.utilizator || null;
    next();
});



const listaIntrebari = [
    {
        intrebare: 'Care dintre următoarele fructe este un citric?',
        variante: ['Măr', 'Portocală', 'Strugure', 'Vișină'],
        corect: 1
    },
    {
        intrebare: 'Care dintre următoarele fructe face parte din familia drupe?',
        variante: ['Căpșună', 'Prună', 'Măr', 'Kiwi'],
        corect: 1
    },
    {
        intrebare: 'Care dintre următoarele fructe este un pom fructifer cu fructe de tip pepene?',
        variante: ['Pepene galben', 'Portocală', 'Lămâie', 'Măr'],
        corect: 0
    },
    {
        intrebare: 'Care dintre următoarele este un fruct de pădure?',
        variante: ['Mango', 'Coacăză', 'Banana', 'Strugure'],
        corect: 1
    }
];

function requireAdmin(req, res, next) {
    if (!req.session.utilizator || req.session.utilizator.rol !== "ADMIN") {
        return res.status(403).send('Acces interzis. Doar ADMIN poate accesa această pagină.');
    }
    next();
}

app.get('/admin', requireAdmin, (req, res) => {
    const mesaj = req.query.mesaj || null;
    res.render('admin', { mesaj });
});

app.post('/admin/adauga-produs', requireAdmin, (req, res) => {
    const { nume, pret } = req.body;
    const db = new sqlite3.Database(dbPath);
    db.run("INSERT INTO produse (nume,pret) VALUES (?,?)", [nume, pret], function (err) {
        db.close();
        if (err) {

            return res.redirect('/admin?mesaj=Eroare la adăugarea produsului!');
        }

        res.redirect('/admin?mesaj=Produs adăugat cu succes!');
    });
});


app.get('/chestionar', (req, res) => {
    fs.readFile('intrebari.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Eroare la citirea fișierului:', err);
            return res.status(500).send('Eroare la citirea fișierului de întrebări');
        }


        const intrebari = JSON.parse(data);
        res.render('chestionar', { intrebari });
    });
});
app.post('/rezultat-chestionar', (req, res) => {
    fs.readFile('intrebari.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Eroare la citirea fișierului:', err);
            return res.status(500).send('Eroare la citirea fișierului de întrebări');
        }


        const listaIntrebari = JSON.parse(data);


        const raspunsuriCorecte = listaIntrebari.filter((item, index) => {
            return item.corect == req.body[`intrebare${index}`];
        });

        const numarRaspunsuriCorecte = raspunsuriCorecte.length;

        res.render('rezultat-chestionar', {
            scor: numarRaspunsuriCorecte,
            totalIntrebari: listaIntrebari.length
        });
    });
});


app.get('/autentificare', (req, res) => {
    const mesajEroare = req.cookies.mesajEroare || null;
    res.clearCookie('mesajEroare');

    res.render('autentificare', { mesajEroare });
});




app.post('/verificare-autentificare', (req, res) => {
    const { utilizator, parola } = req.body;
    const ip = req.ip;
    const acum = Date.now();

    if (blocaje[ip] && blocaje[ip] > acum) {
        return res.status(403).send('Ai fost blocat temporar pe tot site-ul. Încearcă mai târziu!');
    }
    if (blocaje[utilizator] && blocaje[utilizator] > acum) {
        return res.status(403).send('Acest cont este blocat temporar pe tot site-ul. Încearcă mai târziu!');
    }
    if (incercariNereusiteIP[ip] && incercariNereusiteIP[ip].blocatPana && incercariNereusiteIP[ip].doarLogin && acum < incercariNereusiteIP[ip].blocatPana) {
        return res.status(403).send('Prea multe încercări greșite de pe acest IP într-un interval scurt. Accesul la login este blocat temporar!');
    }
    if (incercariNereusiteUser[utilizator] && incercariNereusiteUser[utilizator].blocatPana && incercariNereusiteUser[utilizator].doarLogin && acum < incercariNereusiteUser[utilizator].blocatPana) {
        return res.status(403).send('Prea multe încercări greșite pentru acest utilizator într-un interval scurt. Accesul la login este blocat temporar!');
    }
    if (!incercariAutentificare[ip]) incercariAutentificare[ip] = [];
    if (!incercariAutentificare[utilizator]) incercariAutentificare[utilizator] = [];
    if (incercariAutentificare[ip].length > 100) incercariAutentificare[ip].shift();
    if (incercariAutentificare[utilizator].length > 100) incercariAutentificare[utilizator].shift();

    const caleFisier = path.join(__dirname, 'public', 'utilizatori.json');
    fs.readFile(caleFisier, 'utf8', (err, data) => {
        if (err) {
            console.error('Eroare la citirea fișierului utilizatori:', err);
            return res.status(500).send('Eroare server');
        }
        const utilizatori = JSON.parse(data);
        const user = utilizatori.find(u => u.utilizator === utilizator && u.parola === parola);

        if (user) {
            delete incercariAutentificare[ip];
            delete incercariAutentificare[utilizator];
            delete incercariNereusiteIP[ip];
            delete incercariNereusiteUser[utilizator];
            req.session.utilizator = { ...user };
            return res.redirect('/');
        } else {

            incercariAutentificare[ip].push(acum);
            incercariAutentificare[utilizator].push(acum);


            const incercariUltimulMinutIP = incercariAutentificare[ip].filter(t => acum - t < 60 * 1000);
            const incercariUltimaOraIP = incercariAutentificare[ip].filter(t => acum - t < 60 * 60 * 1000);


            const incercariUltimulMinutUser = incercariAutentificare[utilizator].filter(t => acum - t < 60 * 1000);
            const incercariUltimaOraUser = incercariAutentificare[utilizator].filter(t => acum - t < 60 * 60 * 1000);

            if (!incercariNereusiteIP[ip]) incercariNereusiteIP[ip] = { count: 0, blocatPana: null, doarLogin: false };
            if (!incercariNereusiteUser[utilizator]) incercariNereusiteUser[utilizator] = { count: 0, blocatPana: null, doarLogin: false };
            incercariNereusiteIP[ip].count++;
            incercariNereusiteUser[utilizator].count++;


            if (incercariUltimulMinutIP.length >= limitaScurta) {
                incercariNereusiteIP[ip].blocatPana = acum + durataBlocareScurta;
                incercariNereusiteIP[ip].doarLogin = true;
                res.cookie('mesajEroare', 'Prea multe încercări greșite de pe acest IP într-un interval scurt. Accesul la login este blocat 1 minut!', { maxAge: 5000 });
                return res.redirect('/autentificare');
            }

            if (incercariUltimulMinutUser.length >= limitaScurta) {
                incercariNereusiteUser[utilizator].blocatPana = acum + durataBlocareScurta;
                incercariNereusiteUser[utilizator].doarLogin = true;
                res.cookie('mesajEroare', 'Prea multe încercări greșite pentru acest utilizator într-un interval scurt. Accesul la login este blocat 1 minut!', { maxAge: 5000 });
                return res.redirect('/autentificare');
            }

            if (incercariUltimaOraIP.length >= limitaLunga) {
                blocaje[ip] = acum + durataBlocareLunga;
                res.cookie('mesajEroare', 'Prea multe încercări greșite de pe acest IP într-un interval lung. Accesul la tot site-ul este blocat 10 minute!', { maxAge: 5000 });
                return res.redirect('/autentificare');
            }

            if (incercariUltimaOraUser.length >= limitaLunga) {
                blocaje[utilizator] = acum + durataBlocareLunga;
                res.cookie('mesajEroare', 'Prea multe încercări greșite pentru acest utilizator într-un interval lung. Accesul la tot site-ul este blocat 10 minute!', { maxAge: 5000 });
                return res.redirect('/autentificare');
            }

            res.cookie('mesajEroare', 'Utilizator sau parolă incorectă.', { maxAge: 5000 });
            return res.redirect('/autentificare');
        }
    });
});


app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Eroare la logout');
        }
        res.redirect('/');
    });
});


app.get('/creare-bd', (req, res) => {
    const db = new sqlite3.Database(dbPath);

    db.serialize(() => {
        db.run(`
            CREATE TABLE IF NOT EXISTS produse (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nume TEXT NOT NULL,
                pret REAL NOT NULL
            )
        `, (err) => {
            if (err) {
                console.error('Eroare la creare tabel:', err.message);
                return res.status(500).send('Eroare la creare tabel.');
            }
            db.close();
            res.redirect('/');
        });
    });
});

app.get('/inserare-bd', (req, res) => {
    const db = new sqlite3.Database(dbPath);

    const produse = [
        { nume: 'Mar', pret: 2.5 },
        { nume: 'Portocala', pret: 3.0 },
        { nume: 'Kiwi', pret: 5.3 },
        { nume: 'Capsuna', pret: 5.0 },
        { nume: 'Banana', pret: 3.4 },
    ];

    db.serialize(() => {
        const stmt = db.prepare("INSERT INTO produse (nume,pret) VALUES (?,?)");
        produse.forEach(p => stmt.run(p.nume, p.pret, p.categorie));
        stmt.finalize();
        db.close();
        res.redirect('/');
    });
});

app.get('/', (req, res) => {
    const db = new sqlite3.Database(dbPath);

    db.all('SELECT * FROM produse', [], (err, produse) => {
        if (err) {
            console.error('ERoare', err.message);
            return res.status(500).send('eroare');
        }
        db.close();
        res.render('index', { produse });
    }
    )
})

app.post('/adaugare-cos', (req, res) => {
    if (!req.session.utilizator) {
        return res.status(401).send('Nu ești autentificat');
    }

    const idProdus = req.body.produsId;


    if (!req.session.cos) {
        req.session.cos = [];
    }

    req.session.cos.push(idProdus);

    res.redirect('/');
});

app.get('/vizualizare-cos', (req, res) => {
    if (!req.session.utilizator) {
        return res.status(401).send('Trebuie să fii autentificat pentru a vedea coșul.');
    }

    const cos = req.session.cos || [];

    if (cos.length === 0) {
        return res.render('vizualizare-cos', { produse: [], total: 0 });
    }

    const cantitati = {};
    cos.forEach(id => {
        cantitati[id] = (cantitati[id] || 0) + 1;

    });

    const idProduseUnice = Object.keys(cantitati);

    const db = new sqlite3.Database(dbPath);
    const placeholders = idProduseUnice.map(() => '?').join(',');
    const query = `SELECT * FROM produse WHERE id IN (${placeholders})`;

    db.all(query, idProduseUnice, (err, rows) => {
        if (err) {
            console.error('Eroare la citirea produselor din coș:', err.message);
            return res.status(500).send('Eroare la afișarea coșului.');
        }

        const produseCuCantitati = rows.map(p => ({
            ...p,
            cantitate: cantitati[p.id],
            subtotal: (p.pret * cantitati[p.id]).toFixed(2)
        }));
        const total = produseCuCantitati.reduce((acc, p) => acc + parseFloat(p.subtotal), 0).toFixed(2);


        db.close();
        res.render('vizualizare-cos', { produse: produseCuCantitati, total });
    });
});


app.use((req, res, next) => {
    const ip = req.ip;
    //blocaje[ip] = Date.now() + durataBlocare;
    res.status(404).send("Resursa nu există. Ai fost blocat 1 minut pentru această încercare.");
});
app.use(function (err, req, res, next) {
    if (err.code === 'EBADCSRFTOKEN') {

        return res.status(403).send('Token CSRF invalid. Formularul a expirat sau nu este valid!');
    }
    next(err);
});


app.listen(port, () => console.log(`Serverul rulează la adresa http://localhost:
:${port}/`));