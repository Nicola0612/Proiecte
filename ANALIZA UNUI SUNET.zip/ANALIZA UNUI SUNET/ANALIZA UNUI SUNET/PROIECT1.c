#include <formatio.h>
#include <math.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include <stdlib.h>
#include <utility.h>

#include <analysis.h>
#include "PROIECT1.h"
 //==============================================================================
// Constants
#define SAMPLE_RATE		0
#define NPOINTS			1
#define M_PI 3.14159265358979323846
static int panelHandle=0;	
static int freqHandle=0;
int waveInfo[2]; //waveInfo[0] = sampleRate
				 //waveInfo[1] = number of elements
double sampleRate = 0.0;
int npoints = 0;
double *waveData = 0;
int currentInterval=0;

int numarFerestre;
int nrFereastra=0;
int numarpuncte; 
double* semnalFiltrat=0;
double* semnalFF=0; 
int tipFiltru; //chebyshev II trece jos pentru 1/3 din spectrul semnalului si un filtru Notch pentru frecventa de 1000 Hz
int tipFereastra;//triunghiular sau flattop
int tipAfisare;
int secunda;
double *waveDataPerNrPuncte;
double *wavepersec;

int main (int argc, char *argv[])
{
	//MakeDir("ProiectAPD");

	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	
	if ((panelHandle = LoadPanel (0, "PROIECT1.uir", MAIN_PANEL)) < 0)
		return -1;
	if((freqHandle=LoadPanel(0,"PROIECT1.uir", FREQ_PANEL))<0)
		return -1;
	
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);

//SetCtrlAttribute(freqHandle, FREQ_PANEL_TIMER, ATTR_ENABLED, 1);

	//SetCtrlAttribute(panelHandle, MAIN_PANEL_ALPHA, ATTR_VISIBLE, 0);

	//free(waveData);  
	return 0;
}

// anvelopa
void anvelopa(int panel, int graphControl, double* waveData, int npoints) {
    double* semnal = (double*)malloc(npoints * sizeof(double));
	memcpy(semnal, waveData, npoints * sizeof(double));
    double* amplitudine = (double*)malloc(npoints * sizeof(double));
    
    
   FastHilbertTransform(semnal, npoints);
    
    
    for (int i = 0; i < npoints; i++) {
        amplitudine[i] = fabs(semnal[i]);
    }
    
    // Afisarea anvelopei pe grafic
    PlotY(panel, graphControl, amplitudine, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_GREEN);
    
    free(semnal);
    free(amplitudine);
}



int comparareValori(const void *a,const void* b){
	double diferenta=(*(double*)a-*(double*)b);
	return (diferenta>0)-(diferenta<0);
}
int CVICALLBACK SchimbaFiltru (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	int tip;
	switch (event)
	{
			case EVENT_COMMIT:
				GetCtrlAttribute(panel,MAIN_PANEL_FILTRU,ATTR_CTRL_INDEX,&tip);
				if(tip==2){
					SetCtrlAttribute(panel, MAIN_PANEL_ALPHA, ATTR_DIMMED, 0);
				}else if(tip==1){
					SetCtrlAttribute(panel, MAIN_PANEL_ALPHA, ATTR_DIMMED, 1);
				}
				

				break;
		}
	return 0;
}
//minim si maxim
 void calculeazaMinMax(double* waveData, int npoints, double* min, double* max, double* indexMin, double* indexMax) {
    *min = waveData[0];
    *max = waveData[0];
    *indexMin = 0;
    *indexMax = 0;
    for (int i = 1; i < npoints; i++) {
        if (waveData[i] < *min) {
            *min = waveData[i];
            *indexMin = i;
        }
        if (waveData[i] > *max) {
            *max = waveData[i];
            *indexMax = i;
        }
    }
}
//medie
double calculeazaMedie(double* waveData, int npoints) {
    double suma = 0;
    for (int i = 0; i < npoints; i++) {
        suma += waveData[i];
    }
    return suma / npoints;
}
//mediana
double calculeazaMediana(double* waveData, int npoints){
	double*copie=(double*)malloc(npoints*sizeof(double));
	memcpy(copie,waveData,npoints*sizeof(double));
	qsort(copie,npoints,sizeof(double),comparareValori);
	double mediana;
	if(npoints%2==0){
		mediana=(copie[npoints/2-1]+copie[npoints/2])/2.0;
	}else{
		mediana=copie[npoints/2];
	}
	free(copie);
	return mediana;
}
//dispersie
double calculeazaDispersie(double* waveData, int npoints, double medie) {
    double suma = 0;
    for (int i = 0; i < npoints; i++) {
        suma += pow(waveData[i] - medie, 2);
    }
    return suma / npoints;
}
//treceri prin zero
double calculeazaTreceriZero(double* waveData, int npoints) {
    double zero = 0;
    for (int i = 1; i < npoints; i++) {
        if ((waveData[i - 1] >= 0 && waveData[i] < 0) || (waveData[i - 1] <= 0 && waveData[i] > 0)) {
            zero++;
        }
    }
    return zero;
}
//histograma
void calculeazaHistograma(double* waveData, int npoints, double min, double max, int nrIntervale, int* histograma) {
    double interval = (max - min) / nrIntervale;
    memset(histograma, 0, nrIntervale * sizeof(int)); // Initializez histograma cu 0
    for (int i = 0; i < npoints; i++) {
        int index = (int)((waveData[i] - min) / interval);
        if (index >= 0 && index < nrIntervale) {
            histograma[index]++;
        }
    }
}


int CVICALLBACK OnLoadButtonCB (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT:
			//executa script python pentru conversia unui fisierului .wav in .txt
		//	LaunchExecutable("python main.py");
			
			//astept sa fie generate cele doua fisiere (modificati timpul daca este necesar
		//	Delay(4);
			
			//incarc informatiile privind rata de esantionare si numarul de valori
			FileToArray("wafeInfo.txt", waveInfo, VAL_INTEGER, 2, 1, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS, VAL_ASCII);
			sampleRate = waveInfo[SAMPLE_RATE];
			npoints = waveInfo[NPOINTS];
			waveData = (double *) calloc(npoints, sizeof(double)); 
			//incarcare din fisierul .txt in memorie (vector)
			FileToArray("waveData.txt", waveData, VAL_DOUBLE, npoints, 1, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS, VAL_ASCII);
			
			//afisare pe grapf
			PlotY(panel, MAIN_PANEL_IDC_GRAPH_RAW_DATA, waveData, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_MAGENTA);
			anvelopa(panel,MAIN_PANEL_IDC_GRAPH_RAW_DATA,waveData,npoints);   
			
			double min,max;
			double indexMin,indexMax;
			calculeazaMinMax(waveData,npoints,&min,&max,&indexMin,&indexMax);
			char minStr[50], maxStr[50], indexminstr[50],indexmaxstr[50];
			sprintf(minStr,"%.2f",min);
			sprintf(maxStr,"%.2f",max);
			sprintf(indexminstr,"%.2f",indexMin);
			sprintf(indexmaxstr,"%.2f",indexMax);
			SetCtrlVal(panel, MAIN_PANEL_MIN  ,minStr);
			SetCtrlVal(panel,MAIN_PANEL_MAX,maxStr);
			SetCtrlVal(panel,MAIN_PANEL_IMIN,indexminstr);
			SetCtrlVal(panel,MAIN_PANEL_IMAX,indexmaxstr);
			
			//medie
			double medie=calculeazaMedie(waveData,npoints);
			char medieStr[50];
            sprintf(medieStr, "%.2f", medie);
            SetCtrlVal(panel, MAIN_PANEL_MEDIE, medieStr);
			//mediana
			 double mediana = calculeazaMediana(waveData, npoints);
			char medianastr[50];
			sprintf(medianastr,"%.2f",mediana);
			SetCtrlVal(panel,MAIN_PANEL_MEDIANA,medianastr);
			//dispersie
			 double dispersie = calculeazaDispersie(waveData, npoints, medie);
			char disstr[50];
			sprintf(disstr,"%.2f",dispersie);
			SetCtrlVal(panel,MAIN_PANEL_DISPERSIE,disstr);
			//treceri prin zero
			double zero = calculeazaTreceriZero(waveData, npoints);
			char zerostr[50];
			sprintf(zerostr,"%.2f",zero);
			SetCtrlVal(panel,MAIN_PANEL_ZERO,zerostr);
			//histograma
			int nrIntervale = 20; // Numarul de intervale din histograma
            GetCtrlVal(panel, MAIN_PANEL_INTERVALE, &nrIntervale);
            int* histograma = (int*)calloc(nrIntervale, sizeof(int));
            calculeazaHistograma(waveData, npoints, min, max, nrIntervale, histograma);
			//afisare histograma pe grafic
			PlotY(panel,MAIN_PANEL_HISTOGRAMA,histograma,nrIntervale,VAL_INTEGER,VAL_VERTICAL_BAR,VAL_EMPTY_SQUARE,VAL_SOLID,VAL_CONNECTED_POINTS,VAL_BLUE);
			free(histograma);	
			
			
			
			
			
			break;
	}
	return 0;
}
void calculeazaDerivata(double *semnal, double *derivata, int npoints, double sampleRate) {
    for (int i = 0; i < npoints - 1; i++) {
        derivata[i] = (semnal[i + 1] - semnal[i]) * sampleRate;
    }
    derivata[npoints - 1] = derivata[npoints - 2]; // Extrapolare pentru ultimul punct
}
void filtrareMediere(double *semnal,double *filt,int npoints,int fereastra){
	for(int i=0;i<npoints;i++){
		double suma=0.0;
		int count=0;
		
		for(int j=i-fereastra/2;j<=i+fereastra/2;j++){
			if(j>=0 &&j<npoints){
				suma+=semnal[j];
				count++;
			}
			}
			filt[i]=suma/count;
		}
}

void filtrareOrdinI(double *semnal,double *filt,int npoints,double alpha){
	filt[0]=semnal[0];
	for(int i=1;i<npoints;i++){
		filt[i] = (1 - alpha) * filt[i - 1] + alpha * semnal[i];
	}
}
  

void saveGraph(int panel, int graphControl, const char *filename) {
    int bitmapID;
    GetCtrlDisplayBitmap(panel, graphControl, 1, &bitmapID);
    SaveBitmapToJPEGFile(bitmapID, filename, JPEG_PROGRESSIVE, 100);
    DiscardBitmap(bitmapID);
}

void SalveazaImagine(int panel, int panelID, const char *numeFisier) {
    int bitmapID;
    GetCtrlDisplayBitmap(panel, panelID, 1, &bitmapID);
    SaveBitmapToJPEGFile(bitmapID, numeFisier, JPEG_PROGRESSIVE, 100);
    DiscardBitmap(bitmapID);
}
void saveCurrentIntervalGraphs() {
    char filename[100];

    // salvare grafic original
    sprintf(filename, "ProiectAPD/grafic_original_interval_%d.jpg", currentInterval);
    SalveazaImagine(panelHandle, MAIN_PANEL_IDC_GRAPH_RAW_DATA, filename);

    //salvare grafic filtrat
    sprintf(filename, "ProiectAPD/grafic_filtrat_interval_%d.jpg", currentInterval);
    SalveazaImagine(panelHandle, MAIN_PANEL_FILTRARE, filename);
}




void afiseazaSemnalFiltrat(int panel,double *filt,int length){

	DeleteGraphPlot(panel, MAIN_PANEL_FILTRARE, -1, 0);

	PlotY(panel,MAIN_PANEL_FILTRARE,filt,length,VAL_DOUBLE,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,VAL_CONNECTED_POINTS,VAL_RED);
	anvelopa(panel,MAIN_PANEL_FILTRARE,filt,length);

  	char filename[100];
    sprintf(filename, "ProiectAPD/grafic_filtrat_interval_%d.jpg", currentInterval);
    SalveazaImagine(panel, MAIN_PANEL_FILTRARE, filename);
	
}

void SkewnessKurtosis(int panel) {
    double skewness = 0.0, kurtosis = 0.0;
    int num = 256;  
    double med = 0.0;
    
    if (npoints < num) {
        num = npoints;  
    }

    int start = currentInterval * sampleRate;
    if (start + num > npoints) {
        num = npoints - start;
    }

   
    for (int i = 0; i < num; i++) {
        med += waveData[start + i];
    }
    med /= num;

    double m2 = 0.0;  
    double m3 = 0.0;  
    double m4 = 0.0;  

 
    for (int i = 0; i < num; i++) {
        double dif = waveData[start + i] - med;
        m2 += dif * dif;
        m3 += dif * dif * dif;
        m4 += dif * dif * dif * dif;
    }

    m2 /= num;  
    m3 /= num; 
    m4 /= num;  
	skewness = m3 / pow(m2, 1.5);
    kurtosis = m4 / (m2 * m2);

    
    char sstr[50], kstr[50];
    sprintf(sstr, "%.2f", skewness);
    sprintf(kstr, "%.2f", kurtosis);
    
    SetCtrlVal(panel, MAIN_PANEL_SKEWNESS, sstr);
    SetCtrlVal(panel, MAIN_PANEL_KURTOSIS, kstr);
}
void actualizeazaGraficInterval(int panel) {
    int start = currentInterval * sampleRate;
    int length = sampleRate;
    if (start + length > npoints) {
        length = npoints - start;
    }
	double *filt = (double *)calloc(length, sizeof(double));
    int tip;
    double alpha;
	int derivata;
	double fereastra;
    GetCtrlVal(panel, MAIN_PANEL_FILTRU, &tip);
    GetCtrlVal(panel, MAIN_PANEL_ALPHA, &alpha);
	GetCtrlVal(panel,MAIN_PANEL_FEREASTRA,&fereastra);
	GetCtrlVal(panel,MAIN_PANEL_DERIVATA,&derivata);
    
   
	if(derivata){
		calculeazaDerivata(&waveData[start], filt, length, sampleRate);
        DeleteGraphPlot(panel, MAIN_PANEL_FILTRARE, -1, 0);
        PlotY(panel, MAIN_PANEL_FILTRARE, filt, length, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
		} else{
	   if (tip == 2) {
        filtrareOrdinI(&waveData[start], filt, length, alpha);
		afiseazaSemnalFiltrat(panel,filt,length);
    } else {
        filtrareMediere(&waveData[start], filt, length, fereastra);
		afiseazaSemnalFiltrat(panel,filt,length);
    }
		}
	DeleteGraphPlot(panel,MAIN_PANEL_IDC_GRAPH_RAW_DATA, -1, 0);
	PlotY(panel, MAIN_PANEL_IDC_GRAPH_RAW_DATA, waveData+start, length, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_MAGENTA);
	anvelopa(panel, MAIN_PANEL_IDC_GRAPH_RAW_DATA, waveData+start , length); 
    SkewnessKurtosis(panel);
    saveCurrentIntervalGraphs();
	 double min,max;
	double indexMin,indexMax;
	calculeazaMinMax(waveData+start,length,&min,&max,&indexMin,&indexMax);
	char minStr[50], maxStr[50], indexminstr[50],indexmaxstr[50];
	sprintf(minStr,"%.2f",min);
	sprintf(maxStr,"%.2f",max);
	sprintf(indexminstr,"%.2f",indexMin);
	sprintf(indexmaxstr,"%.2f",indexMax);
	SetCtrlVal(panel, MAIN_PANEL_MIN  ,minStr);
	SetCtrlVal(panel,MAIN_PANEL_MAX,maxStr);
	SetCtrlVal(panel,MAIN_PANEL_IMIN,indexminstr);
	SetCtrlVal(panel,MAIN_PANEL_IMAX,indexmaxstr);
	
	//medie
	double medie=calculeazaMedie(waveData+start,length);
	char medieStr[50];
    sprintf(medieStr, "%.2f", medie);
    SetCtrlVal(panel, MAIN_PANEL_MEDIE, medieStr);
	//mediana
	double mediana = calculeazaMediana(waveData+start, length);
	char medianastr[50];
	sprintf(medianastr,"%.2f",mediana);
	SetCtrlVal(panel,MAIN_PANEL_MEDIANA,medianastr);
	//dispersie
	double dispersie = calculeazaDispersie(waveData+start, length, medie);
	char disstr[50];
	sprintf(disstr,"%.2f",dispersie);
	SetCtrlVal(panel,MAIN_PANEL_DISPERSIE,disstr);
	//treceri prin zero
	double zero = calculeazaTreceriZero(waveData+start, length);
	char zerostr[50];
	sprintf(zerostr,"%.2f",zero);
	SetCtrlVal(panel,MAIN_PANEL_ZERO,zerostr);
    free(filt);
}

int CVICALLBACK IntervalAnterior (int panel, int control, int event,
								  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(currentInterval>0) {
				currentInterval--;
				actualizeazaGraficInterval(panel);
			}
			

			break;
	}
	return 0;
}

int CVICALLBACK IntervalUrmator (int panel, int control, int event,
								 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if((currentInterval+1)*sampleRate<npoints)
			{
				currentInterval++;
				actualizeazaGraficInterval(panel);	
			}
			break;
	}
	return 0;
}

	
	
	


int CVICALLBACK Buton (int panel, int control, int event,
					   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		 currentInterval = 0;  
         actualizeazaGraficInterval(panel);

              
         break;
    }
    return 0;
}


int CVICALLBACK OnSwitchPanelCB (int panel, int control, int event,
								 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(panel == panelHandle)
			{
				SetCtrlVal(freqHandle, FREQ_PANEL_IDC_SWITCH_PANEL, 1);
				DisplayPanel(freqHandle);
				HidePanel(panel);
			}
			else
			{
				SetCtrlVal(panelHandle, MAIN_PANEL_IDC_SWITCH_PANEL, 0);
				DisplayPanel(panelHandle);
				HidePanel(panel);
			}
			break;

		
	}
	return 0;
}

int CVICALLBACK OnFrequencyPanel (int panel, int event, void *callbackData,
								  int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			QuitUserInterface(0);

			break;
	}
	return 0;
}

void afisareSpectru(int panel)
{
	if(tipAfisare==0)//pe numarul de puncte
	{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(numarpuncte/2,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(numarpuncte/2,sizeof(double));
			double dff=0.0;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			char unit[32]="V";
			WindowConst winConst;
			
			ScaledWindowEx(semnalFF,numarpuncte,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,numarpuncte,1.0/sampleRate,autoSpectrumsff,&dff);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff,numarpuncte/2,-1.0,winConst,dff,7,&freqPeak1,&powerPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ2, freqPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER2 , powerPeak1);
	    	
		 	SpectrumUnitConversion(autoSpectrumsff, numarpuncte/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU2, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel,FREQ_PANEL_SPECTRU2, convertedSpectrumsff, numarpuncte/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
		
	}
	else
		if(tipAfisare==1)//tot semnalul
		{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(npoints/2,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(npoints/2,sizeof(double));
			double dff=0.0;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			char unit[32]="V";
			WindowConst winConst;
			
			ScaledWindowEx(semnalFF,npoints,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,npoints,1.0/sampleRate,autoSpectrumsff,&dff);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff,npoints/2,-1.0,winConst,dff,7,&freqPeak1,&powerPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ2, freqPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER2, powerPeak1);
		
			SpectrumUnitConversion(autoSpectrumsff, npoints/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU2, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_SPECTRU2, convertedSpectrumsff, npoints/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	
		}
	else
		if(tipAfisare==2)//pe secunde
		{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(npoints/12,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(npoints/12,sizeof(double));
			double dff=0.0;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			char unit[32]="V";
			WindowConst winConst;
			
			ScaledWindowEx(semnalFF,npoints/6,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,npoints/6,1.0/sampleRate,autoSpectrumsff,&dff);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff,npoints/12,-1.0,winConst,dff,7,&freqPeak1,&powerPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ2, freqPeak1);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER2, powerPeak1);
		
			SpectrumUnitConversion(autoSpectrumsff, npoints/12,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU2, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_SPECTRU2, convertedSpectrumsff, npoints/24 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	
		}
	
}
void aplicareFereastra(int panel)
{
    GetCtrlAttribute(panel,FREQ_PANEL_FEREASTRA , ATTR_CTRL_INDEX, &tipFereastra);
    double *fereastra;

    if (tipAfisare == 0) // pe numarul de puncte
    {
        semnalFF = (double *)malloc(numarpuncte * sizeof(double));
        fereastra = (double *)malloc(numarpuncte * sizeof(double));

        for (int i = 0; i < numarpuncte; i++)
        {
            fereastra[i] = 1.0; 
        }

        if (tipFereastra == 0) // Fereastra Triunghiulara
        {
            for (int i = 0; i < numarpuncte; i++)
            {
                fereastra[i] = 1.0 - fabs((i - (numarpuncte - 1) / 2.0) / ((numarpuncte - 1) / 2.0));
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
        else if (tipFereastra == 1) // Fereastra Flat-Top
        {
            for (int i = 0; i < numarpuncte; i++)
            {
                fereastra[i] = 0.22 - 0.42 * cos(2 * M_PI * i / (numarpuncte - 1)) +
                               0.28 * cos(4 * M_PI * i / (numarpuncte - 1)) -
                               0.08* cos(6 * M_PI * i / (numarpuncte - 1)) +
                               0.007 * cos(8 * M_PI * i / (numarpuncte - 1));
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }

        if (tipFiltru == 0 || tipFiltru==1)
        {
            Mul1D(semnalFiltrat, fereastra, numarpuncte, semnalFF);
            DeleteGraphPlot(panel,FREQ_PANEL_GRAPH_FF, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FF, semnalFF, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            afisareSpectru(panel);
        }
    }
    else if (tipAfisare == 1) // tot semnalul
    {
        semnalFF = (double *)malloc(npoints * sizeof(double));
        fereastra = (double *)malloc(npoints * sizeof(double));

        for (int i = 0; i < npoints; i++)
        {
            fereastra[i] = 1.0;
        }

        if (tipFereastra == 0) // Fereastra Triunghiulara
        {
            for (int i = 0; i < npoints; i++)
            {
                fereastra[i] = 1.0 - fabs((i - (npoints - 1) / 2.0) / ((npoints - 1) / 2.0));
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
        else if (tipFereastra == 1) // Fereastra Flat-Top
        {
            for (int i = 0; i < npoints; i++)
            {
                fereastra[i] =0.22 - 0.42 * cos(2 * M_PI * i / (numarpuncte - 1)) +
                               0.28* cos(4 * M_PI * i / (numarpuncte - 1)) -
                               0.08 * cos(6 * M_PI * i / (numarpuncte - 1)) +
                               0.007 * cos(8 * M_PI * i / (numarpuncte - 1));   
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }

        if (tipFiltru == 0 || tipFiltru==1)
        {
            Mul1D(semnalFiltrat, fereastra, npoints, semnalFF);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FF, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FF, semnalFF, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
    }
    else if (tipAfisare == 2) // pe secunde
    {
        semnalFF = (double *)malloc(npoints / 6 * sizeof(double));
        fereastra = (double *)malloc(npoints / 6 * sizeof(double));

        for (int i = 0; i < npoints / 6; i++)
        {
            fereastra[i] = 1.0; 
        }

        if (tipFereastra == 0) // Fereastra Triunghiulara
        {
            for (int i = 0; i < npoints / 6; i++)
            {
                fereastra[i] = 1.0 - fabs((i - ((npoints / 6) - 1) / 2.0) / (((npoints / 6) - 1) / 2.0));
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
        else if (tipFereastra == 1) // Fereastra Flat-Top
        {
            for (int i = 0; i < npoints / 6; i++)
            {
                fereastra[i] =0.22- 0.42 * cos(2 * M_PI * i / (numarpuncte - 1)) +
                               0.28 * cos(4 * M_PI * i / (numarpuncte - 1)) -
                               0.08 * cos(6 * M_PI * i / (numarpuncte - 1)) +
                               0.007 * cos(8 * M_PI * i / (numarpuncte - 1));  
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }

        if (tipFiltru == 0 || tipFiltru==1)
        {
            Mul1D(semnalFiltrat, fereastra, npoints / 6, semnalFF);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FF, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FF, semnalFF, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
    }

  
}
void aplicareFiltru(int panel)
{
	GetCtrlAttribute(panel,FREQ_PANEL_FILTRU,ATTR_CTRL_INDEX,&tipFiltru);
	
	//filtru
	if(tipAfisare==0) //afisare pe nr de puncte
	{
		semnalFiltrat=(double *) malloc(numarpuncte*numarFerestre*sizeof(double));
		if(tipFiltru==0)
		{
			
			InvCh_LPF(waveDataPerNrPuncte,numarpuncte*numarFerestre,sampleRate,sampleRate/6.0,40,7,semnalFiltrat);
						
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
			PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT,semnalFiltrat+nrFereastra*numarpuncte,numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);		
			aplicareFereastra(panel);
		}
		else
			if(tipFiltru==1) //Notch
			{
				double Numerator[3], Denominator[3];
            double freqNotch = 500.0;
            double omega = 2 * M_PI * freqNotch / sampleRate;
            double bandwidth = 0.1; 
            double alpha = sin(omega) * sinh(log(2.0) / 2 * bandwidth * omega / sin(omega));

            Numerator[0] = 1.0;
            Numerator[1] = -2.0 * cos(omega);
            Numerator[2] = 1.0;

            Denominator[0] = 1.0;
            Denominator[1] = -2.0 * cos(omega) * (1 - alpha);
            Denominator[2] = 1.0 - alpha;

            semnalFiltrat[0] = waveData[0];
            semnalFiltrat[1] = waveData[1];
            for (int i = 2; i < numarpuncte; i++) 
            {
                semnalFiltrat[i] = Numerator[0] * waveData[i + numarpuncte * nrFereastra] +
                                   Numerator[1] * waveData[(i - 1) + numarpuncte * nrFereastra] +
                                   Numerator[2] * waveData[(i - 2) + nrFereastra * numarpuncte] -
                                   Denominator[1] * semnalFiltrat[i - 1] -
                                   Denominator[2] * semnalFiltrat[i - 2];
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFiltrat, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			aplicareFereastra(panel); 
			}
	}
	else
		if(tipAfisare==1) //semnal intreg
		{
			semnalFiltrat=(double *) malloc(npoints*sizeof(double));
			if(tipFiltru==0)
		{
			
			InvCh_LPF(waveData,npoints,sampleRate,sampleRate/6.0,40,20,semnalFiltrat);
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
			PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT,semnalFiltrat,npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);		
			aplicareFereastra(panel);	
		}
		else
			if(tipFiltru==1) //Notch
			{
				double Numerator[3], Denominator[3];
            double freqNotch = 500.0;
            double omega = 2 * M_PI * freqNotch / sampleRate;
            double bandwidth = 0.1; 
            double alpha = sin(omega) * sinh(log(2.0) / 2 * bandwidth * omega / sin(omega));

            Numerator[0] = 1.0;
            Numerator[1] = -2.0 * cos(omega);
            Numerator[2] = 1.0;

            Denominator[0] = 1.0;
            Denominator[1] = -2.0 * cos(omega) * (1 - alpha);
            Denominator[2] = 1.0 - alpha;

            semnalFiltrat[0] = waveData[0];
            semnalFiltrat[1] = waveData[1];
            for (int i = 2; i < npoints; i++)
            {
                semnalFiltrat[i] = Numerator[0] * waveData[i] +
                                   Numerator[1] * waveData[i - 1] +
                                   Numerator[2] * waveData[i - 2] -
                                   Denominator[1] * semnalFiltrat[i - 1] -
                                   Denominator[2] * semnalFiltrat[i - 2];
            }
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFiltrat, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			aplicareFereastra(panel); 
			}
		}
		else
			if(tipAfisare==2)
			{
				semnalFiltrat=(double *) malloc(npoints/6*sizeof(double));
				if(tipFiltru==0)
			{
				InvCh_LPF(wavepersec,npoints/6,sampleRate,sampleRate/6.0,40,7,semnalFiltrat);
				DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
				PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT,semnalFiltrat,npoints/6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);		
				aplicareFereastra(panel); 
			}
			else
				if(tipFiltru==1) //Notch
				{
					double freqNotch = 500.0; 
					double omega = 2 * M_PI * freqNotch / sampleRate;
					double bandwidth = 0.1; 
					double alpha = sin(omega) * sinh(log(2) / 2 * bandwidth * omega / sin(omega));

					double Numerator[3], Denominator[3];
					Numerator[0] = 1.0;
					Numerator[1] = -2.0 * cos(omega);
					Numerator[2] = 1.0;

					Denominator[0] = 1.0;
					Denominator[1] = -2.0 * cos(omega) * (1 - alpha);
					Denominator[2] = 1.0 - alpha;

				
					semnalFiltrat[0] = waveData[secunda * npoints / 6]; 
					semnalFiltrat[1] = waveData[1 + secunda * npoints / 6]; 

				
					for (int i = 2; i < npoints / 6; i++) 
					{
    					semnalFiltrat[i] = Numerator[0] * waveData[i + secunda * npoints / 6] +
                       						Numerator[1] * waveData[(i - 1) + secunda * npoints / 6] +
                       						Numerator[2] * waveData[(i - 2) + secunda * npoints / 6] -
                       						Denominator[1] * semnalFiltrat[i - 1] -
                       						Denominator[2] * semnalFiltrat[i - 2];
					}

				
					DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
					PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFiltrat, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
					aplicareFereastra(panel); 
				}		
			}
			
}





void afisSemnalIntreg(int panel)
{
	double *convertedSpectrumsi= (double*)malloc((int)(npoints/2) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints/2) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="V";
	WindowConst winConst;
	
		
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_INITIAL, -1, VAL_IMMEDIATE_DRAW);
	PlotY(panel, FREQ_PANEL_GRAPH_INITIAL, waveData, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	ScaledWindowEx(waveData,npoints,RECTANGLE_,0,&winConst);
	AutoPowerSpectrum(waveData,npoints,1.0/sampleRate,autoSpectrumsi,&df);
	//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
	PowerFrequencyEstimate(autoSpectrumsi,npoints/2,-1.0,winConst,df,7,&freqPeak,&powerPeak);
	SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ, freqPeak);
	SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER, powerPeak);
	
	SpectrumUnitConversion(autoSpectrumsi, npoints/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
	DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
	PlotWaveform(panel, FREQ_PANEL_SPECTRU, convertedSpectrumsi, npoints/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	aplicareFiltru(panel);
	aplicareFereastra(panel);
	afisareSpectru(panel);
			
			
		
}

int CVICALLBACK OnTimer (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{   double* convertedSpectrumsi = (double*)malloc((int)(npoints) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="V";
	
	
	WindowConst winConst;
	switch (event)
	{
		case EVENT_TIMER_TICK:
			GetCtrlVal(panel, FREQ_PANEL_PUNCTE, &numarpuncte);
			if (waveData == NULL) {
    MessagePopup("Eroare", "Datele nu sunt �ncarcate. Apasa butonul de �ncarcare.");
    return -1;
}

			double *wave=(double*)calloc(numarpuncte,sizeof(double));
			for(int i=0;i<numarpuncte;i++)
			{
				wave[i]=waveData[i+numarpuncte*nrFereastra];
			}
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_INITIAL, -1, VAL_IMMEDIATE_DRAW);
			PlotY(panel, FREQ_PANEL_GRAPH_INITIAL, wave, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			//spectru semnal initial
			
			numarFerestre = (int)(((double)npoints) / numarpuncte);
			if (((double)npoints) / numarpuncte - numarFerestre > 0.0)
			{
				numarFerestre++;
			}
			waveDataPerNrPuncte=(double*)calloc(numarpuncte*numarFerestre,sizeof(double));
			
			for(int i=0;i<numarpuncte*numarFerestre;i++)//formam wave data astfel incat sa avem un nr complet de puncte si pentru ultima fereastra(completam ultima fereastra cu 0)
			{
				if(i<npoints)
				{
					waveDataPerNrPuncte[i]=waveData[i];
				}
				else
				{
					waveDataPerNrPuncte[i]=0;
				}
			}
			
			
			convertedSpectrumsi=(double*)calloc(numarpuncte/2,sizeof(double));
			autoSpectrumsi=(double*)calloc(numarpuncte/2,sizeof(double));
			
			ScaledWindowEx(waveDataPerNrPuncte+nrFereastra*numarpuncte,numarpuncte,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(waveDataPerNrPuncte+nrFereastra*numarpuncte,numarpuncte,1.0/sampleRate,autoSpectrumsi,&df);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsi,numarpuncte/2,-1.0,winConst,df,7,&freqPeak,&powerPeak);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ, freqPeak);
			SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER, powerPeak);
	    
		 	SpectrumUnitConversion(autoSpectrumsi, numarpuncte/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_SPECTRU, convertedSpectrumsi, numarpuncte/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
			aplicareFiltru(panel);
			aplicareFereastra(panel);
			//afisareSpectru(panel);
			
			if(nrFereastra==numarFerestre)
			{
				nrFereastra=0;
			}
			else
				nrFereastra++;
			break;
	}
	return 0;
}

void afispesecunde(int panel)
{
	double *convertedSpectrumsi= (double*)malloc((int)(npoints/12) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints/12) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="V";
	WindowConst winConst;
	GetCtrlAttribute(panel,FREQ_PANEL_RING_SECUNDE,ATTR_CTRL_INDEX,&secunda);
	wavepersec=(double*)malloc((int)(npoints/6) * sizeof(double));
	for(int i=0;i<npoints/6;i++)
	{
		wavepersec[i]=waveData[npoints/6*secunda+i];
	}
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_INITIAL, -1, VAL_IMMEDIATE_DRAW);
	PlotY(panel, FREQ_PANEL_GRAPH_INITIAL, wavepersec, npoints/6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	ScaledWindowEx(wavepersec,npoints/6,RECTANGLE_,0,&winConst);
	AutoPowerSpectrum(wavepersec,npoints/6,1.0/sampleRate,autoSpectrumsi,&df);
	//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
	PowerFrequencyEstimate(autoSpectrumsi,npoints/12,-1.0,winConst,df,7,&freqPeak,&powerPeak);
	SetCtrlVal( panel, FREQ_PANEL_NUMERIC_FREQ, freqPeak);
	SetCtrlVal( panel, FREQ_PANEL_NUMERIC_POWER, powerPeak);
	
	SpectrumUnitConversion(autoSpectrumsi, npoints/12,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
	DeleteGraphPlot (panel,FREQ_PANEL_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
	PlotWaveform(panel, FREQ_PANEL_SPECTRU, convertedSpectrumsi, npoints/24 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	aplicareFiltru(panel);
	aplicareFereastra(panel);
	afisareSpectru(panel);
}
int CVICALLBACK OnSecunda (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			afispesecunde(panel);

			break;
	}
	return 0;
}

int CVICALLBACK OnShow (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlAttribute(panel,FREQ_PANEL_AFISARE,ATTR_CTRL_INDEX,&tipAfisare);
				if(tipAfisare==0)
			{
				nrFereastra=0;
				SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,1);
				SetCtrlAttribute(panel, FREQ_PANEL_PUNCTE,ATTR_DIMMED,0);
				SetCtrlAttribute(panel,FREQ_PANEL_RING_SECUNDE,ATTR_DIMMED,1);
			}
			else
				if(tipAfisare==1)
				{
					SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,0);
					SetCtrlAttribute(panel, FREQ_PANEL_PUNCTE,ATTR_DIMMED,1);
					SetCtrlAttribute(panel,FREQ_PANEL_RING_SECUNDE,ATTR_DIMMED,1);
					afisSemnalIntreg(panel);
				}
			else
				if(tipAfisare==2)
				{
					SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,0);
					SetCtrlAttribute(panel, FREQ_PANEL_PUNCTE,ATTR_DIMMED,1);
					SetCtrlAttribute(panel,FREQ_PANEL_RING_SECUNDE,ATTR_DIMMED,0);
					afispesecunde(panel);
				}

			break;
	}
	return 0;
}

int CVICALLBACK OnLoadButton2 (int panel, int control, int event,
							   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlAttribute(freqHandle, FREQ_PANEL_TIMER, ATTR_ENABLED, 1); 
			

			break;
	}
	return 0;
}

int CVICALLBACK OnWindowType (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			aplicareFereastra(panel);

			break;
	}
	return 0;
}



int CVICALLBACK OnFilterType (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			aplicareFiltru(panel);
			break;
	}
	return 0;
}


int CVICALLBACK OnSave2 (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int bitmapID=0;
			char*filename=0;
			filename=(char*)calloc(100,sizeof(char));
			//spectru semnal initial
			GetCtrlDisplayBitmap(panel,FREQ_PANEL_SPECTRU,1,&bitmapID);
			if(tipAfisare==0)
			{
				sprintf(filename,"ProiectAPD/Spectru_initial_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
			}
			else
				if(tipAfisare==1)
				{
					sprintf(filename,"ProiectAPD/Spectru_initial_intreg.png");
				}
			else
				if(tipAfisare==2)
				{
					sprintf(filename,"ProiectAPD/Spectru_initial_secunda_%d_%d.png",secunda,secunda+1);
				}
			SaveBitmapToJPEGFile(bitmapID,filename,JPEG_DCTFLOAT,50);
			DiscardBitmap(bitmapID);
			
			//fereastra simpla
			GetCtrlDisplayBitmap(panel,FREQ_PANEL_GRAPH_FEREASTRA,1,&bitmapID);
			if(tipAfisare==0)
			{
				if(tipFereastra==0)
				{
				sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_numarpuncte_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
				}
				else
					if(tipFereastra==1)
					{
						sprintf(filename,"ProiectAPD/Fereastra_flat-top_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
					}
			}
			else
				if(tipAfisare==1)
				{
					if(tipFereastra==0)
					{
						sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_intreg.png");
					}
					else
						if(tipFereastra==1)
						{
							sprintf(filename,"ProiectAPD/Fereastra_flat-top_intreg.png");
						}
				}
			else
				if(tipAfisare==2)
				{
					if(tipFereastra==0)
					{
						sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_secunda_%d_%d.png",secunda,secunda+1);
					}
					else
						if(tipFereastra==2)
						{
							sprintf(filename,"ProiectAPD/Fereastra_flat-top_secunda_%d_%d.png",secunda,secunda+1);
						}
					}
					
			SaveBitmapToJPEGFile(bitmapID,filename,JPEG_DCTFLOAT,50);
			DiscardBitmap(bitmapID);
			GetCtrlDisplayBitmap(panel,FREQ_PANEL_GRAPH_FILTRAT,1,&bitmapID);
			//semnal filtrat
			if(tipAfisare==0)
			{
				if(tipFiltru==0)
				{
					sprintf(filename,"ProiectAPD/Filtru_ChebyshevII_trece_jos_numarpuncte_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
				}
				else
					if(tipFiltru==1)
					{
						sprintf(filename,"ProiectAPD/Filtru_Notch_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
				}
			}
			
			else
				if(tipAfisare==1)
				{
					if(tipFiltru==0)
					{
						sprintf(filename,"ProiectAPD/Filtru_ChebyshevII_trece_jos_intreg.png");
					}
					else
						if(tipFiltru==1)
						{
							sprintf(filename,"ProiectAPD/Filtru_Notch_intreg.png");
						}
				}
			else 
				if(tipAfisare==2)
				{
					if(tipFiltru==0)
				{
					sprintf(filename,"ProiectAPD/Filtru_ChebyshevII_trece_jos_secunde_%d_%d.png",secunda,secunda+1);
				}
				else
					if(tipFiltru==1)
					{
						sprintf(filename,"ProiectAPD/Filtru_Notch_%d_%d.png",secunda,secunda+1);
				}
				}
			
			SaveBitmapToJPEGFile(bitmapID,filename,JPEG_DCTFLOAT,50);
			DiscardBitmap(bitmapID);
			
			GetCtrlDisplayBitmap(panel,FREQ_PANEL_GRAPH_FF,1,&bitmapID);
			//semnal filtrat si ferestruit
			
			if(tipAfisare==0)
			{
				if(tipFereastra==0)
				{
					if(tipFiltru==0)
					{
						sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_filtru_chebyshevII_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
					}
					else 
						if(tipFiltru==1)
						{
							sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_filtru_Notch_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
						}
				}
				else
					if(tipFereastra==1)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Fereastra_flat-top_filtru_chebyshevII_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Fereastra_flat-top_filtru_Notch_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
							}
					}
			}
			else
				if(tipAfisare==1)
				{
					if(tipFereastra==0)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_Filtru_ChebyshevII_trece_jos_intreg.png");
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_Filtru_Notch_intreg.png");
							}
					}
					else
						if(tipFereastra==1)
						{
							if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Fereastra_flat-top_Filtru_ChebyshevII_trece_jos_intreg.png");
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Fereastra_flat-top_Filtru_Notch_intreg.png");
							}
					}
				}
			else
				if(tipAfisare==2)
				{
					if(tipFereastra==0)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_Filtru_ChebyshevII_%d_%d.png",secunda,secunda+1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Fereastra_triunghiulara_Filtru_Notch_%d_%d.png",secunda,secunda+1);
							}
					}
					else
						if(tipFereastra==1)
						{
							if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Fereastra_Flat-Top_Filtru_ChebyshevII_%d_%d.png",secunda,secunda+1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Fereastra_Flat-Top_Filtru_Notch_%d_%dintreg.png",secunda,secunda+1);
							}
					}
				}
			SaveBitmapToJPEGFile(bitmapID,filename,JPEG_DCTFLOAT,50);
			DiscardBitmap(bitmapID);
			
			GetCtrlDisplayBitmap(panel,FREQ_PANEL_SPECTRU2 ,1,&bitmapID);
			//spectrul noului semnal
			if(tipAfisare==0)
			{
				if(tipFereastra==0)
				{
					if(tipFiltru==0)
					{
						sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_filtru_chebyshevII_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
					}
					else 
						if(tipFiltru==2)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_filtru_Notch_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
						}
				}
				else
					if(tipFereastra==1)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_filtru_chebyshevII_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_filtru_Notch_%d_%d.png",nrFereastra*numarpuncte,(nrFereastra+1)*numarpuncte-1);
							}
					}
			}
			else
				if(tipAfisare==1)
				{
					if(tipFereastra==0)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_Filtru_ChebyshevII_trece_jos_intreg.png");
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_Filtru_Notch_intreg.png");
							}
					}
					else
						if(tipFereastra==1)
						{
							if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_Filtru_ChebyshevII_trece_jos_intreg.png");
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_Filtru_Notch_intreg.png");
							}
					}
				}
			else
				if(tipAfisare==2)
				{
					if(tipFereastra==0)
					{
						if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_Filtru_ChebyshevII_%d_%d.png",secunda,secunda+1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Spectru_Fereastra_Triunghiulara_Filtru_Notch_%d_%d.png",secunda,secunda+1);
							}
					}
					else
						if(tipFereastra==1)
						{
							if(tipFiltru==0)
						{
							sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_Filtru_ChebyshevII_%d_%d.png",secunda,secunda+1);
						}
						else
							if(tipFiltru==1)
							{
								sprintf(filename,"ProiectAPD/Spectru_Fereastra_Flat-Top_Filtru_Notch_%d_%dintreg.png",secunda,secunda+1);
							}
					}
				}
			SaveBitmapToJPEGFile(bitmapID,filename,JPEG_DCTFLOAT,50);
			DiscardBitmap(bitmapID);
			free(filename);
			break;
	}
	return 0;
}
