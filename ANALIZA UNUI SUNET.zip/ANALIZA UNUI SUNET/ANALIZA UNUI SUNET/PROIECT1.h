/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  FREQ_PANEL                       1       /* callback function: OnFrequencyPanel */
#define  FREQ_PANEL_IDC_SWITCH_PANEL      2       /* control type: binary, callback function: OnSwitchPanelCB */
#define  FREQ_PANEL_GRAPH_INITIAL         3       /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_SPECTRU               4       /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_TIMER                 5       /* control type: timer, callback function: OnTimer */
#define  FREQ_PANEL_PUNCTE                6       /* control type: ring, callback function: (none) */
#define  FREQ_PANEL_NUMERIC_POWER         7       /* control type: numeric, callback function: (none) */
#define  FREQ_PANEL_NUMERIC_FREQ          8       /* control type: numeric, callback function: (none) */
#define  FREQ_PANEL_RING_SECUNDE          9       /* control type: ring, callback function: OnSecunda */
#define  FREQ_PANEL_COMMANDBUTTON2        10      /* control type: command, callback function: OnLoadButton2 */
#define  FREQ_PANEL_AFISARE               11      /* control type: ring, callback function: OnShow */
#define  FREQ_PANEL_GRAPH_FEREASTRA       12      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_GRAPH_FILTRAT         13      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_GRAPH_FF              14      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_SPECTRU2              15      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_FEREASTRA             16      /* control type: ring, callback function: OnWindowType */
#define  FREQ_PANEL_FILTRU                17      /* control type: ring, callback function: OnFilterType */
#define  FREQ_PANEL_NUMERIC_POWER2        18      /* control type: numeric, callback function: (none) */
#define  FREQ_PANEL_NUMERIC_FREQ2         19      /* control type: numeric, callback function: (none) */
#define  FREQ_PANEL_SAVE2                 20      /* control type: command, callback function: OnSave2 */

#define  MAIN_PANEL                       2
#define  MAIN_PANEL_IDC_GRAPH_RAW_DATA    2       /* control type: graph, callback function: (none) */
#define  MAIN_PANEL_COMMANDBUTTON         3       /* control type: command, callback function: OnLoadButtonCB */
#define  MAIN_PANEL_MIN                   4       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_MAX                   5       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_IMIN                  6       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_IMAX                  7       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_MEDIE                 8       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_DISPERSIE             9       /* control type: string, callback function: (none) */
#define  MAIN_PANEL_ZERO                  10      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_HISTOGRAMA            11      /* control type: graph, callback function: (none) */
#define  MAIN_PANEL_MEDIANA               12      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_FILTRU                13      /* control type: ring, callback function: SchimbaFiltru */
#define  MAIN_PANEL_FILTRARE              14      /* control type: graph, callback function: (none) */
#define  MAIN_PANEL_COMMANDBUTTON_2       15      /* control type: command, callback function: Buton */
#define  MAIN_PANEL_INAPOI                16      /* control type: command, callback function: IntervalAnterior */
#define  MAIN_PANEL_INAINTE               17      /* control type: command, callback function: IntervalUrmator */
#define  MAIN_PANEL_SKEWNESS              18      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_KURTOSIS              19      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_ALPHA                 20      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_FEREASTRA             21      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_INTERVALE             22      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_DERIVATA              23      /* control type: radioButton, callback function: (none) */
#define  MAIN_PANEL_IDC_SWITCH_PANEL      24      /* control type: binary, callback function: OnSwitchPanelCB */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK Buton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK IntervalAnterior(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK IntervalUrmator(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnFilterType(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnFrequencyPanel(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnLoadButton2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnLoadButtonCB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnSave2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnSecunda(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnShow(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnSwitchPanelCB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnTimer(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnWindowType(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SchimbaFiltru(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
